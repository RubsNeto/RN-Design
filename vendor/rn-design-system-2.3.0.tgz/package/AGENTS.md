# AGENTS.md — RN Design System contract

Estas instruções valem para todo este repositório e devem ser copiadas/referenciadas por agentes que criam produtos RN Design.

## Leitura obrigatória

Antes de implementar UI:

1. `agent/index.json` para descobrir modos, componentes, estados, templates e contratos;
2. o playbook aplicável: `agent/create-frontend.md` ou `agent/refactor-frontend.md`;
3. `docs/AGENT-QUICKSTART.md`;
4. `design-system/rn-design-system/MASTER.md`;
5. override aplicável em `design-system/rn-design-system/pages/`;
6. `docs/IMPLEMENTATION.md`;
7. os documentos especializados indicados pelo quickstart para a tarefa.

Para artes, campanhas, posts, capas, banners, imagens ou vídeo, siga `agent/create-art.md`, leia `agent/art-direction.json`, `agent/prompts/create-brand-art.md`, `docs/ART-DIRECTION.md` e `docs/BRAND-ASSETS.md`. A seção humana correspondente é `#direcao-de-arte`. Gere a imagem-base sem texto/logo e faça a composição final com Montserrat RN e os assets oficiais.

`agent/index.json` é o índice de descoberta legível por máquina; ele não substitui o Master. Valide sua estrutura com `npm run agent:check` e use `agent/schema.json` em integrações que suportam JSON Schema.

## Decisão de modo

Declare uma escolha:

- `Product`: SaaS, ERP, dashboard, portal, formulário, lista, tabela e trabalho recorrente.
- `Expressive`: proposta, landing, portfólio, onboarding e apresentação.

Na dúvida sobre intensidade use Product, mas derive sua aparência do orçamento. Expressive não pode contaminar áreas densas de trabalho.

## Regras obrigatórias

- Importe `tokens/rn.css` primeiro.
- Reutilize `styles/rn-base.css` e `styles/rn-components.css` ou mapeie exatamente seus tokens.
- Trate a página do orçamento como fonte visual primária; o RN Mail só orienta comportamento operacional ausente nela.
- Use as primitives `rn-story-*` antes de inventar hero, capítulo, progress, handoff, media frame ou ticket.
- Use somente os assets de `assets/`.
- Montserrat RN é a fonte oficial.
- Mantenha apps Product em canvas branco puro e não implemente dark mode. Na réplica Expressive do orçamento, preserve exatamente os capítulos carvão/navy documentados; eles são cenas fixas, não um tema alternável.
- Em Story, use `rn-story-hero`: wordmark, grid editorial, orbitais e composição assimétrica. Em Product, use `rn-brand-canvas`: grid sutil e marcas de canto.
- Para a abertura de marca, use `RnAnimatedWordmark`: `RN DESIGN` entra apenas no eixo vertical, o `RnBrandMark` monta depois e o lockup termina estático. Não crie outra coreografia nem faça replay automático.
- Escolha a escala do wordmark pela superfície: `hero` no hero e no vídeo oficial, `showcase` em `/animacoes`, `panel` no Motion Studio e no blueprint de arte, `compact` no Playground, Quality e miniaturas. Nunca deixe um preview herdar a escala do hero e não sobrescreva essa API com tamanho local.
- Para loading de marca, use `RnBrandLoader` com `variant="radial"` (**Montagem com impacto — 01**). `xl` é exclusivo de splash/troca de contexto; as outras nove variantes são estudos do laboratório, não escolhas de produção.
- Use azul-celeste como ação primária com texto ink. Para texto colorido/links sobre branco use `brand-text`; para foco use `focus`; para borda de controle use `control-border`.
- Use tokens semânticos; não adicione raw hex, spacing, radius, shadow, z-index ou duração em componentes.
- Uma ação primária por tela/região decisória.
- Todo componente interativo tem estados completos e semântica nativa.
- Controle só com ícone possui nome acessível; ícone decorativo fica fora da árvore acessível.
- Use Phosphor Outline; Heroicons Outline é fallback. Não misture famílias na mesma superfície.
- Não use emoji como ícone estrutural.
- Não dependa de hover, animação, cor ou gesto como único canal.
- Respeite `prefers-reduced-motion` e renderize o estado final sem aguardar animação.
- Valide 375, 768, 1024 e 1440px, além de landscape.
- Meta mínima WCAG 2.2 AA.

## Ordem de implementação

1. Defina conteúdo e semântica do DOM.
2. Monte layout mobile first.
3. Aplique tokens e componentes existentes.
4. Implemente loading, empty, error, success, disabled e permission states.
5. Adicione responsividade.
6. Adicione motion somente se comunicar causa/efeito.
7. Teste teclado, foco, contraste, zoom e reduced motion.
8. Rode `npm run audit` ao alterar este sistema.

Para uma criação nova, siga `agent/create-frontend.md`. Para uma base existente, migre em lotes pelo `agent/refactor-frontend.md`. Em ambos os casos conclua com `agent/validate.md`.

Para uma arte, o contrato de saída é diferente: brief normalizado, direção, mapa de composição, prompt da imagem-base, negative prompt, plano de composição final, assets, matriz de exportação, alt text, proveniência e checklist RN. O JSON baixado pelo Prompt Studio representa o brief atual; `agent/art-direction.json` continua sendo o contrato normativo. Confirme direitos e fontes antes da entrega e resolva qualquer campo que o usuário tenha deixado vazio.

## Componentes novos

Antes de criar um componente:

1. confirme que não existe equivalente;
2. defina propósito e contexto;
3. documente anatomia, variantes, estados, semântica e responsive;
4. use apenas tokens existentes ou proponha o novo token em `tokens/rn.css` e rode `npm run tokens:sync` para gerar JSON, JS e TS;
5. adicione exemplo ao catálogo visual;
6. adicione teste/validação proporcional ao risco.

## Proibições

- Não introduza Cormorant, serif “luxury”, dourado/beige ou outra estética genérica premium.
- Não transforme a linguagem em dashboard SaaS genérico, bento grid sem hierarquia ou estética visual do SOGo.
- Não crie dark mode nem hero navy. Capítulos escuros são permitidos em experiências Story derivadas do orçamento e devem usar os scene tokens documentados.
- Não redesenhe/recolora o logo.
- Não copie screenshots BROUD da pasta reference do projeto proposta.
- Não copie a arquitetura de overrides `!important` do SOGo para apps novos.
- Não use glass, glow, tilt, parallax ou cursor customizado em tabelas/formulários.
- Não esconda conteúdo até o scroll.
- Não crie div clicável onde link/button nativo resolve.
- Não remova focus outline sem substituição equivalente.
- Não desabilite zoom, paste ou password managers.

## Entrega

Relate:

- modo escolhido;
- componentes/tokens reutilizados ou adicionados;
- estados cobertos;
- viewports testados;
- resultado de acessibilidade/reduced motion;
- resultado da validação.

## Fonte canônica — front do orçamento

O front do orçamento é a fonte majoritária mesmo quando o pedido não o menciona. Para réplica integral, a implementação de referência é `src/pages/ProposalPage.tsx`: monte-a diretamente, sem `InvitationPage`, preserve todas as seções e altere dados variáveis em `src/data/content.ts`. Para outros apps, traduza o mesmo DNA usando tokens e primitives, sem substituir a composição por um catálogo genérico de cards.
