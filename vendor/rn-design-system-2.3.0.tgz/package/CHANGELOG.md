# Changelog

Todas as mudanças relevantes deste Design System seguem SemVer.

## [Unreleased]

### Alterado

- ação Primary passa a seguir a fonte normativa com sky + ink, e Accent usa ciano + ink;
- `RnDataTable`, `RnSearch` e `RnStepper` passam a cobrir explicitamente os estados declarados em seus contratos.

### Corrigido

- `RnAnimatedWordmark` deixa de contar o espaço entre `RN` e `DESIGN` como uma etapa extra do stagger;
- referências CSS e contratos que apontavam para tokens inexistentes;
- migração de `#ffbb00` deixa de gerar o token inexistente `--rn-color-highlight`;
- card de portfólio usa botão nativo com `aria-pressed` e foco visível;
- validações passam a impedir referências CSS e tokens contratuais sem fonte válida.

## [2.3.0] — 2026-08-26

### Adicionado

- aba **Direção de arte IA** com brief de produção, presets de formato, preview estrutural, prompt completo, negative prompt, brief JSON e downloads;
- contrato `agent/art-direction.json`, schema, playbook e system prompt para agentes criarem artes sem redesenhar logo ou tipografia;
- kit oficial com download direto de logo PNG, símbolo SVG/PNG, animação WebM 1920×1080, halo e pixels;
- script reproduzível `npm run motion:export`, rota isolada de renderização, poster final e metadata sincronizado da animação oficial.

### Alterado

- `RnAnimatedWordmark` agora possui escalas contextuais `hero`, `showcase`, `panel` e `compact`, baseadas no contêiner;
- Hero, Motion Studio, laboratório, Playground, templates e Quality usam escalas próprias sem alterar a coreografia;
- pacote público exporta direção de arte, prompt, vídeo e poster oficiais.

### Corrigido

- wordmark e símbolo não herdam mais o tamanho monumental do hero dentro de abas, cards e miniaturas;
- previews compactos deixam de transbordar em 375, 768, 1024 e 1440px.

## [2.2.0] — 2026-08-26

### Adicionado

- painel visual agent-first com busca global, navegação por grupos e scroll spy, catálogo filtrável, estados, playground de motion, loader oficial, biblioteca de ícones, templates responsivos, playbooks e gates de qualidade;
- `agent/index.json` e `agent/schema.json` como contrato estruturado para agentes criarem ou refatorarem frontends, com roteador de oito tipos de tarefa e playbooks de criação, refatoração e validação;
- validação automática do índice, das referências locais, das âncoras do painel, do loader oficial, dos viewports e do artefato publicado;
- componentes reutilizáveis Tooltip, Switch, Search, Segmented Control, Progress, Stepper e Avatar, com estados e reduced motion documentados;
- biblioteca React publicável com 41 exports, declarações TypeScript, imports individuais e saída ESM validada por um consumidor externo;
- 26 contratos individuais em JSON Schema com anatomia, props, semântica, teclado, estados, tokens, motion, exemplo e critérios de aceite;
- CLI `rn-design` com fluxos `create`, `audit`, `migrate`, `contract` e `doctor` para criação e refatoração assistida por agentes;
- implementações estáveis para Combobox/Autocomplete, Date/Time/Range, Dialog/Drawer/Popover e Data Visualization com estados completos e tabela equivalente;
- Playwright + axe + regressão visual nos viewports 375, 768, 1024 e 1440, incluindo teclado, foco e reduced motion;
- Playground conectado aos exports reais e Motion Studio com scrub de timeline, comparação reduced motion e cópia de CSS/JSON;
- starters executáveis de lista de gestão, formulário, detalhe de entidade e feedback do sistema, promovendo todos os templates a estáveis;
- CI de qualidade e release verificável, com sincronização de versão, pacote npm e publicação com provenance;
- entrada oficial do wordmark `RN DESIGN` com subida vertical, bounce e stagger por letra, seguida pela montagem dos nove paths do símbolo e pelo lockup final, sem rotação ou deslocamento lateral das letras e com fallback imediato para `prefers-reduced-motion`;
- primitives compartilhadas `RnBrandMark` e `RnAnimatedWordmark`, eliminando cópias divergentes da geometria oficial;
- rota `/animacoes` consolidada como referência da única animação oficial, removendo as cinco alternativas e seus controles de seleção.
- botões preenchidos padronizados com texto branco e fundos de marca com contraste adequado, incluindo hover, seleção e variantes secundária, accent e chip interativo.
- brand loader oficial reconstruído com os nove paths vetoriais da marca, quatro escalas (`sm` a `xl`), pausa controlada e fallback para `prefers-reduced-motion`; **Montagem com impacto — 01** é a única coreografia pública oficial;
- rota `/carregamento` preservada como laboratório histórico com dez explorações; as nove alternativas à 01 não integram o contrato de produção.
- símbolo RN vetorizado em SVG com nove fragmentos independentes, gradientes de preenchimento e borda medidos do PNG oficial e export dedicado `./icon.svg`.

## [2.1.0] — 2026-08-22

### Adicionado

- manifesto integral gerado a partir dos custom properties CSS;
- componentes de shell, sidebar, breadcrumb, tabs, paginação, overlays, badge, upload e error summary;
- exemplos React semânticos para CardLink, formulários, tabs, dialog e erros;
- testes automatizados de contraste, contratos, links e artefato de produção;
- quickstart/brief para agentes e starters de auth, product shell, dashboard e experiência Expressive;
- seção visual de estados, acessibilidade, iconografia, voz e release gates;
- changelog, contribuição e atribuição da licença Montserrat.

### Alterado

- foco e bordas de controles passam a usar papéis semânticos com contraste não textual verificado;
- CSS de tokens é a fonte única; JSON, JS e TS passam a ser sincronizados por código;
- build separa CSS por rota e publica documentação, tokens, catálogo e `/orcamento` no `dist`.

### Corrigido

- card interativo agora usa link semântico;
- ícones/imagens críticas declaram dimensões;
- links do catálogo e da documentação resolvem no artefato de produção.

## [2.0.0] — 2026-08-21

- consolidação do Design System RN majoritariamente a partir do front do orçamento;
- tokens, primitives Product/Story, documentação e página visual inicial.
