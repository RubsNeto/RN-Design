# Contribuindo

1. Leia `AGENTS.md`, `docs/AGENT-QUICKSTART.md` e `docs/GOVERNANCE.md`.
2. Trabalhe em uma mudança coerente e mantenha alterações alheias intactas.
3. Edite tokens somente em `tokens/rn.css`; rode `npm run tokens:sync`.
4. Documente API, estados, acessibilidade e migração de componente novo.
5. Atualize `CHANGELOG.md` conforme SemVer.
6. Execute `npm run audit` e registre qualquer verificação manual pendente.

Uma mudança visual precisa mostrar os estados default, hover, focus-visible, active, disabled, loading e os estados contextuais aplicáveis. A revisão considera marca, acessibilidade, engenharia, conteúdo e fidelidade ao orçamento.

