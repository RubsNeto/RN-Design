# RN Design System

Design system oficial da **RN Design & Serviços**, baseado majoritariamente no front da proposta/orçamento. O RN Mail contribui apenas com padrões funcionais para interfaces operacionais.

Versão atual: **2.3.0**.

Ele foi estruturado para dois públicos:

1. pessoas que precisam consultar marca, componentes e padrões;
2. agentes de IA que precisam criar apps consistentes sem inventar branding.

## Ver o Design System

No PowerShell:

```powershell
.\scripts\serve.ps1
```

Abra `http://localhost:8090/` para navegar pelo painel completo: marca, fundamentos, tokens, Playground conectado à biblioteca React, estados, Motion Studio com timeline, loading oficial, ícones, padrões, templates responsivos, acessibilidade, implementação, Direção de arte IA, playbooks para agentes e gates de qualidade. A busca global usa `/` ou `Ctrl/Cmd + K`; a aba de criação assistida possui o link direto `http://localhost:8090/#direcao-de-arte`.

A réplica do front do orçamento, começando diretamente no hero e sem a tela de envelope/cartão, fica em `http://localhost:8090/orcamento`. A entrada oficial em `/animacoes` revela primeiro `RN DESIGN`, monta depois os nove paths vetoriais do símbolo e termina no lockup completo. O loader oficial **Montagem com impacto — 01** aparece no painel também em escala `xl`; `/carregamento` preserva as outras nove explorações apenas como laboratório, sem torná-las variantes oficiais. O catálogo técnico anterior continua disponível em `http://localhost:8090/catalog.html`.

## Comece aqui

1. Preencha o [`starters/AGENT-BRIEF.md`](starters/AGENT-BRIEF.md).
2. Consulte o índice em [`agent/index.json`](agent/index.json) e o contrato individual em [`agent/contracts/`](agent/contracts/).
3. Siga [`agent/create-frontend.md`](agent/create-frontend.md) ou [`agent/refactor-frontend.md`](agent/refactor-frontend.md).
4. Leia o [`docs/AGENT-QUICKSTART.md`](docs/AGENT-QUICKSTART.md), o [Master](design-system/rn-design-system/MASTER.md) e o override da tela.
5. Importe tokens, base e componentes e use apenas os [`assets/`](assets/) oficiais.
6. Finalize com [`agent/validate.md`](agent/validate.md), `rn-design audit`, `npm run agent:check` e `npm run audit`.

Para criar artes, use o [prompt oficial](agent/prompts/create-brand-art.md), o [contrato estruturado](agent/art-direction.json) e o [playbook de arte](agent/create-art.md). Na aba `#direcao-de-arte`, o painel permite preencher o brief de produção, copiar ou baixar o prompt/negative prompt e baixar o brief em JSON. O kit entrega logo PNG, símbolo SVG/PNG, animação oficial WebM 1920×1080, halo e pixels; o JSON exibido no Prompt Studio é o brief preenchido, não substitui o contrato canônico.

Para qualquer novo app, o orçamento é a referência estética dominante. Product é uma redução operacional do mesmo DNA, não outra linguagem visual.

## Uso em um app

```css
@import "@rn-design/system/tokens.css";
@import "@rn-design/system/base.css";
@import "@rn-design/system/components.css";
```

Ou como dependência local:

```json
{
  "dependencies": {
    "@rn-design/system": "file:../system-Design-RN"
  }
}
```

Componentes React tipados:

```tsx
import { RnButton, RnCombobox, RnDialog } from "@rn-design/system/react";
```

Scaffold e auditoria por CLI:

```powershell
npx rn-design create .\portal-rn --template product-shell --mode product
npx rn-design audit .\portal-rn\src --strict
```

## Estrutura

```text
agent/           índice, contratos individuais, schemas e playbooks para agentes
assets/          logo, símbolo, vídeo, fonte e motivos oficiais
cli/             create, audit, migrate, contract e doctor
design-system/   Master e overrides por contexto
docs/            branding, componentes, acessibilidade, conteúdo e implementação
examples/        exemplos HTML e React + TypeScript
scripts/         servidor local e validação
starters/        briefs e esqueletos de telas para novos apps
styles/          base, componentes e bridge Tailwind
tests/           contratos, schema, CLI, axe, teclado e regressão visual
tokens/          CSS, JSON, JavaScript e TypeScript
index.html       entrada Vite do Design System visual
catalog.html     catálogo técnico de tokens e componentes
src/react/       biblioteca React canônica e tipada
src/             painel, fixtures e réplica executável do orçamento
public/          assets executáveis da referência
AGENTS.md        contrato de implementação para agentes
```

## Documentação

- [Master / fonte de verdade](design-system/rn-design-system/MASTER.md)
- [Quickstart para agentes](docs/AGENT-QUICKSTART.md)
- [Índice estruturado para agentes](agent/index.json)
- [Contratos individuais para agentes](docs/AGENT-CONTRACTS.md)
- [Direção de arte e geração assistida](docs/ART-DIRECTION.md)
- [System prompt para criação de artes](agent/prompts/create-brand-art.md)
- [Playbook para criar frontend](agent/create-frontend.md)
- [Playbook para refatorar frontend](agent/refactor-frontend.md)
- [Checklist de validação](agent/validate.md)
- [DNA visual e hierarquia de autoridade](docs/DESIGN-DNA.md)
- [Auditoria dos projetos de origem](docs/SOURCE-AUDIT.md)
- [Front do orçamento — réplica e especificação](docs/BUDGET-FRONT-REFERENCE.md)
- [Gramática visual e background RN](docs/VISUAL-GRAMMAR.md)
- [Marca e assets](docs/BRAND-ASSETS.md)
- [Iconografia](docs/ICONOGRAPHY.md)
- [Especificação de componentes](docs/COMPONENT-SPECS.md)
- [Padrões de tela](docs/PATTERNS.md)
- [Acessibilidade](docs/ACCESSIBILITY.md)
- [Voz e microcopy](docs/CONTENT-VOICE.md)
- [Implementação](docs/IMPLEMENTATION.md)
- [Biblioteca React](docs/REACT-LIBRARY.md)
- [RN Design CLI](docs/CLI.md)
- [Arquitetura](docs/ARCHITECTURE.md)
- [Estratégia de testes](docs/TESTING.md)
- [Releases](docs/RELEASES.md)
- [Governança e evolução](docs/GOVERNANCE.md)
- [Changelog](CHANGELOG.md)
- [Licenças e atribuições](THIRD_PARTY_NOTICES.md)

## Regras rápidas

- Montserrat é a única família oficial.
- O orçamento define majoritariamente visual, composição, tipografia, superfícies e motion.
- Apps Product usam canvas branco e traduzem o mesmo DNA em menor intensidade.
- Experiências narrativas preservam os capítulos escuros fixos do orçamento sem oferecer dark mode.
- O wordmark declara uma escala por superfície: `hero`, `showcase`, `panel` ou `compact`; previews nunca herdam automaticamente o tamanho do hero.
- O background oficial combina grid sutil, símbolo grande no topo direito e símbolo menor no canto inferior esquerdo.
- Azul-celeste `#47ABE1` é a cor primária; navy é reservado para texto de alto contraste e links acessíveis.
- Product é o modo padrão; Expressive é reservado para experiências de marca.
- Nenhum raw hex, spacing, radius ou shadow novo dentro de componentes.
- Use Phosphor Outline como família de ícones.
- WCAG 2.2 AA, teclado, focus-visible e reduced motion são obrigatórios.
- Não altere proporção, cor ou desenho dos assets oficiais.

## Validação

```powershell
npm run audit
```

O audit sincroniza tokens e contratos, valida o índice dos agentes, verifica estrutura/assets, mede contraste, testa schema/CLI/ESM, executa typecheck e build, confere o artefato, roda Playwright + axe nos quatro viewports e simula o pacote npm.
