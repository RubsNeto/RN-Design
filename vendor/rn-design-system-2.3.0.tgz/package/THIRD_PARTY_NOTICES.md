# Licenças e atribuições

## Montserrat

O arquivo `assets/fonts/montserrat.woff2` é distribuído sob a SIL Open Font License 1.1.

Copyright 2024 The Montserrat.Git Project Authors (https://github.com/JulietaUla/Montserrat.git)

O texto completo está em `assets/fonts/OFL.txt` e deve acompanhar qualquer redistribuição da fonte.

## Marca RN

Os arquivos de `assets/brand/` e a identidade RN são ativos proprietários da RN Design & Serviços. A presença neste repositório autoriza seu uso apenas em produtos RN aprovados; não concede direito de sublicenciar, recolorir, redesenhar ou usar a marca em produtos de terceiros.

## Código e documentação

Este repositório é de uso interno/proprietário até que a RN Design & Serviços publique uma licença explícita. Dependências npm mantêm suas próprias licenças, consultáveis em seus respectivos pacotes.

