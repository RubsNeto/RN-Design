# Índice para agentes

`agent/index.json` é o mapa estruturado do RN Design System. Ele não substitui o `MASTER.md`: aponta a ordem de autoridade, os contratos estáveis e os arquivos que devem ser lidos para cada tarefa.

## Ordem mínima

1. Leia `agent/index.json`; use `taskRouter` para descobrir modo, playbook, documentos e entregáveis aplicáveis.
2. Leia `design-system/rn-design-system/MASTER.md`.
3. Leia o override indicado em `modes[].override`.
4. Siga `agent/create-frontend.md` ou `agent/refactor-frontend.md`.
5. Execute os gates de `quality.commands` e entregue o conteúdo de `deliveryContract`.

## Status

- `stable`: decisão oficial pronta para uso.
- `reference`: contrato definido, com implementação de referência que pode exigir composição no app.
- `experimental`: estudo visível, não deve ser escolhido automaticamente.
- `planned`: lacuna registrada; não invente comportamento sem autorização.
- `deprecated`: não usar em trabalho novo; procure substituto e migração.

Em conflito, prevalece a ordem de `authority`. Corrija a divergência no mesmo change set quando estiver alterando este repositório.
