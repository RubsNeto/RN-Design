# Playbook — criar arte RN

1. Leia `agent/art-direction.json`, `agent/prompts/create-brand-art.md`, `docs/ART-DIRECTION.md` e `docs/BRAND-ASSETS.md`.
2. Normalize objetivo, formato, dimensões, público, mensagem, assunto visual, conteúdo obrigatório, direitos e modo.
3. Declare `Expressive` ou `Product/quiet`, um ponto focal, hierarquia, grid, safe area e assets oficiais.
4. Gere apenas a imagem-base, sem texto e sem aproximações do logo.
5. Componha deterministicamente Montserrat RN, conteúdo final e assets de `assets/`.
6. Valide fidelidade, contraste, leitura no tamanho real, direitos, alt text e formatos de exportação.
7. Registre prompt, negative prompt, modelo/ferramenta, fontes, assets e revisão humana.

Nunca declare a peça pronta quando o logo foi gerado, o texto está deformado, os direitos são desconhecidos ou um conteúdo obrigatório está ausente.
