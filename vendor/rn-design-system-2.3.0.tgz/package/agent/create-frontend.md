# Playbook — criar frontend RN

## Entrada obrigatória

Leia `starters/AGENT-BRIEF.md`. Não invente regras de negócio, permissões, integrações ou ações destrutivas ausentes.

## Sequência

1. Classifique cada região como `Product` ou `Expressive`; na dúvida use Product.
2. Leia o override correspondente informado em `agent/index.json`.
3. Liste rotas, tarefas principais, conteúdo e estados antes de escrever CSS.
4. Importe `tokens/rn.css`, `styles/rn-base.css` e `styles/rn-components.css` nessa ordem.
5. Escolha o template ou pattern mais próximo; preserve a hierarquia e substitua o conteúdo.
6. Monte DOM semântico e ordem mobile first.
7. Use apenas tokens, assets e componentes com status `stable` ou `reference`.
8. Implemente default, hover, focus-visible, active, disabled e loading; acrescente estados contextuais.
9. Implemente empty, error, success e permission quando aplicáveis.
10. Adicione motion somente após o estado final funcionar; use a receita oficial e reduced motion.
11. Valide 375, 768, 1024 e 1440px, landscape, teclado, zoom e contraste.
12. Execute gates equivalentes a `quality.commands`.

## Decisões obrigatórias

- Canvas Product branco, sem dark mode.
- Uma ação primária por tela ou região decisória.
- Montserrat RN e assets oficiais.
- O símbolo RN é marca; ícones funcionais seguem Phosphor Outline.
- Abertura Expressive usa `RnAnimatedWordmark` uma vez: letras verticais → símbolo vetorial → lockup estático.
- “Montagem com impacto” é o loader de marca oficial; estudos do laboratório não são opções equivalentes.

## Entrega

Responda com todos os itens de `deliveryContract` de `agent/index.json`. Registre exceções com motivo, impacto e caminho de correção.
