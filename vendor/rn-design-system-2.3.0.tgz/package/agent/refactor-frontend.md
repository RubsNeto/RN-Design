# Playbook — refatorar frontend para RN

## Princípio

Preserve comportamento e dados do produto. Refatore a camada visual e de interação por etapas, sem um big bang e sem apagar alterações do time.

## Auditoria inicial

1. Mapeie rotas, shell, componentes compartilhados e pontos críticos.
2. Liste fontes, cores, spacing, radius, shadows, z-index, animações e assets atuais.
3. Identifique componentes interativos sem semântica nativa, foco, estados ou labels.
4. Classifique cada região como Product ou Expressive.
5. Compare o inventário com `agent/index.json` e registre lacunas antes de editar.

## Migração

1. Importe os tokens sem alterar visual ou comportamento.
2. Substitua valores repetidos por tokens semânticos.
3. Normalize fonte, canvas, containers e hierarquia.
4. Migre Button, Field, Card e Navigation antes de componentes de baixa frequência.
5. Corrija semântica, teclado, foco e contraste junto de cada componente migrado.
6. Implemente estados ausentes e preserve valores depois de erros.
7. Substitua motion divergente por receitas oficiais; remova loops decorativos em Product.
8. Use “Montagem com impacto” apenas nos contextos descritos em `loading.decision`.
9. Compare antes/depois nas quatro viewports e com reduced motion.
10. Remova overrides obsoletos apenas depois da migração correspondente estar validada.

## Não fazer

- Não reescrever regra de negócio para facilitar styling.
- Não trocar todos os componentes em uma única alteração de alto risco.
- Não manter raw values como “temporários” sem registrar dívida e responsável.
- Não transformar telas Product em cenas Expressive.
- Não considerar uma página pronta apenas porque se parece com a referência em desktop.

## Entrega

Inclua inventário inicial, itens migrados, divergências restantes, estados cobertos, resultados de validação e próximo lote recomendado.
