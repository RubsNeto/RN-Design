# Playbook — validar frontend RN

## Marca e fundamentos

- Montserrat RN carregada.
- Canvas Product branco; scene surfaces somente em narrativa Expressive.
- Logo e símbolo terminam na geometria e nas cores oficiais; transform transitório só existe dentro de `RnAnimatedWordmark` ou `RnBrandLoader`.
- Sem raw hex, spacing, radius, shadow, z-index ou duração em componentes.

## Componentes e estados

- Elementos nativos para ação, navegação e formulário.
- Default, hover, focus-visible, active, disabled e loading.
- Selected, expanded, invalid, read-only, empty, error, success e permission quando aplicáveis.
- Mudança de estado não desloca vizinhos nem depende de animationend.

## Acessibilidade

- Um `h1`, landmarks e skip link quando há navegação persistente.
- Teclado completo, foco visível e restaurado depois de overlays.
- Contraste WCAG 2.2 AA.
- Labels, helpers, erros, status e conteúdo dinâmico anunciados.
- Zoom 200%, reflow e reduced motion funcionais.

## Motion e loading

- Wordmark Expressive usa `RnAnimatedWordmark`: letras somente no eixo vertical, símbolo depois, lockup final e replay apenas explícito.
- Loader de marca usa `RnBrandLoader` radial; label descreve a operação no presente contínuo e o ciclo termina junto com o processo.
- Motion contínuo possui pausa no demonstrador e estado final estático em reduced motion.
- Animações ficam em transform/opacity e não atrasam foco, conteúdo ou ação.

## Responsive

- 375, 768, 1024 e 1440px, além de landscape.
- Sem scroll horizontal, exceto wrapper identificado de tabela.
- Alvos de 44×44px e 8px de separação.
- Sticky UI não cobre conteúdo ou foco.

## Relatório

Use os itens de `deliveryContract` em `agent/index.json`. Uma falha conhecida deve conter impacto, workaround e próximo passo; não omita validações não executadas.
