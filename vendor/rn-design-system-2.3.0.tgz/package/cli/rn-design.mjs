#!/usr/bin/env node

import { access, cp, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { dirname, extname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const registry = JSON.parse(await readFile(resolve(packageRoot, "agent/index.json"), "utf8"));
const args = process.argv.slice(2);
const command = args.shift();

const colors = {
  red: "\u001b[31m",
  yellow: "\u001b[33m",
  green: "\u001b[32m",
  cyan: "\u001b[36m",
  dim: "\u001b[2m",
  reset: "\u001b[0m",
};

const useColor = process.stdout.isTTY && !args.includes("--no-color");
const paint = (color, value) => useColor ? `${colors[color]}${value}${colors.reset}` : value;

function option(name, fallback) {
  const index = args.indexOf(`--${name}`);
  if (index < 0) return fallback;
  const value = args[index + 1];
  if (!value || value.startsWith("--")) return true;
  return value;
}

function positional(index = 0) {
  return args.filter((value, valueIndex) => !value.startsWith("--") && !args[valueIndex - 1]?.startsWith("--"))[index];
}

function help() {
  console.log(`RN Design CLI ${registry.meta.version}

Uso:
  rn-design create <diretório> --template product-shell --mode product
  rn-design audit <diretório> [--json] [--strict]
  rn-design migrate <diretório> [--write] [--report arquivo.json]
  rn-design contract <component>
  rn-design doctor

Templates: ${registry.templates.map(({ id }) => id).join(", ")}
Componentes: use "rn-design contract button" para consultar o contrato executável.`);
}

function fail(message, code = 1) {
  console.error(paint("red", `Erro: ${message}`));
  process.exitCode = code;
}

async function exists(path) {
  return access(path).then(() => true).catch(() => false);
}

async function isEmptyDirectory(path) {
  if (!(await exists(path))) return true;
  const info = await stat(path);
  if (!info.isDirectory()) return false;
  return (await readdir(path)).length === 0;
}

async function createProject() {
  const requestedTarget = positional();
  if (!requestedTarget) return fail("Informe o diretório de destino.");
  const templateId = String(option("template", "product-shell"));
  const template = registry.templates.find(({ id }) => id === templateId);
  if (!template) return fail(`Template desconhecido: ${templateId}.`);
  if (!template.starter.endsWith(".html")) return fail(`O template ${templateId} ainda não possui starter executável.`);
  const mode = String(option("mode", template.mode));
  if (!registry.modes.some(({ id }) => id === mode)) return fail(`Modo inválido: ${mode}.`);

  const target = resolve(process.cwd(), requestedTarget);
  const force = args.includes("--force");
  if (!force && !(await isEmptyDirectory(target))) {
    return fail(`O destino não está vazio: ${target}. Use --force apenas se quiser sobrescrever os arquivos gerados.`);
  }

  await mkdir(target, { recursive: true });
  await Promise.all([
    cp(resolve(packageRoot, "assets"), resolve(target, "assets"), { recursive: true, force }),
    cp(resolve(packageRoot, "agent"), resolve(target, "agent"), { recursive: true, force }),
    cp(resolve(packageRoot, "design-system"), resolve(target, "design-system"), { recursive: true, force }),
    cp(resolve(packageRoot, "docs"), resolve(target, "docs"), { recursive: true, force }),
    cp(resolve(packageRoot, "styles"), resolve(target, "styles"), { recursive: true, force }),
    cp(resolve(packageRoot, "tokens"), resolve(target, "tokens"), { recursive: true, force }),
  ]);

  const executableTemplates = registry.templates.filter((item) => item.starter.endsWith(".html"));
  await mkdir(resolve(target, "starters"), { recursive: true });
  let selectedStarter = "";
  for (const item of executableTemplates) {
    const source = await readFile(resolve(packageRoot, item.starter), "utf8");
    await writeFile(resolve(target, item.starter), source, "utf8");
    if (item.id === templateId) {
      selectedStarter = source.replace(/((?:href|src)=["'])\.\.\//g, "$1./");
    }
  }
  await writeFile(resolve(target, "index.html"), selectedStarter, "utf8");

  const projectName = requestedTarget.split(/[\\/]/).filter(Boolean).at(-1)?.toLowerCase().replace(/[^a-z0-9-]+/g, "-") || "rn-app";
  const packageJson = {
    name: projectName,
    version: "0.1.0",
    private: true,
    type: "module",
    scripts: { dev: "vite --host 127.0.0.1", build: "vite build", preview: "vite preview --host 127.0.0.1" },
    devDependencies: { vite: "^7.1.1" },
  };
  const projectContract = {
    $schema: "./agent/schema.json",
    designSystem: "@rn-design/system",
    version: registry.meta.version,
    mode,
    template: templateId,
    override: template.override,
    quality: registry.quality,
  };

  await writeFile(resolve(target, "package.json"), `${JSON.stringify(packageJson, null, 2)}\n`, "utf8");
  await writeFile(resolve(target, "rn-design.json"), `${JSON.stringify(projectContract, null, 2)}\n`, "utf8");
  await writeFile(resolve(target, "RN-DESIGN.md"), `# Contrato RN Design\n\n- Modo: ${mode}\n- Template: ${templateId}\n- Override: ${template.override}\n- Versão: ${registry.meta.version}\n\nValide com \`rn-design audit . --strict\` antes de entregar.\n`, "utf8");

  console.log(paint("green", `Projeto RN criado em ${target}`));
  console.log(`Template ${templateId} · modo ${mode} · contrato rn-design.json`);
}

const sourceExtensions = new Set([".css", ".scss", ".sass", ".less", ".html", ".tsx", ".jsx", ".ts", ".js", ".vue", ".svelte"]);
const ignoredDirectories = new Set([".git", "node_modules", "dist", "build", "coverage", ".next", ".turbo", "lib"]);

async function sourceFiles(path) {
  const info = await stat(path);
  if (info.isFile()) return sourceExtensions.has(extname(path)) ? [path] : [];
  const files = [];
  for (const entry of await readdir(path, { withFileTypes: true })) {
    if (entry.name.startsWith(".") && entry.name !== ".storybook") continue;
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const child = resolve(path, entry.name);
    if (entry.isDirectory()) files.push(...await sourceFiles(child));
    else if (sourceExtensions.has(extname(entry.name))) files.push(child);
  }
  return files;
}

const auditRules = [
  { id: "raw-color", severity: "error", pattern: /#[0-9a-f]{3,8}\b/gi, message: "Cor literal encontrada; use token --rn-*.", suggestion: "Mapeie a cor para um token semântico de tokens/rn.css." },
  { id: "rgb-color", severity: "error", pattern: /\brgba?\s*\(/gi, message: "Cor rgb/rgba literal encontrada.", suggestion: "Use token semântico ou color-mix baseado em --rn-*." },
  { id: "clickable-div", severity: "error", pattern: /<(?:div|span)\b[^>]*\bonClick\s*=/gi, message: "Elemento não semântico clicável.", suggestion: "Use button ou link nativo." },
  { id: "outline-removed", severity: "error", pattern: /outline\s*:\s*(?:none|0)\b/gi, message: "Contorno de foco removido.", suggestion: "Use :focus-visible com --rn-color-focus." },
  { id: "transition-all", severity: "warning", pattern: /transition(?:-property)?\s*:\s*all\b/gi, message: "transition: all degrada previsibilidade e performance.", suggestion: "Liste apenas transform, opacity ou a propriedade de estado." },
  { id: "local-duration", severity: "warning", pattern: /(?:transition|animation)(?:-[\w-]+)?\s*:[^;{}]*(?:\d+ms|\d*\.\d+s)\b/gi, message: "Duração local de motion encontrada.", suggestion: "Use --rn-duration-* e --rn-ease-*." },
  { id: "clickable-cursor", severity: "warning", pattern: /cursor\s*:\s*pointer/gi, message: "Revise se o alvo usa elemento interativo nativo.", suggestion: "Prefira button/link; cursor sozinho não cria semântica." },
];

function lineAndColumn(source, index) {
  const before = source.slice(0, index);
  const lines = before.split("\n");
  return { line: lines.length, column: lines.at(-1).length + 1 };
}

async function collectFindings(target) {
  const files = await sourceFiles(target);
  const findings = [];
  for (const file of files) {
    const source = await readFile(file, "utf8");
    for (const rule of auditRules) {
      rule.pattern.lastIndex = 0;
      for (const match of source.matchAll(rule.pattern)) {
        const location = lineAndColumn(source, match.index ?? 0);
        findings.push({
          rule: rule.id,
          severity: rule.severity,
          file: relative(target, file) || file.split(/[\\/]/).at(-1),
          ...location,
          match: match[0].slice(0, 100),
          message: rule.message,
          suggestion: rule.suggestion,
        });
      }
    }
  }
  return { files, findings };
}

async function auditProject() {
  const target = resolve(process.cwd(), positional() ?? ".");
  if (!(await exists(target))) return fail(`Caminho não encontrado: ${target}.`);
  const result = await collectFindings(target);
  const payload = {
    designSystemVersion: registry.meta.version,
    target,
    scannedFiles: result.files.length,
    summary: {
      errors: result.findings.filter(({ severity }) => severity === "error").length,
      warnings: result.findings.filter(({ severity }) => severity === "warning").length,
    },
    findings: result.findings,
  };

  if (args.includes("--json")) console.log(JSON.stringify(payload, null, 2));
  else {
    console.log(`RN audit · ${payload.scannedFiles} arquivos · ${payload.summary.errors} erros · ${payload.summary.warnings} avisos`);
    for (const finding of result.findings) {
      const tone = finding.severity === "error" ? "red" : "yellow";
      console.log(`${paint(tone, finding.severity.toUpperCase())} ${finding.file}:${finding.line}:${finding.column} ${finding.rule}`);
      console.log(`  ${finding.message} ${paint("dim", finding.suggestion)}`);
    }
    if (result.findings.length === 0) console.log(paint("green", "Nenhuma violação heurística encontrada."));
  }

  if (payload.summary.errors > 0 || (args.includes("--strict") && payload.summary.warnings > 0)) process.exitCode = 1;
}

const safeColorMigrations = new Map([
  ["#0047ab", "var(--rn-color-primary)"],
  ["#40b7ff", "var(--rn-color-accent)"],
  ["#ffbb00", "var(--rn-color-warning)"],
  ["#111111", "var(--rn-color-heading)"],
  ["#ffffff", "var(--rn-color-surface)"],
]);

async function migrateProject() {
  const target = resolve(process.cwd(), positional() ?? ".");
  if (!(await exists(target))) return fail(`Caminho não encontrado: ${target}.`);
  const files = (await sourceFiles(target)).filter((file) => [".css", ".scss", ".sass", ".less"].includes(extname(file)));
  const changes = [];
  const write = args.includes("--write");

  for (const file of files) {
    const source = await readFile(file, "utf8");
    let migrated = source;
    for (const [literal, token] of safeColorMigrations) {
      const pattern = new RegExp(literal, "gi");
      const matches = migrated.match(pattern)?.length ?? 0;
      if (matches > 0) {
        migrated = migrated.replace(pattern, token);
        changes.push({ file: relative(target, file), from: literal, to: token, occurrences: matches });
      }
    }
    if (write && migrated !== source) await writeFile(file, migrated, "utf8");
  }

  const report = {
    designSystemVersion: registry.meta.version,
    target,
    mode: write ? "write" : "dry-run",
    safeChanges: changes,
    next: ["Execute rn-design audit <diretório> --strict.", "Revise spacing, radius, shadow, motion e semântica manualmente.", "Valide 375, 768, 1024 e 1440 pixels."],
  };
  const reportPath = option("report", null);
  if (typeof reportPath === "string") await writeFile(resolve(process.cwd(), reportPath), `${JSON.stringify(report, null, 2)}\n`, "utf8");
  console.log(JSON.stringify(report, null, 2));
}

async function showContract() {
  const id = positional();
  if (!id) return fail("Informe o ID do componente.");
  const contractIndex = JSON.parse(await readFile(resolve(packageRoot, registry.contracts.index), "utf8"));
  const entry = contractIndex.contracts.find((contract) => contract.id === id);
  if (!entry) return fail(`Componente desconhecido: ${id}.`);
  const contract = await readFile(resolve(packageRoot, "agent/contracts", entry.path), "utf8");
  console.log(contract.trim());
}

async function doctor() {
  const checks = [
    ["agent/index.json", resolve(packageRoot, "agent/index.json")],
    ["component contracts", resolve(packageRoot, registry.contracts.index)],
    ["tokens/rn.css", resolve(packageRoot, "tokens/rn.css")],
    ["styles/rn-base.css", resolve(packageRoot, "styles/rn-base.css")],
    ["styles/rn-components.css", resolve(packageRoot, "styles/rn-components.css")],
    ["React declarations", resolve(packageRoot, "lib/react/index.d.ts")],
  ];
  let healthy = true;
  for (const [label, path] of checks) {
    const ok = await exists(path);
    healthy &&= ok;
    console.log(`${ok ? paint("green", "✓") : paint("red", "×")} ${label}`);
  }
  console.log(`RN Design ${registry.meta.version} · Node ${process.version} · ${healthy ? "pronto" : "incompleto"}`);
  if (!healthy) process.exitCode = 1;
}

switch (command) {
  case "create": await createProject(); break;
  case "audit": await auditProject(); break;
  case "migrate": await migrateProject(); break;
  case "contract": await showContract(); break;
  case "doctor": await doctor(); break;
  case "help":
  case "--help":
  case "-h":
  case undefined: help(); break;
  default: fail(`Comando desconhecido: ${command}.`); help();
}
