# RN Design System — Master

Versão: **2.3.0**
Status: **fonte oficial para novos produtos RN Design & Serviços**
Idioma padrão: **pt-BR**
Stack de referência: **Web responsiva; exemplos React + TypeScript**

Este arquivo é a fonte de verdade. Para uma tela específica, leia primeiro este Master e depois, se existir, o arquivo correspondente em `pages/`. O override pode restringir o Master, nunca trocar branding, tokens ou requisitos de acessibilidade.

## 1. Identidade em uma frase

**O DNA visual do orçamento aplicado a todo produto RN:** Montserrat, azul-celeste, escala editorial, grid, wordmark, capítulos de alto contraste e movimento com propósito — reduzidos com disciplina quando a interface é operacional.

A página do orçamento é a fonte visual primária. Leia [`docs/DESIGN-DNA.md`](../../docs/DESIGN-DNA.md) para a hierarquia completa; o RN Mail é referência secundária somente para comportamento Product.

## 2. Princípios inegociáveis

1. **Clareza antes do espetáculo.** O usuário deve entender conteúdo, estado e próxima ação sem depender de animação.
2. **Tecnologia com propósito.** IA, motion, glow e efeitos aparecem para explicar, orientar ou reforçar valor — nunca como enfeite gratuito.
3. **Uma estética, duas intensidades.** `Product` e `Expressive` derivam da página do orçamento. Product reduz escala e motion; não troca a identidade por um dashboard genérico.
4. **Dados pedem calma.** Tabelas, formulários, listas e leitura usam superfícies claras, bordas frias e baixa ornamentação.
5. **A marca é reconhecível sem o logo.** Montserrat, celeste/ciano, grid, palavra destacada, pills, linhas de progresso, um ponto focal e ritmo amplo formam a assinatura.
6. **Acessibilidade faz parte do componente.** Teclado, foco, estados, contraste, texto alternativo e redução de movimento não são opcionais.

## 3. Como escolher o modo

| Pergunta | Product | Expressive |
|---|---|---|
| O usuário volta diariamente para trabalhar? | Sim | Não é o foco |
| Há tabelas, formulários, filtros ou grandes listas? | Sim | Apenas como trecho demonstrativo |
| O objetivo principal é explicar, vender ou apresentar? | Pode apoiar | Sim |
| Motion permitido | Feedback e transições curtas | Narrativa, reveal e parallax moderado |
| Superfície dominante | Branco | Hero branco; capítulos brancos e carvão prescritos pela narrativa |
| Densidade | Média ou compacta | Espaçosa |

Na dúvida sobre intensidade, use **Product**, mas preserve o DNA do orçamento. Nunca use motion Expressive dentro de tabela, formulário crítico, tela de operação intensa ou fluxo de erro.

Overrides oficiais:

- [`product-interface.md`](pages/product-interface.md)
- [`expressive-experience.md`](pages/expressive-experience.md)
- [`auth.md`](pages/auth.md)
- [`data-dashboard.md`](pages/data-dashboard.md)

Quando o pedido citar o “front do orçamento”, a composição canônica está em [`docs/BUDGET-FRONT-REFERENCE.md`](../../docs/BUDGET-FRONT-REFERENCE.md) e na implementação executável em `src/`. Mesmo quando o pedido não citar, essa página continua sendo a referência visual dominante.

## 4. Assinatura visual

### 4.1 Marca

- Logo completo: `assets/brand/rn-logo.png`, 821×400, transparência preservada.
- Ícone vetorial: `assets/brand/rn-icon.svg`, viewBox 384×384 e nove paths independentes; `rn-icon.png` permanece como referência raster.
- Fonte: `assets/fonts/montserrat.woff2`, variável 100–900.
- Motivos opcionais: `assets/motifs/rn-glow.svg` e `assets/motifs/rn-pixels.svg`.
- Gradiente visual recorrente: azul suave → sky → ciano.
- Use sempre a arte oficial colorida sobre branco, sem distorção ou recoloração.

Regras de uso completas em [`docs/BRAND-ASSETS.md`](../../docs/BRAND-ASSETS.md).

### 4.2 Background e composição

A composição principal é `rn-story-hero`, extraída do orçamento:

- hero branco com grid sky de 160×180px a aproximadamente 3,5%;
- wordmark RN DESIGN de 84–212px, peso 800;
- ícone oficial de 84–172px;
- halo e orbitais de 120/360px;
- layout assimétrico 920/432px, gap 88px, container 1440px;
- título 64–80px, peso 500, tracking −0,045em;
- chips, progress line e handoff.

Experiências narrativas alternam `rn-story-scene` light, dark, stage e deep seguindo a cadência do orçamento.

Todo app Product usa canvas branco. Sua região principal de identidade pode aplicar a composição derivada `rn-brand-canvas`:

- grid sky a 3–6%; 40px em Product e 160×180px em Expressive;
- símbolo RN grande no topo direito, até 608px e 6% de opacidade;
- símbolo RN menor no canto inferior esquerdo, até 120px e 14% de opacidade;
- halo radial celeste opcional, sempre translúcido;
- conteúdo acima da atmosfera, com contraste medido e zona segura.

As duas marcas são decorativas e não entram na árvore de acessibilidade. Em mobile, reduza a escala e aumente o recorte da marca grande; preserve a assinatura. Especificação completa em [`docs/VISUAL-GRAMMAR.md`](../../docs/VISUAL-GRAMMAR.md).

A alternância do orçamento é a expressão completa do sistema, não uma estética paralela. Isso não autoriza dark mode nem superfícies escuras atrás de dados densos em Product.

### 4.3 Paleta primária

| Papel | Valor | Uso |
|---|---:|---|
| Navy profundo | `#04101D` | Scrim, contraste e capítulos prescritos do orçamento; nunca canvas Product |
| Charcoal | `#202020` | Objetivo e capítulos narrativos |
| Stage | `#1A1D1D` | Showcase de devices e prova visual |
| Deep | `#16191C` | Telas, processo, FAQ e fechamento |
| Ink | `#07141F` | Texto de maior contraste, `on-accent` |
| Navy | `#0A2540` | Headings e texto institucional; nunca fundo de seção |
| Azul profundo | `#14538C` | Link hover e texto colorido acessível |
| Azul RN | `#1A6FAE` | Links e texto colorido sobre branco |
| Sky / azul-celeste | `#47ABE1` | Ação primária, estado ativo, ícone e gradiente |
| Azul suave | `#5A9AEE` | Gradiente e ilustração; evitar como texto pequeno |
| Ciano | `#3FD0E9` | Acento, glow e detalhes; não é o único indicador de foco |
| Focus | `#14538C` | Outline acessível sobre canvas e superfícies claras |
| Control border | `#617987` | Limite essencial de campos e controles |
| Branco | `#FFFFFF` | Canvas obrigatório de Product e abertura dos fluxos Story |
| Neutros 50–100 | `#F8FBFD` / `#F4F8FB` | Agrupamentos locais e controles; nunca o canvas global |

Use os tokens de `tokens/rn.css`; hex direto só pode existir nos próprios arquivos de tokens.

### 4.4 Pares de contraste verificados

| Primeiro plano | Fundo | Relação |
|---|---|---:|
| `#07141F` | `#FFFFFF` | 18.60:1 |
| `#102A3D` | `#FFFFFF` | 14.78:1 |
| `#526B7A` | `#FFFFFF` | 5.61:1 |
| `#617987` | `#FFFFFF` | 4.57:1 |
| `#07141F` | `#47ABE1` | 7.25:1 |
| `#07141F` | `#3FD0E9` | 10.11:1 |
| `#1A6FAE` | `#FFFFFF` | 5.35:1 para links e texto colorido |
| `#F3F3F3` | `#202020` | 14.68:1 em capítulos Story |
| `#989898` | `#202020` | 5.65:1 para copy sutil Story |
| `#F3F3F3` | `#1A1D1D` | 15.29:1 em stage |
| `#989898` | `#16191C` | 6.12:1 em deep |

Não use texto branco sobre o azul-celeste. A combinação oficial de ação primária é ink `#07141F` sobre `#47ABE1`, com relação 7.25:1. Para links e texto colorido sobre branco, use `#1A6FAE`, não o celeste puro.

### 4.5 Cores semânticas

- `primary`: ação principal e estado ativo; uma ação primária por tela ou região decisória.
- `link`: azul RN `#1A6FAE` para manter contraste sobre branco.
- `accent`: detalhes e indicação ativa; no fundo ciano use texto `ink`.
- `focus`: outline de interação; `control-border`: limite essencial de campos.
- `success`, `warning`, `danger`: reservadas para estado; sempre acompanhadas por texto/ícone.
- `surface`, `surface-soft`, `surface-muted`: criam hierarquia sem excesso de sombra.
- `text`, `text-subtle`, `text-muted`: `muted` é o limite mínimo para texto normal; não reduza opacidade arbitrariamente.

O único tema oficial está em `tokens/rn.css`: canvas branco. Não responda a `prefers-color-scheme` mudando as cores da marca e não crie mapas escuros por produto. As cenas escuras da proposta são composição editorial fixa, não tema.

## 5. Tipografia

### Família

Use **Montserrat RN** em toda a experiência. Não combine com serifas ou outra família apenas para “dar personalidade”; a personalidade vem da escala, peso, composição e motion.

### Pesos

- 400: corpo e leitura longa.
- 500: label, navegação e texto de apoio com ênfase.
- 650: títulos de componente, botões e headings padrão.
- 700: destaque forte, eyebrow e números importantes.
- 800: wordmark RN e somente grandes momentos de marca.

### Escala

| Papel | Tamanho de referência | Line-height |
|---|---:|---:|
| Wordmark RN | 84–212px | 0.94 |
| Hero Story | 64–80px | 1.14 |
| Caption | 12px | 1.45 |
| Label | 13px | 1.4 |
| Body small | 14px | 1.55 |
| Body | 16px | 1.60 |
| Body large | 18px | 1.60 |
| Title | 20px | 1.35 |
| Heading small | 24px | 1.25 |
| Heading | 32px | 1.18 |
| Display small | 40px | 1.10 |
| Display | 56px | 1.08 |
| Display large | 72px | 1.05 |
| Display XL Product | 96px | 0.98 |

Regras:

- Corpo mobile nunca menor que 16px em inputs e leitura principal.
- Hero Story usa tracking `-0.045em`; headings usam `-0.02em` a `-0.035em`; corpo usa tracking normal.
- Eyebrow pode usar uppercase, 12px, peso 700 e tracking `0.12em`.
- Preços, métricas e tabelas usam `font-variant-numeric: tabular-nums`.
- Parágrafos ficam entre 45 e 75 caracteres por linha; container de leitura: 720px.
- Headings curtos podem usar `text-wrap: balance`; não force quebras com espaços não separáveis.
- Use `rn-story-wordmark`/`rn-story-title` em experiências derivadas do orçamento e `rn-display`/`rn-title` em Product; não crie escalas locais por página.

## 6. Espaçamento, forma e elevação

### Espaçamento

Escala: `0, 4, 8, 12, 16, 24, 32, 40, 48, 64, 80, 96, 128px`.

- Dentro de controles: 8–16px.
- Entre label e campo: 8px.
- Entre componentes relacionados: 16–24px.
- Entre blocos de uma seção Product: 32–64px.
- Entre capítulos Expressive: 80–128px.

### Raios

- 6px: elementos mínimos.
- 8px: navegação e itens compactos.
- 12px: controle padrão.
- 16px: card padrão, diálogo compacto.
- 24px: card hero, login e modal de destaque.
- 32px: cenas Expressive.
- Pill: badges, chips e botões que pedem linguagem de cápsula.

Não misture mais de três níveis de raio na mesma tela.

### Elevação

- `xs`: separação de superfície.
- `sm`: hover e menu pequeno.
- `md`: card elevado e dropdown.
- `lg`: modal, login, cena de proposta.
- `brand`: ação primária.

Antes de adicionar sombra, tente hierarquia por superfície e borda. Interfaces Product devem parecer calmas.

## 7. Layout e responsividade

### Breakpoints canônicos

- `compact`: `< 600px`, 4 colunas.
- `medium`: `600–899px`, 8 colunas.
- `wide`: `900–1199px`, 12 colunas.
- `desktop`: `1200–1499px`, 12 colunas.
- `large`: `≥ 1500px`, 12 colunas com limite de container.

Os projetos legados usam 600, 900, 1150 e 1500px. Em novos apps use os tokens 600, 900, 1200 e 1500px; ao editar uma tela legada preserve seu breakpoint até a refatoração completa.

### Containers

- Leitura: 720px.
- Produto: 1200px.
- Experiência ampla: 1440px.
- Gutter: `clamp(18px, 4vw, 48px)`.

### Regras

- Mobile first e sem scroll horizontal.
- 4 colunas no mobile, 8 no tablet, 12 no desktop.
- `minmax(0, 1fr)` em grids e `min-width: 0` em filhos com texto.
- Touch target mínimo de 44×44px; alvos adjacentes separados por pelo menos 8px.
- Sticky header reserva espaço e usa `scroll-padding-top`.
- Em mobile, conteúdo principal vem antes de ilustração e adornos.
- Valide em 375, 768, 1024 e 1440px; valide também landscape.

## 8. Componentes

A especificação detalhada está em [`docs/COMPONENT-SPECS.md`](../../docs/COMPONENT-SPECS.md). Implementação CSS de referência: `styles/rn-components.css`.

Inventário mínimo para todo app:

- Button: primary, accent, secondary, ghost, danger, icon, loading e disabled.
- Field: label visível, helper, erro inline, required e read-only.
- Select, textarea, checkbox/radio e upload.
- Search, combobox/autocomplete e date/time picker.
- Card: base, soft, raised, glass, brand e interactive.
- Brand Canvas: product, editorial e quiet; background branco com grid e duas marcas de canto.
- Story Hero: wordmark, orbitais, grid editorial, conteúdo 2/3 + 1/3 e handoff.
- Animated Wordmark: `RN DESIGN` sobe letra por letra sem giro ou deslocamento lateral; depois o símbolo oficial monta seus nove paths e encerra no lockup estático. Use `hero`, `showcase`, `panel` ou `compact` conforme a superfície; a escala monumental não vaza para previews.
- Brand Loader: **Montagem com impacto — 01** é a única variante pública; `xl` fica reservado a splash screen, troca de contexto e palco de marca.
- Story Scene: light, dark, stage e deep; container 1278px e um ponto focal.
- Story Navigation/Progress: logo, linha de leitura e até três âncoras.
- Capability Chips, Media Frame, Story Split e Story Ticket.
- Chip/badge: neutral, brand, success, warning, danger.
- Alert, toast, error summary e empty state.
- Topbar, sidebar, nav link, breadcrumb e tabs.
- List item, table, pagination e skeleton.
- Dialog, drawer, popover e menu.
- Accordion/FAQ.
- KPI, data display e visualização de dados com tabela/resumo equivalente.

Estados obrigatórios: `default`, `hover`, `focus-visible`, `active/pressed`, `disabled`, `loading`; quando aplicável `selected`, `expanded`, `invalid`, `read-only`, `empty`, `error` e `success`.

## 9. Ícones

- Família primária: **Phosphor Outline**, peso `regular`.
- Fallback: **Heroicons Outline**, sem misturar famílias na mesma superfície.
- Tamanhos: 16, 20, 24 e 32px.
- Stroke visual: aproximadamente 1.5–2px.
- Ícone decorativo ao lado de texto: `aria-hidden="true"`.
- Controle só com ícone: nome acessível obrigatório e estado (`aria-pressed`, `aria-expanded`) quando necessário.
- Não use emoji como ícone estrutural.
- Diferencie símbolo de marca de ícone funcional: o símbolo RN compõe o background; Phosphor/Material Symbols comunicam ações.

Detalhes em [`docs/ICONOGRAPHY.md`](../../docs/ICONOGRAPHY.md).

## 10. Movimento

### Tokens

- 100ms: feedback instantâneo.
- 160ms: hover, press, seleção.
- 240ms: expansão simples, troca de estado.
- 420ms: entrada de card/seção curta.
- 580ms: cortina/entrada de página.
- 650ms: reveal de copy/card.
- 720ms: cena Expressive.
- 820ms: heading/ticket e handoff de capítulo.
- 920ms: contagem de valor.
- Easing de entrada: `cubic-bezier(0.22, 1, 0.36, 1)`.
- Easing enfático: `cubic-bezier(0.16, 1, 0.3, 1)`.

### Product

- Anime transform e opacity, nunca layout como primeira opção.
- Feedback deve iniciar em até 100ms.
- Listas densas não usam overshoot, tilt, parallax ou brilho recorrente.
- Use no máximo um movimento de entrada relevante por view.

### Expressive

- Scroll storytelling é permitido se a ordem do DOM continuar completa e legível.
- Stagger de 30–50ms por item; não exceder 6 itens em sequência. A única exceção é o wordmark oficial, que usa as oito letras de `RN DESIGN` e `--rn-stagger-wordmark`.
- Parallax sutil, sem bloquear scroll e desativado em `prefers-reduced-motion`.
- Animação não pode ser necessária para revelar informação ou habilitar ação.
- Conteúdo termina em estado final correto mesmo se a animação for interrompida.
- A abertura oficial executa uma vez por fluxo: letras no eixo vertical → montagem do símbolo → lockup estático. Replay somente por ação explícita.
- Loading contínuo oferece pausa no demonstrador, mantém status textual e encerra assim que o resultado da operação chega.

### Redução de movimento

Com `prefers-reduced-motion: reduce`, remova loop, scrub, tilt, parallax e deslocamento amplo; renderize o conteúdo já visível. Transições funcionais podem virar fade quase instantâneo.

## 11. Conteúdo e voz

Voz RN: direta, segura, próxima e orientada a resultado.

- Fale com “você”; explique impacto antes da tecnologia.
- Use verbos ativos: “Criar proposta”, “Salvar alterações”, “Tentar novamente”.
- Erros dizem causa + solução.
- Evite “revolucionário”, “mágico” e promessas vagas.
- IA aparece como ferramenta aplicada a valor real, não como adereço.
- Headings podem combinar uma frase neutra com uma palavra de ênfase em azul.
- Taglines aprovadas: “Design • Desenvolvimento • IA” e “Onde ideias se transformam em inovação”.

Detalhes em [`docs/CONTENT-VOICE.md`](../../docs/CONTENT-VOICE.md).

## 12. Acessibilidade

Meta mínima: **WCAG 2.2 AA**.

- Contraste 4.5:1 para texto normal, 3:1 para texto grande e componentes gráficos relevantes.
- Foco visível de 3px com offset; sticky UI não pode ocultá-lo.
- Ordem de tab corresponde à ordem visual/DOM.
- Campos têm label visível e erros associados por `aria-describedby`.
- Formulário com múltiplos erros mostra summary focável e links para campos, preservando erro inline.
- Hover nunca é o único meio de descoberta; toda ação funciona com teclado e touch.
- Imagens significativas têm alt; imagem decorativa usa alt vazio.
- Movimento automático pausa em foco/reduced motion; loops precisam de controle quando competem com conteúdo.
- Zoom do navegador não pode ser desativado.
- Rotas movem foco para o conteúdo principal sem perder contexto.

Checklist completo em [`docs/ACCESSIBILITY.md`](../../docs/ACCESSIBILITY.md).

## 13. Direção de arte assistida

Artes, campanhas, posts, capas, banners, imagens e vídeo usam `agent/art-direction.json`, `agent/create-art.md` e `agent/prompts/create-brand-art.md`.

- O agente gera a imagem-base sem texto, logo ou aproximação do símbolo.
- A composição final aplica Montserrat RN e assets de `assets/` deterministicamente.
- Um ponto focal, safe area, direitos, alt text, negative prompt e proveniência são obrigatórios.
- `Expressive` é a direção padrão de campanha; `Product/quiet` atende peças informacionais densas.
- Revisão humana antecede publicação.

Detalhes em [`docs/ART-DIRECTION.md`](../../docs/ART-DIRECTION.md).

## 14. Contrato para agentes de IA

Ao criar ou alterar um app RN Design, o agente deve seguir esta ordem:

1. Ler `agent/index.json` para rotear a tarefa.
2. Ler este `MASTER.md` e o override aplicável em `pages/`.
3. Ler `docs/DESIGN-DNA.md`; em Expressive, ler também `docs/BUDGET-FRONT-REFERENCE.md` e `docs/VISUAL-GRAMMAR.md`.
4. Identificar `Product` ou `Expressive` apenas para calibrar intensidade.
5. Selecionar o template estável mais próximo e consultar `agent/contracts/components/<id>.json` para cada componente.
6. Importar `tokens/rn.css` antes de base e componentes.
7. Preferir os exports de `@rn-design/system/react`; em HTML, reutilizar as classes canônicas `rn-*`.
8. Usar somente assets oficiais de `assets/`/`public/assets/`.
9. Montar a tela com semântica e conteúdo real antes de aplicar motion.
10. Implementar todos os estados declarados nos contratos e a responsividade.
11. Verificar teclado, focus-visible, contraste, axe e reduced motion.
12. Testar 375, 768, 1024 e 1440px.
13. Registrar qualquer novo token em `tokens/rn.css`, rodar `npm run tokens:sync` e regenerar contratos quando necessário.
14. Executar `rn-design audit`, `npm run agent:check` e `npm run audit` quando trabalhar neste repositório.

Proibições:

- Não introduzir outra fonte sem decisão explícita de rebranding.
- Não usar gold/beige como assinatura “premium”.
- Não inventar logo, símbolo, mascote ou variação cromática.
- Não usar glassmorphism em dados densos.
- Não usar ciano como texto pequeno sobre branco.
- Não usar animação para esconder conteúdo até o scroll em reduced motion.
- Não construir controles primários com `div` sem semântica.
- Não usar raw hex, shadow, radius ou spacing em componentes novos.

## 15. Definition of Done

- [ ] Modo Product/Expressive escolhido e coerente.
- [ ] A tela parece uma extensão do orçamento, não um template genérico.
- [ ] `docs/DESIGN-DNA.md` foi usado como regra de desempate.
- [ ] Assets oficiais, Montserrat e tokens importados.
- [ ] Canvas Product branco e sem tema escuro; capítulos carvão seguem os scene tokens em experiências narrativas.
- [ ] Background RN com grid, símbolo grande no topo direito e pequeno no canto inferior esquerdo.
- [ ] Azul-celeste aplicado como cor primária com texto ink.
- [ ] Sem valores visuais arbitrários fora dos tokens.
- [ ] Uma ação primária por tela/região decisória.
- [ ] Estados completos de todos os componentes.
- [ ] Contratos individuais consultados e critérios de aceite atendidos.
- [ ] Contraste AA e foco visível verificados.
- [ ] Teclado e touch funcionam sem depender de hover/gesto.
- [ ] Reduced motion mantém conteúdo completo e operável.
- [ ] Layout validado em 375, 768, 1024 e 1440px, além de landscape.
- [ ] Sem scroll horizontal e sem conteúdo sob sticky UI.
- [ ] Imagens têm dimensões/aspect-ratio e lazy loading fora do hero.
- [ ] Erros explicam como recuperar; loading bloqueia reenvio duplicado.
- [ ] Textos seguem a voz RN.
- [ ] Testes Playwright/axe e regressão visual passam nos quatro viewports.
- [ ] Validação do repositório passa sem erros.

## 15. Governança

Tokens, componentes e breaking changes seguem SemVer, processo de revisão e sincronização descritos em [`docs/GOVERNANCE.md`](../../docs/GOVERNANCE.md). Um token novo entra no CSS canônico e seus manifestos JSON, JS e TS gerados precisam estar sincronizados no mesmo change set.
