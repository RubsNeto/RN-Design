# Override — Authentication

Use para login, recuperação, criação de senha e MFA.

## Layout

- Abertura branca derivada do hero do orçamento: grid, halo e orbitais em intensidade baixa.
- Wordmark compacto acima do card; nunca substitua Montserrat/celeste por estética genérica de login.
- Card central de até 520px, raio 24px, fundo branco e halo/grid azul-celeste muito sutil.
- Logo completo centralizado; descrição curta antes do formulário.
- Mobile mantém pelo menos 18px de gutter e inputs de 48px quando possível.

## Formulário

- Labels visíveis; placeholder apenas como exemplo.
- `autocomplete` correto: `username`, `current-password`, `new-password`, `one-time-code`.
- Permitir colar, password managers e revelar senha.
- Submit entra em loading, fica disabled e não apaga os valores em erro.
- Erro explica o problema sem revelar se uma conta específica existe.

## Conteúdo

- Eyebrow: `WEBMAIL RN DESIGN` ou nome do produto.
- Slogan opcional: `Onde ideias se transformam em inovação`.
- Texto de apoio direto: o que o usuário acessará após entrar.

## Motion

Uma entrada do wordmark + card de até 720ms é permitida; controles continuam disponíveis imediatamente. Reduced motion remove deslocamento, blur, scan, ribbons e halo pulsante.

## Segurança e acessibilidade

Não bloquear paste, não exigir memorização cognitiva como único método, não usar CAPTCHA visual sem alternativa, manter foco claro e mensagens associadas aos campos.
