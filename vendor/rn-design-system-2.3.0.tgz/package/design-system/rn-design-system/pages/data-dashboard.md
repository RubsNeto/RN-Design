# Override — Data Dashboard

Use para dashboards analíticos, relatórios, operação e monitoramento.

## Hierarquia

1. Título, período e ação principal.
2. KPIs essenciais, no máximo 4 por linha.
3. Insight/tendência.
4. Gráficos e tabela detalhada.
5. Estado, fonte e atualização dos dados.

## Visual

- O page header traduz o orçamento em baixa intensidade: título Montserrat com uma expressão azul, linha/handoff, filtros em pill e grid quiet opcional.
- Superfícies claras, borda fria e sombra `xs`.
- Números usam tabular nums.
- Grid e gradiente nunca competem com os dados.
- Ciano e azul destacam série principal; séries adicionais usam tons com contraste e forma/linha distinta.
- Vermelho e verde nunca são o único canal de significado.
- Não herde a estética do SOGo/Mailcow; herde apenas seus padrões de densidade e comportamento.

## Gráficos

- Linha para tendência, barra para comparação, donut apenas com até cinco categorias.
- Eixos, unidade, legenda e tooltip acessível obrigatórios.
- Forneça tabela ou resumo textual equivalente.
- Em mobile reduza ticks e reflow; não faça o gráfico vazar horizontalmente.

## Tabelas

- Header sticky somente se não ocultar foco.
- Ordenação anuncia `aria-sort`.
- 50+ linhas: paginação ou virtualização; preserve contexto de filtros.
- Estados loading, empty e error têm conteúdo e ação de recuperação.

## Motion

Sem overshoot. Entrada de dados é opcional, curta e removida em reduced motion. Atualizações não movem foco; anuncie mudanças relevantes em região live apropriada.
