# Override — Expressive Experience

Use para propostas, landing pages, portfólio, onboarding e apresentações de alto impacto. Esta é a expressão completa do DNA visual primário do sistema.

## Direção

- A referência principal é o front do orçamento: hero branco e alternância deliberada entre capítulos brancos e carvão.
- O hero principal usa `rn-story-hero`: grid 160×180px, wordmark monumental, ícone, halo e orbitais. `rn-brand-canvas--editorial` é uma redução alternativa.
- Display Montserrat de 40–72px; em hero especial pode exceder 72px com `clamp`, sem comprometer mobile.
- Grid fino, glow radial, pixels, pills e wordmark em escala são as assinaturas visuais.
- Espaçamento de capítulo: 80–128px.

## Narrativa

Intro hook → problema/contexto → solução → evidência/processo → investimento/decisão → CTA final.

O DOM deve conter a narrativa completa na ordem correta. Motion melhora a leitura, não cria conteúdo.

Para reprodução fiel, leia [`docs/BUDGET-FRONT-REFERENCE.md`](../../../docs/BUDGET-FRONT-REFERENCE.md) e use `src/pages/ProposalPage.tsx`. A tela de convite/cartão não faz parte do fluxo canônico do System Design.

## Motion

- Entrada 420–720ms, easing emphasized.
- Stagger 30–50ms, máximo de seis elementos por grupo.
- ScrollTrigger/GSAP permitido quando o conteúdo permanece legível sem JavaScript.
- Parallax e tilt desativados para pointer coarse ou reduced motion.
- Loops decorativos suaves precisam pausar quando fora da viewport.

## CTA

Uma mini CTA pode encerrar cada capítulo; o clímax contém a ação principal. CTA nunca depende de hover ou cursor customizado.

## Evitar

Serifas “luxury”, dourado, glass opaco sem contraste, cenas que bloqueiam scroll, texto cinza sobre fundo visual e animações acima de dados/preços.
