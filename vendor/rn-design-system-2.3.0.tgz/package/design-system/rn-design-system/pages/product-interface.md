# Override — Product Interface

Product é uma redução operacional do orçamento, não uma estética independente. Preserve Montserrat, celeste, grid, pills, linhas finas, palavra destacada e um ponto focal; reduza escala, capítulos escuros e motion conforme a tarefa.

Use para SaaS, ERP, CRM, portais, áreas administrativas e ferramentas internas.

## Direção

- Tema único e obrigatório: canvas branco, sem dark mode.
- Superfícies brancas; neutros azulados muito claros apenas para agrupamentos locais. Azul-celeste identifica ações e estados ativos.
- Use `rn-brand-canvas--quiet` apenas no page header, empty state ou área de leitura vazia: grid 40px, marca grande no topo direito e pequena no canto inferior esquerdo.
- Densidade média. Cards só quando agrupam uma unidade conceitual; listas e tabelas permanecem planas.
- Grid, glow e pixel motif aparecem apenas em login, empty state, onboarding ou leitura vazia.

## Layout

- Desktop ≥1024px: sidebar para navegação persistente; topbar para contexto e ações.
- Mobile: topbar + drawer ou bottom nav com no máximo cinco destinos de primeiro nível.
- Área de conteúdo: até 1200px; formulários: 720px ou menos.
- Topbar de 64px; sidebar de 216px em desktop; controles de 40–44px; linhas principais de 52px.
- Uma ação primária por tela. Ações destrutivas ficam separadas.

## Motion

- 100–240ms para estados; até 420ms em entrada de view.
- Sem parallax, tilt ou loop decorativo em áreas de trabalho.
- Skeleton somente quando a espera esperada passa de aproximadamente 1s.

## Componentes preferidos

Topbar, sidebar, breadcrumb, tabs, list item, table, filters, field, dialog, drawer, toast, alert, empty state e KPI.

## Evitar

Glass em tabela, card dentro de card, gradiente em todas as ações, sombras grandes, conteúdo escondido até scroll e ícones sem label em navegação principal.
