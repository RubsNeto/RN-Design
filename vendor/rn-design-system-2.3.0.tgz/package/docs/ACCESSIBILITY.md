# Acessibilidade e qualidade

Alvo mínimo: **WCAG 2.2 AA**. O sistema fornece defaults, mas cada produto precisa validar a composição real.

## Contraste

- Texto normal: ≥4.5:1.
- Texto grande: ≥3:1.
- Indicador de foco, ícones significativos e bordas de controle: ≥3:1 contra cores adjacentes.
- Não reduza opacidade de `text-muted` ou aplique-o sobre glass sem recalcular.
- Ciano/sky recebem texto `ink`. Links azul RN aparecem sobre branco. Em capítulos Story, use somente os scene tokens com `on-scene`; não improvise superfícies escuras para acomodar texto inverso.
- Texto colorido pequeno sobre branco usa `--rn-color-brand-text` (`#1A6FAE`, 5.35:1), nunca sky puro.
- Bordas essenciais de input usam `--rn-color-control-border` (`#617987`, 4.57:1 contra branco).
- Pares Story verificados: `on-scene`/charcoal 14.68:1, `on-scene-muted`/charcoal 5.65:1, `on-scene`/stage 15.29:1 e `on-scene-muted`/deep 6.12:1.
- Estado nunca depende apenas de cor.

## Teclado

- Ordem de tab segue DOM e hierarquia visual.
- Todos os controles funcionam com teclado.
- Nunca use `tabindex` positivo.
- Menus, tabs, comboboxes e dialogs seguem o padrão ARIA correspondente.
- Escape fecha overlays quando seguro.
- Ao fechar modal/drawer, devolva foco ao trigger.
- Rotas movem foco para heading/main com anúncio de contexto.
- Sticky header/footer não pode cobrir o foco; use `scroll-padding`/`scroll-margin`.

## Focus visible

O padrão RN é outline de 3px com `--rn-color-focus` (`#14538C`, 7.94:1 contra branco) e 3px de offset. O ciano permanece como acento visual, não como único indicador de foco. Não remova sem substituição de contraste equivalente.

Teste foco em:

- fundo branco e superfícies azuladas muito claras;
- card brand e card glass;
- dentro de modal/drawer;
- primeiro e último item de uma região rolável;
- zoom 200%.

## Formulários

- Label visível com `for`/`id`.
- Required indicado em texto/legenda e atributo semântico.
- Helper e erro conectados por `aria-describedby`.
- `aria-invalid="true"` somente após validação relevante.
- Valide em blur/submit; não acuse erro a cada tecla.
- Erro diz causa e forma de corrigir.
- Submit loading fica disabled para evitar duplicidade.
- Preserve valores e erros depois de falha.
- Múltiplos erros: summary focável + links para campos + erros inline.
- Use `autocomplete`, `inputmode` e tipos adequados.
- Autenticação permite colar e password manager.

## Imagens e ícones

- Logo linkado: alt com nome da marca/ação; evite repetir texto vizinho.
- Imagem significativa: alt descreve conteúdo/função, não “imagem de”.
- Imagem decorativa: `alt=""` e, se SVG inline, `aria-hidden="true"`.
- Ícone ao lado de label visível é decorativo.
- Icon button tem nome acessível e estados (`pressed`, `expanded`, `current`) quando aplicável.

## Motion

Com `prefers-reduced-motion: reduce`:

- conteúdo nasce visível;
- desative parallax, tilt, scroll scrub, marquee, cursor follower e loops;
- substitua deslocamentos grandes por fade quase instantâneo;
- preserve feedback funcional sem causar espera;
- auto-rotating content para em foco/reduced motion e oferece pause.

Toda animação deve ser interrompível e nunca ser requisito para ação ou compreensão.

## Touch e responsive

- Alvo mínimo web/native compartilhado: 44×44px; use 48px quando o contexto é primariamente touch.
- Separe alvos por pelo menos 8px.
- Não dependa de hover.
- Não desabilite zoom.
- Sem scroll horizontal em 320–375px, exceto tabela dentro de wrapper identificado.
- Não esconda conteúdo sob bottom bar, teclado ou safe area.
- Texto cresce até 200% sem perda de função; teste também maior configuração do sistema em app nativo.

## Dados e gráficos

- Gráfico tem título, unidade, legenda e resumo textual.
- Informação relevante possui tabela ou alternativa acessível.
- Tooltip é alcançável por teclado/touch.
- Séries diferem por forma/linha/padrão, não apenas cor.
- `aria-sort` anuncia ordenação de tabela.
- Atualizações de status usam live region contextual sem mover foco.

## Matriz manual mínima

| Área | Verificação |
|---|---|
| Teclado | Tab, Shift+Tab, Enter, Space, Escape e setas quando aplicável |
| Foco | Visível, não encoberto, restaurado após overlay |
| Leitor de tela | Headings, landmarks, labels, estados e mensagens |
| Zoom | 200% desktop e reflow até 320 CSS px |
| Motion | Reduced motion e animação interrompida no meio |
| Responsive | 375, 768, 1024, 1440 e landscape |
| Contraste | Canvas branco, superfícies claras e todos os estados medidos |
| Form | Empty, invalid, loading, server error e success |

## Automação recomendada

- ESLint jsx-a11y ou equivalente.
- axe-core em testes de componente/e2e.
- Playwright para fluxo de teclado e screenshots.
- Lighthouse como sinal complementar, não como substituto de teste manual.
- Teste de contraste para tokens e estados principais.

Neste repositório, `npm run test` mede automaticamente os pares canônicos de texto, foco e bordas de controle. Testes manuais e axe continuam obrigatórios no app consumidor, porque a composição final pode criar pares novos.

## Checklist de entrega

- [ ] Um `h1` claro e hierarquia de heading sem saltos arbitrários.
- [ ] Landmarks `header`, `nav`, `main`, `aside`, `footer` quando aplicáveis.
- [ ] Skip link em apps com navegação persistente.
- [ ] Foco visível e teclado completo.
- [ ] Contraste medido sobre branco e sobre cada superfície clara usada.
- [ ] Form labels, helpers e errors ligados.
- [ ] Alt/aria corretos e sem anúncio duplicado.
- [ ] Reduced motion funcional.
- [ ] Touch targets e spacing adequados.
- [ ] Loading, empty, error e success compreensíveis.
- [ ] Sem conteúdo oculto por sticky/fixed UI.
