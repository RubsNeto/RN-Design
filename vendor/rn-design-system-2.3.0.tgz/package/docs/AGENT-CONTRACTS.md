# Contratos para agentes

## Entrada e precedência

1. `design-system/rn-design-system/MASTER.md` define regras globais.
2. `design-system/rn-design-system/pages/` aplica o override Product, Expressive, Auth ou Data.
3. `agent/index.json` roteia tarefas, componentes, motion, templates e gates.
4. `agent/contracts/index.json` localiza o contrato individual.
5. `agent/contracts/components/<id>.json` define como decidir, montar e validar o componente.

O pacote exporta esses recursos em `@rn-design/system/agent`, `@rn-design/system/contracts`, `@rn-design/system/contracts/<id>` e `@rn-design/system/contract.schema`.

Criação de artes possui um contrato de domínio separado: `agent/art-direction.json`, validado por `agent/art-direction.schema.json` e exportado como `@rn-design/system/art-direction`. O system prompt correspondente é `agent/prompts/create-brand-art.md`/`@rn-design/system/art-prompt`; a seção humana é `#direcao-de-arte`. O JSON baixado pelo Prompt Studio representa o brief preenchido e não substitui esse contrato.

## Conteúdo de um contrato

Cada componente declara:

- `decision.useWhen` e `decision.avoidWhen`;
- cobertura, fonte canônica, classes raiz e exports React;
- anatomia e semântica;
- props tipadas;
- requisito verificável para cada estado;
- teclado;
- tokens permitidos;
- receita e fallback de motion;
- exemplo mínimo;
- critérios de aceite.

## Algoritmo para criação

1. classifique a tarefa pelo `taskRouter`;
2. escolha modo e override;
3. selecione o template estável mais próximo;
4. selecione componentes por `decision.useWhen`;
5. rejeite usos que correspondam a `avoidWhen`;
6. implemente todos os `states`, não apenas `default`;
7. use `implementation.reactExports` ou `rootClasses` sem alterar o contrato visual;
8. valide toda a lista `acceptance` e o `deliveryContract`.

## Algoritmo para refatoração

1. preserve rotas, dados, permissões e ações existentes;
2. inventarie padrões equivalentes;
3. consulte o contrato RN correspondente;
4. migre semântica antes do estilo;
5. substitua valores por tokens e comportamentos por exports públicos;
6. compare antes/depois nos quatro viewports;
7. registre qualquer requisito que não possua cobertura em vez de inventar um componente.

## Sincronização

O gerador canônico é `scripts/generate-component-contracts.mjs`.

```bash
npm run contracts:sync
npm run contracts:check
npm run agent:check
```

Não edite JSON individual manualmente; altere o perfil no gerador e regenere.
