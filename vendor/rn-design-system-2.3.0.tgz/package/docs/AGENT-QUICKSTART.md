# Quickstart para agentes de IA

Use este arquivo como roteador. O objetivo é criar uma interface reconhecivelmente RN sem reler documentos irrelevantes para a tarefa.

## 0. Escolha o fluxo

Abra `agent/index.json`, que concentra o mapa estruturado de modos, seções, componentes, estados, motion, loading, templates e gates. Em seguida escolha:

- `agent/create-frontend.md` para uma aplicação ou rota nova;
- `agent/refactor-frontend.md` para migrar uma interface existente sem alterar a regra de negócio;
- `agent/create-art.md` para arte, campanha, post, capa, banner, imagem ou vídeo;
- `agent/validate.md` para revisar uma implementação pronta.

O índice acelera descoberta; `agent/contracts/index.json` leva ao contrato executável de cada componente. Decisões normativas continuam no Master e nos overrides.

## 1. Receba o brief

Comece por `starters/AGENT-BRIEF.md`. Se um campo estiver ausente, faça a menor suposição reversível e registre-a na entrega. Não invente requisito de negócio, permissão, integração ou ação destrutiva.

Pedidos de arte, post, campanha, banner, capa, imagem ou vídeo seguem `agent/create-art.md`, `agent/art-direction.json`, `agent/prompts/create-brand-art.md` e `docs/ART-DIRECTION.md`. A geração cria a base sem logo e sem texto; a composição final usa os assets oficiais. O painel humano está em `/#direcao-de-arte`.

## 2. Leia na ordem certa

Leitura sempre obrigatória:

1. `agent/index.json` — índice estruturado e status do inventário;
2. `design-system/rn-design-system/MASTER.md` — fonte de verdade;
3. um override de `design-system/rn-design-system/pages/` — contexto da tela;
4. `docs/IMPLEMENTATION.md` — consumo e gates técnicos;
5. `docs/ACCESSIBILITY.md` — qualidade mínima.

Roteamento adicional:

| Se a tarefa envolve… | Leia também |
|---|---|
| hero, landing, proposta ou onboarding | `docs/BUDGET-FRONT-REFERENCE.md` e `docs/VISUAL-GRAMMAR.md` |
| componente novo ou estados | `docs/COMPONENT-SPECS.md` |
| logo, background, fonte ou imagem | `docs/BRAND-ASSETS.md` e `docs/ICONOGRAPHY.md` |
| arte, campanha, post, capa ou vídeo | `docs/ART-DIRECTION.md`, `agent/art-direction.json` e `agent/prompts/create-brand-art.md` |
| textos, erros ou CTA | `docs/CONTENT-VOICE.md` |
| fluxo completo/tipo de tela | `docs/PATTERNS.md` |
| mudança do próprio sistema | `docs/GOVERNANCE.md` e `CHANGELOG.md` |

Antes de montar um componente, leia `agent/contracts/components/<id>.json`. Ele contém decisão de uso, anatomia, props, semântica, teclado, estados, tokens, motion, exemplo e critérios de aceite.

## 3. Declare o modo

- **Product:** app, SaaS, ERP, dashboard, portal, formulário, lista ou tabela. Canvas sempre branco, composição calma e background RN sutil.
- **Expressive:** landing, orçamento, portfólio, apresentação ou onboarding marcante. Replica o ritmo do orçamento com hero editorial e capítulos prescritos.

Não misture a densidade Expressive em uma área operacional. Product é o mesmo DNA em volume menor, nunca um dashboard genérico.

Em criação de arte, o painel edita formato, intensidade, objetivo, mensagem, CTA, mídia, público, assunto visual, conteúdo obrigatório, direitos e fontes. Assets e restrições são preenchidos pelo contrato a partir do kit oficial, da safe area e da regra de um ponto focal. Resolva qualquer campo apagado antes de gerar ou declarar a peça pronta. A visualização `JSON` do Prompt Studio é o brief preenchido; o contrato oficial permanece em `agent/art-direction.json`.

## 4. Importe o Core

```css
@import "@rn-design/system/tokens.css";
@import "@rn-design/system/base.css";
@import "@rn-design/system/components.css";
```

Use Montserrat e os assets exportados pelo pacote. Para começar uma composição, copie o starter mais próximo em `starters/` e substitua conteúdo/semântica, não o branding.

```tsx
import { RnButton, RnField } from "@rn-design/system/react";
```

Ou gere a base completa com `rn-design create <destino> --template <id> --mode <modo>`.

## 5. Implemente nesta sequência

1. conteúdo real e DOM semântico;
2. layout mobile first;
3. tokens semânticos e primitives existentes;
4. default, hover, focus-visible, active, disabled e loading;
5. empty, error, success e permission quando aplicáveis;
6. responsividade em 375, 768, 1024 e 1440px;
7. motion opcional, depois do estado final, com reduced motion;
8. auditoria automática e revisão manual.

## 6. Regras que não podem ser negociadas

- Fundo de Product é branco. Scene charcoal/stage/deep é capítulo editorial fixo, não dark mode.
- A ação primária usa sky com texto ink. Texto colorido usa `brand-text`; foco usa `focus`; borda essencial usa `control-border`.
- O background RN usa `rn-brand-canvas`: grid sutil, símbolo grande no alto à direita e pequeno embaixo à esquerda.
- O wordmark usa `hero` no hero/vídeo oficial, `showcase` em `/animacoes`, `panel` em documentação de destaque e `compact` em cards, fixtures e miniaturas. Declare a escala pela superfície.
- Não crie raw hex, fonte, raio, spacing, shadow, z-index ou duração local.
- Não use `div` clicável, emoji estrutural, texto dentro de imagem, conteúdo dependente de hover ou animação.
- Um ponto focal e uma ação primária por região decisória.

## 7. Contrato de saída

Na entrega informe:

- modo e override escolhidos;
- telas/fluxos entregues;
- tokens e componentes reutilizados/adicionados;
- estados implementados;
- viewports e navegação por teclado testados;
- resultado de contraste e reduced motion;
- comandos executados e pendências reais.

Se você alterou este repositório, execute `npm run agent:check` e `npm run audit`. Em um app consumidor, use `rn-design audit ./src --strict` e replique gates equivalentes com typecheck, testes de interação/axe, build e revisão visual.

Para artes, acrescente ao relatório: prompt e negative prompt, assets oficiais usados, dimensões/safe area, matriz de exportação, alt text, direitos/fontes, modelo ou ferramenta, proveniência e revisão humana. O kit visual permite baixar `rn-design-logo-oficial.png`, `rn-design-icone-oficial.svg` e `rn-design-animacao-oficial.webm`.
