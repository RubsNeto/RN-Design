# Arquitetura do sistema

## Fontes canônicas

| Domínio | Fonte editável | Artefato gerado/consumido |
|---|---|---|
| tokens | `tokens/rn.css` | manifests CSS/JSON/JS/TS |
| componentes React | `src/react/` | `lib/react/` e `@rn-design/system/react` |
| componentes visuais | `styles/rn-components.css` | classes `rn-*` |
| contratos | `scripts/generate-component-contracts.mjs` | `agent/contracts/components/*.json` |
| decisões | `MASTER.md` + overrides | `agent/index.json` e painel |
| marca vetorial | `RnBrandMark.tsx` + assets | wordmark e loader |
| direção de arte | `docs/ART-DIRECTION.md` + `agent/art-direction.json` | aba `#direcao-de-arte`, prompt e brief JSON |
| vídeo da marca | `RnAnimatedWordmark` + rota `/motion-export` | `assets/brand/rn-wordmark-hero.webm` |

Arquivos gerados nunca viram fonte paralela. `examples/react/` reexporta `src/react/`; o painel usa os mesmos componentes da biblioteca.

## Aplicação visual

- `SystemDesignPage` compõe a documentação humana;
- `ComponentPlayground` é um módulo isolado conectado aos exports públicos;
- `ArtDirectionPanel` consome diretamente o contrato e o prompt canônicos, monta o brief e oferece downloads; seu CSS vive em `art-direction.css`;
- `motion-studio.css` contém a extensão de timeline/comparação;
- `MotionExportPage` é uma rota técnica e determinística para `npm run motion:export`, não uma nova variante visual;
- `QualityLabPage` é uma fixture pequena, determinística e acessível;
- rotas pesadas continuam lazy loaded.

Novos módulos de painel devem ter CSS próprio. Não ampliar `system-hub.css` com features isoláveis.

## Fluxo de distribuição

```text
fonte → sync/check → typecheck → build lib/app → testes Node → Playwright/axe → npm pack → release
```

`fix-lib-esm.mjs` normaliza extensões relativas depois do `tsc`, garantindo consumo por ESM nativo e por bundlers.

## Orçamento de mudança

- token novo exige papel semântico e sincronização;
- componente novo exige contrato, export, estilos, estados e teste proporcional ao risco;
- motion novo exige receita no índice, reduced motion e demonstração;
- escala nova do wordmark exige caso de uso diferente de `hero`, `showcase`, `panel` e `compact`; não crie tamanho para corrigir uma aba isolada;
- mudança de direção de arte exige contrato, schema, prompt, documentação, painel e teste no mesmo change set;
- regeneração do vídeo exige metadata, checksum, duração, dimensões, ausência de áudio e quadro final validados;
- template novo exige starter executável e todos os estados declarados;
- mudança breaking exige major version e plano de migração.
