# Direção de arte RN

Versão: **2.3.0**  
Status: **estável**

Esta especificação traduz o RN Design System para posts, banners, capas, campanhas, apresentações, imagens e vídeo. A experiência humana está na aba [`#direcao-de-arte`](http://localhost:8090/#direcao-de-arte); o contrato estruturado está em [`agent/art-direction.json`](../agent/art-direction.json), o prompt operacional em [`agent/prompts/create-brand-art.md`](../agent/prompts/create-brand-art.md) e o fluxo obrigatório em [`agent/create-art.md`](../agent/create-art.md).

## O que a aba entrega

A aba **Direção de arte IA** reúne quatro superfícies conectadas à mesma fonte:

1. **Brief dinâmico:** formato, intensidade, objetivo, mensagem principal, CTA, mídia, público, assunto visual, conteúdo obrigatório, direitos e fontes.
2. **Blueprint estrutural:** proporção calculada, safe area, paleta e wordmark estático em escala `panel`; é uma prévia de composição, não uma arte final nem um gerador de imagem.
3. **Prompt Studio:** visualizações `Completo`, `Negative` e `JSON`, com cópia e download do conteúdo exibido.
4. **Kit oficial:** download direto do logo PNG, símbolo SVG/PNG, animação WebM, halo e pixels, além de preview do vídeo.

O seletor `JSON` do Prompt Studio baixa o **brief preenchido** como `rn-art-brief.json`. O contrato normativo completo continua sendo `agent/art-direction.json`, acessível pelo link “Abrir contrato JSON”. Esses dois arquivos têm papéis diferentes e não devem ser tratados como equivalentes.

## Brief operacional

O painel permite editar diretamente:

- preset de formato;
- intensidade `Expressive` ou `Product / quiet`;
- objetivo;
- mensagem principal;
- CTA;
- mídia visual;
- público;
- assunto visual;
- conteúdo obrigatório;
- direitos e fontes.

Assets exigidos e restrições são preenchidos pelo sistema com o kit oficial, a safe area do preset e a regra de um único ponto focal. Campos apagados pelo usuário reaparecem como placeholders explícitos no prompt e devem ser resolvidos antes da produção.

## Presets oficiais

| ID | Uso exibido | Dimensão | Safe area |
|---|---|---:|---:|
| `square` | Post quadrado | 1080 × 1080 | 8% |
| `portrait` | Post retrato | 1080 × 1350 | 8% |
| `story` | Story / Reel | 1080 × 1920 | 8% |
| `landscape` | Vídeo / banner | 1920 × 1080 | 8% |
| `open-graph` | Open Graph | 1200 × 630 | 8% |

Esses valores vêm de `agent/art-direction.json`. Mudanças de dimensão ou safe area exigem atualização do contrato, schema, painel e testes no mesmo change set.

## Assinatura reconhecível

A peça deve parecer RN antes da leitura do logo: Montserrat RN, celeste/ciano, grande respiro, grid fino ou editorial, assimetria, um ponto focal, palavra importante em azul e uso preciso do símbolo oficial. Halo, até dois orbitais, pixels e cenas escuras são recursos Expressive, não decoração obrigatória.

- `Expressive`: campanha, post, capa, apresentação, proposta e institucional. Escala ampla, grid editorial, respiro e narrativa.
- `Product/quiet`: release, tutorial, diagrama e material informacional. Canvas branco, grid sutil e ornamentos reduzidos.

## Processo em duas etapas

1. Gere ou produza a imagem-base sem texto, wordmark ou logo.
2. Componha texto e assets oficiais de forma determinística.

Modelos generativos não devem desenhar a marca nem a tipografia final. Isso evita letras defeituosas, geometria aproximada e cores divergentes. A composição final usa Montserrat RN e arquivos do kit oficial.

## Kit para download

| Conteúdo | Arquivo | Entrega no painel | Uso |
|---|---|---|---|
| Logo RN Design & Serviços | `assets/brand/rn-logo.png` | `rn-design-logo-oficial.png` | Lockup final digital e apresentações |
| Símbolo RN | `assets/brand/rn-icon.svg` | `rn-design-icone-oficial.svg` | Uso escalável, app icon, favicon e composição editorial |
| Abertura oficial | `assets/brand/rn-wordmark-hero.webm` | `rn-design-animacao-oficial.webm` | Abertura institucional, uma vez por fluxo |
| Símbolo RN raster | `assets/brand/rn-icon.png` | `rn-design-icone-oficial.png` | Fallback para ambientes sem SVG |
| Halo editorial | `assets/motifs/rn-glow.svg` | `rn-design-halo.svg` | Luz e profundidade Expressive |
| Pixels modulares | `assets/motifs/rn-pixels.svg` | `rn-design-pixels.svg` | Borda, transição ou fechamento |

O vídeo oficial possui 1920 × 1080, aproximadamente 4,6 segundos, não contém áudio e termina com quadro estático. Ele é reproduzível com `npm run motion:export`, que grava a rota técnica `/motion-export` usando a própria primitive `RnAnimatedWordmark`, gera `rn-wordmark-hero-poster.png` e sincroniza bytes/checksum no metadata. O pacote exporta o vídeo como `@rn-design/system/wordmark-video`.

O lockup completo continua sendo PNG; apenas o símbolo possui SVG oficial. Não anuncie nem entregue o logo completo como vetor.

## Escalas contextuais do wordmark

`RnAnimatedWordmark` possui uma única coreografia e quatro escalas. A escala é uma decisão da superfície, não uma variante de identidade:

| `size` | Contexto canônico | Uso atual |
|---|---|---|
| `hero` | Abertura monumental | Hero principal e exportação oficial em vídeo |
| `showcase` | Demonstração dedicada | Rota `/animacoes` |
| `panel` | Documentação de destaque | Motion Studio e blueprint da Direção de arte |
| `compact` | Card ou fixture pequena | Playground, Quality Lab e miniaturas de template |

`hero` permanece o default apenas por compatibilidade. Novas aparições devem declarar `size` explicitamente. `showcase`, `panel` e `compact` usam unidades relativas ao contêiner para não herdarem a escala monumental do viewport. Não sobrescreva o tamanho interno por CSS local.

## Aprovação

- um ponto focal e hierarquia mensagem → prova → CTA → metadados;
- logo PNG ou símbolo SVG oficial, sem recolorir, girar, distorcer ou regenerar;
- Montserrat RN e paleta oficial;
- contraste e leitura no tamanho real;
- conteúdo obrigatório, direitos e fontes confirmados;
- negative prompt, alt text e proveniência registrados;
- revisão humana antes da publicação;
- formato e safe area conferidos contra `agent/art-direction.json`;
- vídeo usado somente como abertura institucional, sem loop decorativo.

Não declare a arte pronta se o logo foi aproximado, o texto foi gerado dentro da imagem-base, os direitos são desconhecidos ou o brief ainda contém placeholders necessários à entrega.
