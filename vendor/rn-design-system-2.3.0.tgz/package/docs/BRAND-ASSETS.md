# Marca e assets

## Arquivos oficiais

- `assets/brand/rn-logo.png`: lockup completo, 821×400, proporção 2.0525:1.
- `assets/brand/rn-icon.png`: símbolo isolado, 384×384.
- `assets/brand/rn-icon.svg`: versão vetorial escalável do símbolo, com os nove fragmentos independentes e gradientes medidos do PNG oficial.
- `assets/brand/rn-wordmark-hero.webm`: abertura oficial 1920×1080, aproximadamente 4,6 segundos, sem áudio e com quadro final estático.
- `assets/fonts/montserrat.woff2`: fonte variável oficial.
- `assets/motifs/rn-glow.svg`: halo azul/ciano para composição clara sobre branco.
- `assets/motifs/rn-pixels.svg`: textura modular para preço, rodapé e empty state.

## Escolha do asset

- Use o logo completo em header, login, proposta, capa, footer institucional e metadados sociais.
- Use o ícone em favicon, avatar de produto, app icon e situações abaixo do tamanho mínimo do lockup.
- Prefira `rn-icon.svg` quando houver ampliação, animação ou necessidade de manipular os fragmentos; mantenha `rn-icon.png` como referência raster oficial.
- Use `rn-wordmark-hero.webm` em abertura institucional ou apresentação de marca, uma vez por fluxo. Não use como loader, wallpaper animado ou loop decorativo.
- Nunca reconstitua o lockup completo com texto digitado. A única exceção aprovada é `RnAnimatedWordmark`, que usa Montserrat e geometria prescritas para a abertura `RN DESIGN`; logo institucional estático continua vindo do asset oficial.

## Tamanho mínimo digital

- Logo completo: 108px de largura; prefira 140–220px quando a assinatura “Design & Serviços” precisar ser lida.
- Ícone: 24px; prefira 32–48px em UI.
- Não amplie raster além do necessário para a densidade do dispositivo. Para o símbolo em tamanhos grandes, use o SVG; quando o logo completo for exibido a 200px, entregue o arquivo 821px sem compressão destrutiva.

## Construção vetorial do símbolo

- ViewBox canônico: `0 0 384 384`, igual à matriz de referência.
- Nove paths possuem IDs estáveis de `rn-piece-top` a `rn-piece-bottom`, permitindo animação por fragmento sem alterar a geometria.
- Preenchimento: gradiente diagonal `#3CC5DD` → `#5494E4`.
- Borda óptica subpixel: gradiente diagonal `#3FD0E9` → `#5A9AEE`.
- Não converta os paths em um único contorno ao criar animações.

### Movimento aprovado

- Somente `RnAnimatedWordmark` e `RnBrandLoader` transformam os fragmentos individualmente.
- Transforms transitórios não alteram o `d`, o gradiente ou a borda; o estado final coincide exatamente com `rn-icon.svg`.
- Letras de `RN DESIGN` sobem no eixo vertical sem giro. As peças do símbolo podem convergir e girar apenas durante a montagem oficial.
- Fora dessas duas primitives, logo e símbolo permanecem estáticos.

### Escalas do wordmark

`RnAnimatedWordmark` mantém a mesma sequência e muda apenas a escala conforme a superfície:

| Escala | Superfície |
|---|---|
| `hero` | hero principal e gravação WebM oficial |
| `showcase` | demonstração dedicada em `/animacoes` |
| `panel` | Motion Studio e blueprint da aba `#direcao-de-arte` |
| `compact` | Playground, Quality Lab e miniaturas |

As três escalas menores respondem ao contêiner, não ao viewport. Declare `size` explicitamente fora do hero; não reduza a primitive por seletores CSS da aba ou do card.

### Vídeo oficial e reprodução

O WebM é gerado pelo script `npm run motion:export` a partir da rota técnica `/motion-export` e da própria primitive `RnAnimatedWordmark size="hero" timing="overlap"`. O arquivo registrado em `assets/brand/metadata.json` possui 1920×1080, sem áudio, e deve terminar no lockup estático.

O pacote expõe o vídeo como `@rn-design/system/wordmark-video` e o quadro final como `@rn-design/system/wordmark-poster`. Ao regenerar, valide duração, dimensões, ausência de áudio, hash do metadata e fidelidade do quadro final.

## Downloads no painel

Na aba `/#direcao-de-arte`, o kit oficial oferece:

- `rn-design-logo-oficial.png` a partir de `assets/brand/rn-logo.png`;
- `rn-design-icone-oficial.svg` a partir de `assets/brand/rn-icon.svg`;
- `rn-design-animacao-oficial.webm` a partir de `assets/brand/rn-wordmark-hero.webm`.

O kit da Direção de arte também oferece `rn-icon.png`, `rn-glow.svg` e `rn-pixels.svg`. O lockup completo é raster; apenas o símbolo possui versão SVG oficial. Não descreva o logo PNG como vetor.

## Área de proteção

Reserve ao redor do asset pelo menos **25% da altura visual do símbolo**. Em chrome compacto o mínimo absoluto é 12px; em peças institucionais use 24–48px.

Nenhum texto, borda, ícone ou recorte deve invadir essa área.

## Fundos

- Product usa canvas branco puro. Story abre em branco e pode alternar os capítulos charcoal/stage/deep canônicos do orçamento.
- Use o logo oficial colorido sobre branco; não há versão inversa no sistema.
- Superfícies azuladas muito claras podem agrupar conteúdo, desde que o entorno permaneça branco.
- Fundo fotográfico: coloque o logo em surface branca sólida/translúcida com contraste medido; não dependa de drop shadow.
- A composição canônica usa o símbolo grande no topo direito e pequeno no canto inferior esquerdo por meio de `rn-brand-canvas`.

Exemplo:

```html
<img class="rn-brand-logo" src="/assets/brand/rn-logo.png" alt="RN Design & Serviços" />
```

## Uso do gradiente

Gradientes aprovados:

```css
background: var(--rn-gradient-brand); /* ação primária acessível */
background: var(--rn-gradient-accent); /* acento com texto ink */
```

Não use gradiente em todos os componentes. A ação primária, o logo e um momento de marca já são suficientes.

## Motivos

### Grid

- Product: 40px, linha sky/azul com opacidade aproximada de 2–4,5%.
- Expressive/editorial: 160×180px, linha azul a aproximadamente 3,5%.
- Deve organizar a atmosfera sem competir com texto.

### Marcas de canto

- Símbolo grande: topo direito, até 608px, 6% de opacidade, recorte permitido apenas como motivo de background.
- Símbolo pequeno: canto inferior esquerdo, até 120px, 14% de opacidade.
- Use `rn-icon.svg` ou `rn-icon.png`, nunca o logo completo, para essas duas marcas.
- Em Product denso use a variante `quiet`, que reduz as opacidades pela metade.

### Glow

Halo radial ciano/sky com baixa opacidade sobre branco. Use em hero, login, transição e empty state premium. Nunca atrás de parágrafo longo ou tabela.

### Pixels

Textura modular ligada ao símbolo RN. Use parcialmente, com baixa opacidade, em rodapé, preço, divider de seção ou empty state. Não aplique como papel de parede repetitivo em todo app.

## Proibições

- Distorcer proporção, inclinar ou redesenhar. Recorte só é permitido na marca grande do background canônico.
- Trocar o gradiente por dourado, roxo ou verde.
- Adicionar contorno pesado, bevel ou sombra dura.
- Usar logo como watermark atrás de texto com contraste insuficiente.
- Animar o logo continuamente em Product.
- Criar nova versão apenas porque o arquivo oficial “não cabe”; ajuste o layout ou use o ícone.
