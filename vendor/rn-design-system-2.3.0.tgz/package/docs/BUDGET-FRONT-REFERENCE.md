# Referência oficial — Front do Orçamento

Versão: **2.3.0**
Status: **fonte visual primária de todo o RN Design System**
Implementação executável: `src/`
Preview local: `http://localhost:8090/orcamento`

## 1. Decisão principal

O front oficial do System Design replica o projeto `proposta` **a partir do hero**. Ele é a principal fonte para aparência, ritmo, tipografia, composição e motion de qualquer produto RN. A tela anterior de convite — envelope/cartão com o nome da empresa — e seus componentes exclusivos foram removidos deste projeto.

A ordem visual preservada é:

1. navegação e progresso;
2. hero RN;
3. objetivo;
4. showcase de dispositivos;
5. trilho de telas;
6. fundador;
7. processo;
8. portfólio;
9. orçamento;
10. FAQ e fechamento.

Não compactar, fundir, reordenar ou substituir essas cenas quando a solicitação for “usar o front do orçamento”.

## 2. Fontes de verdade

| Camada | Arquivo |
|---|---|
| Entrada sem cartão | rota `/orcamento` em `src/App.tsx` |
| Composição e animações globais | `src/pages/ProposalPage.tsx` |
| Conteúdo editável | `src/data/content.ts` |
| Tipografia, layout e efeitos | `src/styles/global.css` |
| Seções | `src/sections/*.tsx` |
| Marca e ilustrações | `public/assets/` |
| Regras reutilizáveis para apps | `design-system/rn-design-system/MASTER.md` |

Em uma réplica, copiar a composição desses arquivos. Não reconstruir a página a partir de screenshot, não aproximar medidas “no olho” e não trocar assets por similares.

## 3. Assinatura visual da tela

### 3.1 Hero branco

- Altura de referência desktop: `1080px`.
- Canvas: branco quase puro no código legado, percebido como branco.
- Grid: linhas celestes com opacidade aproximada de 3,5%, células de `160 × 180px`.
- Atmosfera: diagonais cinza quase invisíveis, halo radial azul e dois círculos orbitais.
- Órbita grande: `360px`, topo direito.
- Órbita pequena: `120px`, região esquerda.
- Wordmark central: ícone oficial + “RN DESIGN” em Montserrat 800 e gradiente celeste/ciano.
- Ícone do wordmark: `clamp(84px, 9.6vw, 172px)`.
- Texto do wordmark: `clamp(84px, 11.6vw, 212px)`, line-height `0.94`, tracking `-0.035em`.
- Assinatura “& SERVIÇOS”: pequena, espaçada e digitada após a entrada principal.
- Conteúdo desktop: grid de `920px / 432px`, gap de `88px`, dentro de até `1440px`.
- H1: `clamp(64px, 4.2vw, 80px)`, peso 500, line-height `1.14`, tracking `-0.045em`.
- Azul enfatiza apenas a expressão principal; o restante usa ink/preto.

O selo “Cliente” pertence ao hero da proposta e é diferente da tela de cartão removida. Ele pode receber os dados reais em `content.ts`; não deve recriar uma página de abertura.

### 3.2 Capítulos escuros da narrativa

Product é a tradução operacional e white-first deste mesmo DNA. A referência do orçamento possui capítulos navy/carvão prescritos. Eles não configuram dark mode: são cenas editoriais fixas que criam ritmo entre as superfícies brancas.

- Objetivo: painel carvão com entrada superior recortada.
- Showcase: fundo `#1A1D1D`, halo azul e dispositivos sobrepostos.
- Telas: fundo `#16191C`, heading central e rail horizontal.
- Processo: capítulo escuro com timeline vertical.
- FAQ/fechamento: capítulo escuro com devices, glow e contatos.

Não aplicar esses capítulos escuros a dashboards, tabelas, formulários ou outras interfaces Product.

### 3.3 Capítulos brancos

- Hero: reconhecimento imediato da marca.
- Fundador: autoridade e proximidade, com retrato, card e assinatura.
- Portfólio: evidência visual em cards grandes.
- Orçamento: decisão comercial concentrada no ticket.

O alternar branco/escuro é parte da cadência do orçamento e não deve ser nivelado em um único fundo quando a réplica exata for solicitada.

## 4. Anatomia por seção

### 4.1 Navegação

- Logo oficial à esquerda.
- Linha central que também comunica progresso.
- Três âncoras curtas à direita.
- Fixa no topo, com entrada vertical curta.
- Em mobile, simplificar sem perder logo, início e acesso à proposta.

### 4.2 Hero

Objetivo: apresentar a RN antes do serviço. Ordem interna:

1. wordmark em escala monumental;
2. selo contextual;
3. título da proposta;
4. chips de capacidade e credencial;
5. descrição;
6. CTA para o investimento;
7. indicação de scroll e handoff de capítulo.

### 4.3 Objetivo

Objetivo: explicar o valor antes de mostrar telas. Usa duas colunas no desktop: pergunta/título à esquerda e três parágrafos à direita. O texto forte marca resultados, nunca adjetivos vazios.

### 4.4 Showcase de dispositivos

Objetivo: materializar a promessa. Laptop e celulares são camadas SVG independentes, com profundidade, glow, moldura fina e leve resposta ao ponteiro. Em touch ou reduced motion, a composição permanece estática e legível.

### 4.5 Telas de projetos

Objetivo: criar prova visual contínua. O rail duplica a sequência de imagens para loop sem salto; o hover pausa a animação. As extremidades recebem máscara gradual. O heading permanece central e separado do movimento.

### 4.6 Fundador

Objetivo: associar a entrega a uma pessoa responsável. Combina card fotográfico, texto institucional, retrato destacado e assinatura vetorial animada. O conteúdo deve dizer formação, responsabilidade e impacto no projeto.

### 4.7 Processo

Objetivo: reduzir incerteza. São seis passos canônicos:

1. Descoberta;
2. Estratégia;
3. Design;
4. Desenvolvimento;
5. Lançamento;
6. Evolução.

No desktop, a timeline acompanha o scroll e atualiza número/progresso. Em layout compacto, os passos viram uma leitura linear; nenhum passo pode depender da animação para existir.

### 4.8 Portfólio

Objetivo: provar capacidade. Os cards usam screenshot real, título, ano, tipo e resposta de tilt apenas em ponteiro fino. Clique, Enter e Espaço alternam o estado ativo. Não substituir screenshots RN por referências de terceiros.

### 4.9 Orçamento

Objetivo: concentrar a decisão. O heading introduz o serviço; o ticket contém logo, investimento, opções de pagamento, CTA e pixels de marca. Os valores animam até o total ao entrar na viewport, mas já possuem texto e `aria-label` finais.

Todos os dados variáveis ficam em `src/data/content.ts`: cliente, serviço, valor, parcelas, validade e contato. Não espalhar valores comerciais pelo JSX ou CSS.

### 4.10 FAQ e fechamento

Objetivo: remover objeções e terminar com canais claros. O FAQ é um accordion controlado com `aria-expanded`. O fechamento usa devices, glow, logo e links reais de WhatsApp, e-mail, site e redes.

## 5. Tipografia

- Família única: Montserrat variável oficial em `public/assets/fonts/montserrat.woff2`.
- Wordmark: 800.
- Hero H1: 500.
- Headings editoriais: 400–500, com uma expressão em azul.
- Labels, chips e navegação: 600–700, caixa alta apenas em textos curtos.
- Corpo: 16–20px, leitura clara e entrelinha generosa.
- Números do orçamento: tabulares e de alto contraste.

Não adicionar serif, fonte “premium”, Inter ou fonte de sistema como identidade. Os fallbacks só existem para falha de carregamento.

## 6. Cor e materiais

- Cor de marca dominante: azul-celeste `#47ABE1`.
- Gradiente de marca: azul suave → celeste → ciano.
- Texto no branco: ink/preto e navy acessível.
- Texto nos capítulos escuros: branco suave; azul apenas para destaque.
- Bordas: finas, frias e de baixa opacidade.
- Glow: radial e difuso; não usar como fundo atrás de texto longo.
- Grid: atmosfera, nunca elemento competitivo.

Para novos apps, seguir `tokens/rn.css` e as primitives `rn-story-*`. Os valores locais de `src/styles/global.css` são preservados porque esta pasta é a réplica executável e a evidência primária do sistema.

## 7. Movimento

### Entrada

- Cortina inicial curta dentro da própria ProposalPage.
- Nav entra de cima.
- Ícone gira e assenta com shockwave/partículas.
- Letras do wordmark entram em stagger.
- H1, detalhes e CTA aparecem depois do wordmark.

### Scroll

- Hero sobe e ganha profundidade no handoff.
- Headings revelam palavra por palavra.
- Cards e ticket entram com opacity, translate, scale e leve rotateX.
- Showcase de devices compõe laptop e celulares em velocidades diferentes.
- Timeline atualiza a etapa ativa.
- Fechamento aproxima devices e badge.

### Regras de segurança

- Toda cena respeita `prefers-reduced-motion`.
- Pointer tracking só funciona com `(pointer: fine)`.
- Animação não altera a ordem do DOM.
- Conteúdo e CTA continuam disponíveis sem motion.
- Não adicionar novos loops além dos existentes sem justificar propósito.

## 8. Responsividade

Breakpoints herdados e preservados: `1500`, `1150`, `900` e `600px`.

### Desktop amplo

- Hero mantém composição horizontal.
- Wordmark em escala máxima.
- Conteúdo usa duas colunas.
- Seções editoriais usam grandes áreas de respiro.

### Tablet

- Reduz wordmark, gutters e distância entre colunas.
- Objetivo e founder começam a empilhar.
- Timeline e cards reduzem profundidade e largura.

### Mobile

- Conteúdo vira uma coluna.
- Quebras do hero são controladas pelas classes responsivas.
- Chips quebram linha.
- Rails permanecem recortados, sem scroll horizontal da página.
- Tilt, pointer light e parallax não são requisitos.
- Alvos interativos preservam pelo menos 44px.

Validar sempre em `375`, `768`, `1024` e `1440px`, além de mobile landscape.

## 9. Acessibilidade mínima

- Navegação por âncoras funciona por teclado.
- Foco visível não pode ser removido.
- Imagens decorativas usam `alt=""`; imagens de projeto e fundador têm descrição.
- Accordion expõe `aria-expanded`.
- Cards do portfólio respondem a Enter/Espaço e expõem `aria-pressed`.
- Valores animados preservam nome acessível final.
- Reduced motion mostra o estado final.
- Nenhuma informação existe apenas em hover, cor ou animação.

## 10. Contrato para agentes de IA

Quando o pedido citar “design/front do orçamento”:

1. iniciar em `src/pages/ProposalPage.tsx`, nunca em `InvitationPage.tsx`;
2. preservar a ordem completa das dez cenas;
3. reutilizar `src/styles/global.css` e `public/assets/`;
4. alterar conteúdo somente em `src/data/content.ts`, salvo mudança estrutural explícita;
5. manter Montserrat, azul-celeste, wordmark, grids, devices, pixels e ritmo de seções;
6. não converter o layout em um catálogo genérico de cards;
7. não remover capítulos para “simplificar”;
8. não introduzir outra identidade visual;
9. implementar reduced motion e comportamento mobile;
10. executar `npm run validate`, `npm run typecheck` e `npm run build`.

Se o pedido for para um app operacional, usar Product e o canvas branco do Master, preservando a mesma linguagem em intensidade menor. A réplica integral continua específica de propostas e experiências Expressive; o DNA visual não é específico delas.

## 11. Definition of Done da réplica

- [ ] A URL `/orcamento` abre diretamente no hero.
- [ ] Não existe clique obrigatório no envelope/cartão.
- [ ] Todas as oito seções React do `ProposalPage` estão montadas.
- [ ] O fechamento está incluído dentro do FAQ.
- [ ] Fonte e assets locais carregam sem 404.
- [ ] A ordem visual coincide com a referência.
- [ ] Layout não cria overflow horizontal.
- [ ] Motion é reduzido quando solicitado pelo sistema.
- [ ] Navegação, CTA, portfólio e FAQ funcionam por teclado.
- [ ] Build e validação terminam sem erro.
