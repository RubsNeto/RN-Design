# RN Design CLI

O binário `rn-design` transforma as regras do sistema em operações repetíveis para pessoas, CI e agentes.

```bash
npx rn-design help
```

## Criar

```bash
rn-design create ./portal-cliente --template product-shell --mode product
```

Gera o starter escolhido, os demais patterns executáveis, assets, tokens, estilos, documentação, contratos e `rn-design.json`. O comando não sobrescreve diretório não vazio sem `--force`; mesmo com `--force`, não remove arquivos desconhecidos.

Templates: `auth`, `product-shell`, `dashboard`, `management-list`, `entity-form`, `entity-detail`, `expressive` e `system-feedback`.

## Auditar

```bash
rn-design audit ./src --strict
rn-design audit ./src --json
```

A auditoria heurística detecta cores literais, `rgb/rgba`, elementos não semânticos clicáveis, foco removido, `transition: all` e durações locais. `--strict` também transforma avisos em falha. Ela complementa, mas não substitui, axe, testes de interação e revisão visual.

## Migrar

```bash
rn-design migrate ./src
rn-design migrate ./src --write --report migration.json
```

O modo padrão é dry-run. `--write` aplica somente substituições CSS consideradas seguras para cores oficiais conhecidas; spacing, radius, layout, semântica e motion continuam exigindo decisão humana/agente.

## Consultar contrato

```bash
rn-design contract combobox
```

Retorna o JSON completo do componente para composição direta no contexto do agente.

## Diagnóstico

```bash
rn-design doctor
```

Confere índice, contratos, tokens, estilos e declarações React da instalação.
