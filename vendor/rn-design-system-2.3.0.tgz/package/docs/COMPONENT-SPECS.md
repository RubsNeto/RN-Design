# Especificação de componentes

Implementação CSS de referência: `styles/rn-components.css`. Os exemplos mostram estrutura e comportamento; frameworks podem mudar a API, não a semântica.

## Regras compartilhadas

- Todos os controles têm hit area mínima de 44×44px.
- Estados obrigatórios: default, hover, focus-visible, active, disabled e loading; adicione selected/expanded/invalid quando aplicável.
- Mudanças de estado não deslocam componentes vizinhos.
- Ícone decorativo usa `aria-hidden="true"`; controle só com ícone recebe nome acessível.
- Cor nunca é o único indicador.
- Componente não contém raw hex, raio, sombra ou spacing.

## Button

### Variantes

| Variante | Uso |
|---|---|
| Primary | Ação principal da tela/região; no máximo uma |
| Accent | Ação de marca em ciano sobre fundo neutro, com texto ink |
| Secondary | Alternativa segura e visível |
| Ghost | Ação terciária em chrome ou grupo |
| Danger | Ação destrutiva confirmada |
| Icon | Ação universal e reconhecível; label acessível obrigatório |

### Tamanhos

- Small: 36px; só desktop compacto e com hit area ampliada quando necessário.
- Medium: 44px, padrão.
- Large: 52px para hero, auth e CTA final.

### Comportamento

- Loading: `aria-busy="true"`, texto estável e interação bloqueada.
- Disabled: atributo `disabled`, não apenas estilo.
- Press: scale até 0.98 sem alterar layout.
- Não use primary e accent lado a lado com o mesmo peso visual.

```html
<button class="rn-button" type="submit">Salvar alterações</button>
<button class="rn-button rn-button--secondary" type="button">Cancelar</button>
<button class="rn-button" type="submit" aria-busy="true" disabled>Salvando</button>
```

Primary usa `--rn-color-primary` com `--rn-color-on-primary`; Accent usa `--rn-color-accent` com `--rn-color-on-accent`. Secondary e Danger usam texto branco sobre fundos escuros. Variantes transparentes mantêm a cor semântica e passam para texto branco quando recebem fundo escuro no hover ou no estado selecionado.

## Field

Anatomia: label → controle → helper/erro.

- Label sempre visível e ligada por `for`/`id`.
- Required aparece em texto ou símbolo explicado; o atributo `required` permanece.
- Helper persiste para formato/regras complexas.
- Erro específico usa `aria-describedby` e aparece depois de blur ou submit.
- Read-only mantém contraste e usa `readonly`; disabled só quando o valor realmente não é aplicável.
- Inputs mobile têm pelo menos 44px; login prefere 48px.
- Use `autocomplete`, `inputmode` e `type` semântico.

```html
<div class="rn-field" data-invalid="true">
  <label class="rn-field__label" for="email">
    E-mail <span class="rn-field__required" aria-hidden="true">*</span>
  </label>
  <input
    class="rn-field__control"
    id="email"
    name="email"
    type="email"
    autocomplete="email"
    aria-describedby="email-help email-error"
    aria-invalid="true"
    required
  />
  <p class="rn-field__description" id="email-help">Use seu e-mail profissional.</p>
  <p class="rn-field__error" id="email-error">Digite um e-mail no formato nome@empresa.com.</p>
</div>
```

## Form error summary

Em múltiplos erros, crie um bloco com `role="alert"`, `tabindex="-1"`, heading e links para cada campo. Após submit inválido, mova foco para o summary; preserve erros inline.

## Checkbox e radio

- Label inteira clicável e 44px de altura mínima.
- Checkbox: múltiplas escolhas; radio: uma escolha no grupo.
- Grupo de radios usa `fieldset` e `legend`.
- Estado indeterminate inclui explicação textual para leitor de tela.

## Switch

- Use apenas para uma preferência que entra em vigor imediatamente; escolha checkbox quando a opção fizer parte de um formulário submetido em conjunto.
- O controle usa `button` com `role="switch"` e `aria-checked`, ou um checkbox nativo com aparência equivalente.
- Label permanece visível; on/off não depende apenas da posição ou cor.
- Estados: off, on, hover, focus-visible e disabled.
- O thumb usa transform e deve concluir no estado sem aguardar `transitionend`.

## Search

- Campo recebe label acessível; placeholder não substitui label.
- Limpar busca é um botão com nome acessível e alvo mínimo.
- Estados: empty, typing, loading, results, no-results e error.
- `RnSearch` recebe `status`, `resultCount` e `statusMessage`; loading e resultados usam live region, enquanto no-results e error também permanecem visíveis.
- Preserve query, filtros e scroll ao voltar de um resultado.
- No-results explica como ampliar a busca ou limpar filtros; nunca entregue uma região vazia.

## Combobox e Autocomplete

Use quando a pessoa precisa pesquisar dentro de uma lista extensa. Para poucas opções sem busca, prefira `select` nativo.

- O input mantém o foco e usa `role="combobox"`, `aria-expanded`, `aria-controls`, `aria-autocomplete="list"` e `aria-activedescendant`.
- Resultados usam `role="listbox"`; cada item usa `role="option"` e `aria-selected`. O ID do item ativo alimenta `aria-activedescendant`.
- `ArrowDown`/`ArrowUp` percorrem resultados, `Enter` seleciona, `Escape` fecha sem apagar a busca e `Home`/`End` alcançam os extremos quando a lista está aberta.
- Busca assíncrona anuncia loading, quantidade de resultados, no-results e error em uma live region educada. Cancele respostas obsoletas e preserve a string digitada.
- Não abra automaticamente com uma opção pré-selecionada que possa ser confirmada por engano. IME, acentos e colagem precisam funcionar.
- Em mobile com resultados complexos, pode virar dialog/drawer de busca, restaurando foco ao fechar.
- Estados: closed, open, typing, loading, no-results, invalid e disabled.

```html
<div class="rn-field rn-combobox" data-open="true">
  <label class="rn-field__label" for="project">Projeto</label>
  <div class="rn-combobox__control">
    <input id="project" class="rn-field__control" role="combobox"
      aria-expanded="true" aria-controls="project-options"
      aria-autocomplete="list" aria-activedescendant="project-2" />
    <button class="rn-combobox__toggle" type="button" aria-label="Mostrar projetos" aria-expanded="true"></button>
  </div>
  <ul class="rn-combobox__listbox" id="project-options" role="listbox">
    <li class="rn-combobox__option" id="project-2" role="option" aria-selected="true">Projeto Aurora</li>
  </ul>
</div>
```

## Date e Time Picker

Prefira `input type="date"`, `time` ou `datetime-local` quando a experiência nativa atender ao contexto. Use o calendário composto quando houver range, bloqueios, múltiplos meses ou regras que precisem ficar visíveis.

- Valor de domínio permanece ISO; apresentação, ordem e nomes usam `pt-BR`. Não grave a string formatada como data.
- O trigger possui label e `aria-expanded`; o painel recebe nome acessível e, quando modal, focus trap, Escape e restauração de foco.
- Calendário segue o padrão ARIA grid: setas movem um dia, Page Up/Down troca mês, Home/End alcança início/fim da semana e Enter/Space seleciona.
- Hoje, selecionado, dentro do range, indisponível e inválido usam texto/semântica além de cor. Datas bloqueadas explicam o motivo quando necessário.
- Range anuncia início e fim, não altera uma data já confirmada sem ação explícita e tolera teclado e touch.
- Hora usa formato de 24 horas por padrão; timezone e horário de verão pertencem ao contrato de dados.
- Em mobile, calendários complexos viram dialog ou bottom sheet com ações claras; nunca desabilite digitação quando ela for válida.
- Estados: closed, open, selected, range, invalid e disabled.

`RnDateTimeField` implementa a estratégia native-first para `date`, `time` e `datetime-local`. `RnDateRangeField` combina dois inputs nativos, limita início/fim mutuamente e mantém o valor ISO. Calendários compostos continuam reservados para regras que realmente exijam grid, múltiplos meses ou datas bloqueadas visíveis.

## Segmented Control

- Use para alternar poucas visualizações mutuamente exclusivas dentro do mesmo contexto.
- Cada item é `button` com `aria-pressed` ou segue o padrão ARIA tabs quando troca um painel associado.
- Labels não truncam silenciosamente; em largura insuficiente permita scroll identificado ou use outro pattern.
- Setas movem foco quando o componente adota semântica de tabs.

## Progress

- Use `<progress>` quando o valor for mensurável e informe label, valor atual e unidade.
- Indeterminado comunica atividade, não porcentagem fictícia.
- Upload, importação e exportação oferecem cancelar quando a operação permitir.
- Complete e error usam texto/ícone além da cor; atualização relevante pode usar live region contextual.

## Stepper

- Use em fluxos realmente sequenciais; não transforme navegação comum em etapas.
- Estados: upcoming, current, complete, error e disabled.
- O passo atual usa `aria-current="step"`; todos os labels permanecem visíveis.
- Error possui indicador vetorial e descrição textual; disabled usa `aria-disabled` e mantém o contexto legível.
- Em mobile vira lista vertical na mesma ordem do DOM.

## Tooltip

- É conteúdo complementar curto, nunca o único nome de um controle.
- Abre em hover e foco; touch precisa de acionamento operável quando o conteúdo for necessário.
- O trigger referencia o conteúdo por `aria-describedby`.
- Escape fecha quando aberto de forma persistente; não cobre o controle com foco.

## Avatar

- Prioridade de fallback: imagem válida → iniciais → símbolo neutro; o ícone RN só representa o produto, não uma pessoa.
- Informe nome visível próximo ou texto alternativo quando a imagem carregar significado.
- Status combina indicador visual e texto acessível.
- Tamanhos derivam dos controles canônicos; mantenha forma circular e não distorça fotografia.

## Card

| Variante | Uso |
|---|---|
| Base | Agrupamento conceitual padrão |
| Soft | Bloco informativo sem elevação |
| Raised | Menu, painel em destaque |
| Glass | Login, modal ou cena curta |
| Brand | Destaque celeste claro, sem trocar o canvas para fundo escuro |
| Interactive | Destino ou seleção completa |

- Não use card apenas para colocar borda em cada item de uma lista.
- Card navegável usa `RnCardLink`/`<a class="rn-card rn-card--interactive">`; uma ação local usa `<button>`. Nunca torne uma `div` clicável.
- Card clicável deve ser um único link/button sem controles interativos aninhados.
- Hover não pode revelar a única informação necessária.

## Brand Canvas

Background estrutural para hero, login, onboarding, empty state e cabeçalho de página com identidade forte.

| Variante | Uso |
|---|---|
| Base/Product | Grid 40px, marcas discretas, app e dashboard |
| Editorial | Grid 160×180px, marcas 6%/14%, landing e proposta |
| Quiet | Sem halo e marcas pela metade, formulário/lista/leitura |

Anatomia fixa:

1. canvas branco;
2. grid azul sutil;
3. símbolo grande no topo direito;
4. símbolo menor no canto inferior esquerdo;
5. conteúdo em camada superior.

Use `rn-brand-canvas`; não recrie pseudo-elementos por página. Os símbolos são decorativos e não recebem texto alternativo.

## Story primitives — DNA do orçamento

Estas primitives são mais importantes que os cards genéricos quando o app possui uma região institucional, landing, onboarding, proposta, portfólio ou apresentação.

| Primitive | Responsabilidade |
|---|---|
| `rn-story-page` | Contexto raiz e tipografia RN |
| `rn-story-progress` | Linha fixa de progresso em gradiente |
| `rn-story-nav` | Logo + linha + navegação curta |
| `rn-story-hero` | Hero branco, grid 160×180px e orbitais |
| `rn-story-wordmark` | RN DESIGN + símbolo oficial vetorial em escala contextual |
| `rn-story-wordmark__letters` | Primeira etapa: subida vertical com bounce e stagger por letra |
| `rn-story-wordmark__symbol` | Segunda etapa: montagem dos nove paths; termina no lockup completo |
| `rn-story-title` | H1 64–80px, peso 500, expressão destacada |
| `rn-capability-chips` | Selos de capacidade em pill |
| `rn-story-scene` | Capítulo light com container e respiro |
| `rn-story-scene--dark` | Capítulo charcoal de contexto/processo |
| `rn-story-scene--stage` | Palco de devices/prova visual |
| `rn-story-scene--deep` | Telas, FAQ e fechamento |
| `rn-story-split` | Composição assimétrica de título + copy |
| `rn-story-media-frame` | Frame de device com glow e profundidade |
| `rn-story-handoff` | Linha de transição entre capítulos |
| `rn-story-ticket` | Superfície de decisão, plano ou investimento |

Regras:

- preserve um único ponto focal por cena;
- use `rn-story-scene__inner` com container de 1278px;
- em mobile, o conteúdo vem antes da ilustração;
- dark/stage/deep usam `on-scene` tokens e contraste medido;
- motion só é adicionado depois do DOM final e deve desaparecer em reduced motion;
- a entrada do wordmark usa `rn-story-wordmark__letter`, `rn-story-wordmark__symbol-piece` e os tokens `duration-count`, `stagger-wordmark`, `duration-scene` e `ease-emphasized`; o wrapper visual fica oculto da árvore acessível e o nome completo permanece no `aria-label` do wordmark;
- use o hero completo apenas uma vez por fluxo; escolha `size="hero"`, `showcase`, `panel` ou `compact` pela superfície e não sobrescreva seus filhos com CSS local.

## Chip e badge

- Badge: status curto, não interativo.
- Chip estático usa `rn-chip`; badge usa `rn-badge`; chip interativo usa `button.rn-chip-button` com estado `aria-pressed`/nome acessível quando aplicável.
- Coleções fazem wrap antes de truncar texto.
- Removable chip precisa de botão de remover com nome acessível.
- Status combina cor com texto/ícone.

## Alert e toast

### Alert

Persistente no fluxo, usado para informação, sucesso, warning e error. Título curto, explicação e ação de recuperação quando necessário.

### Toast

- Não rouba foco.
- `role="status"`/`aria-live="polite"` para sucesso/informação; alertas críticos podem usar `role="alert"`.
- Auto-dismiss entre 3–5s somente se a mensagem não exigir ação/leitura longa.
- Ação destrutiva reversível oferece “Desfazer”.

## Navigation

### Topbar

- Altura 64px desktop, 56px compact.
- Logo à esquerda, contexto central quando necessário e ações à direita.
- Sticky topbar usa fundo quase opaco e reserva offset de scroll.

### Sidebar

- Desktop para navegação persistente de produto.
- Largura de referência: 216–256px.
- Item ativo usa background brand-soft + indicador, não apenas cor.
- Logout e ações perigosas ficam separados no fim.

### Mobile

- Drawer ou bottom nav; não os dois no mesmo nível.
- Bottom nav tem no máximo cinco destinos com ícone + label.
- Estado ativo é semântico (`aria-current="page"`).
- A primitive sidebar vira navegação horizontal rolável como fallback compacto, preservando todos os destinos; apps com muitos destinos devem substituí-la por drawer ou bottom nav explícito.

### Breadcrumb

Use com três ou mais níveis. Último item é texto/current, não link redundante.

## Tabs

- Para alternar views relacionadas sem mudar de nível de navegação.
- Implementar padrão ARIA tabs quando o conteúdo troca inline.
- Setas movem foco entre tabs; Enter/Space ativa conforme modelo escolhido.
- Tabs em excesso viram overflow/menu, não texto espremido.

## List item

- Flat e escaneável; altura 58–64px para conteúdo de duas linhas.
- Estrutura: leading → texto flexível → metadata/actions.
- `min-width: 0` no conteúdo; tokens longos usam `overflow-wrap:anywhere`.
- Unread/selected usa peso + indicador, não apenas cor.

## Table

- Header claro, números tabulares e alinhamento consistente.
- Wrapper pode rolar horizontalmente como último recurso; em mobile prefira priorizar colunas ou card list.
- Ordenável: button dentro de `th` e `aria-sort` no header.
- 50+ linhas: paginação/virtualização.
- Loading, empty, error e partial data têm estados explícitos.
- `RnDataTable` recebe `status`/`statusMessage`, permite `isRowSelected` e coloca o controle de ordenação dentro do `th` quando a coluna fornece `onSort`.
- Ações por linha ficam em menu quando excedem duas.

## KPI

- Label curta, valor tabular, unidade e comparação temporal.
- Tendência inclui texto/seta além de verde/vermelho.
- No máximo quatro KPIs por linha; mobile empilha ou usa 2 colunas.
- Não anime contagem em Product se atrapalhar comparação ou reduced motion.

## Data Visualization

Escolha a visualização pela pergunta, não pela aparência: linha para tendência, barras para comparação, barras empilhadas para composição, scatter para relação e tabela quando o valor exato é a tarefa principal. Pie/donut só entra com poucas partes de um todo e labels diretos.

- Todo gráfico informa título, medida, período, timezone quando relevante e fonte/última atualização.
- Use `--rn-color-data-1` a `--rn-color-data-5` na ordem. Cor nunca é o único canal: combine label direto, ordem, forma, traço ou padrão.
- Eixos têm unidade, escala honesta e ticks legíveis. Barras partem de zero; cortes de eixo precisam ser explícitos.
- Tooltip abre também por foco/teclado, não contém a única informação e não cobre o ponto ativo. Valores usam `Intl.NumberFormat("pt-BR")`.
- Forneça resumo textual e tabela acessível equivalente para leitores de tela e para tarefas que exigem precisão.
- Estados obrigatórios: loading com geometria reservada, ready, empty, error com recuperação, partial com aviso e no-permission.
- Atualizações preservam contexto e foco. Motion usa transform/opacity, não roda em loop e desaparece em reduced motion.
- Em mobile priorize séries, labels e comparação; permita scroll identificado somente quando reduzir informação mudaria o significado.

`RnBarChart` é a implementação estável para comparação por barras: fornece container, header, legenda, plot, até cinco séries, estados de consulta e tabela equivalente. Outras engines podem consumir os mesmos tokens e contrato quando linha, scatter ou composição forem necessários.

```html
<figure class="rn-chart" aria-labelledby="revenue-title" aria-describedby="revenue-summary">
  <figcaption class="rn-chart__header">
    <div><h3 id="revenue-title">Receita por mês</h3><p>Jan–Jun 2026 · BRL</p></div>
  </figcaption>
  <p class="rn-sr-only" id="revenue-summary">A receita cresceu em cinco dos seis meses.</p>
  <div class="rn-chart__plot" aria-hidden="true"><!-- visualização --></div>
  <table class="rn-chart__table"><!-- valores equivalentes --></table>
</figure>
```

## Dialog

- Use `<dialog>` quando possível ou implemente focus trap, `aria-modal`, nome e descrição.
- Foco inicial vai ao título/primeiro campo, não automaticamente à ação destrutiva.
- Escape fecha quando seguro; alteração não salva exige confirmação.
- Ao fechar, devolva foco ao trigger.
- Footer: primary à direita no desktop; no mobile empilhe com primary por último na ordem visual e correta na ordem DOM.

## Drawer e popover

- Drawer para navegação/contexto lateral; popover para conteúdo curto ancorado.
- Clique no scrim e Escape fecham quando não houver perda de dados.
- Posição não pode cobrir o controle com foco.

## Accordion/FAQ

- Use `button` ou `<summary>` nativo.
- Anuncie expanded/collapsed.
- Título continua legível sem JavaScript.
- Permitir múltiplos itens abertos em FAQ longo; não feche conteúdo inesperadamente.

## Empty state

Inclui: título que descreve o estado, uma frase de orientação e uma ação possível. Ilustração é opcional e decorativa.

Exemplo: “Nenhum projeto ainda” + “Crie o primeiro projeto para acompanhar prazos e equipe.” + “Criar projeto”.

## Skeleton

- Reserve a geometria final para evitar layout shift.
- Use quando espera prevista passa de 1s.
- Não mostre skeleton em ação instantânea.
- Reduced motion remove shimmer.

## Brand loader

- Use `rn-brand-loader` em transições de rota, inicialização do produto e esperas previstas acima de 300ms.
- O núcleo usa os nove paths de `assets/brand/rn-icon.svg`, preservando exatamente geometria, preenchimento e borda da marca.
- O componente expõe `role="status"`, label específica no presente contínuo e `aria-live="polite"`.
- `sm`, `md`, `lg` e `xl` alteram apenas escala. Reserve `xl` para splash screens, troca de contexto e demonstrações de marca; em fluxos operacionais prefira `sm` ou `md`. A variante pública oficial é `radial`, nomeada **Montagem com impacto — 01**.
- `pulse`, `orbit`, `wave`, `focus`, `scan`, `breathe`, `magnetic`, `cascade` e `eclipse` permanecem apenas no laboratório comparativo com status experimental; agentes não devem escolhê-las automaticamente.
- A prop `paused` interrompe o ciclo sem desmontar o estado visual; `announce={false}` torna prévias comparativas decorativas e silenciosas para leitores de tela.
- `prefers-reduced-motion` congela a composição em um estado final legível, sem remover o status.

```tsx
<RnBrandLoader variant="radial" size="md" label="Carregando projetos" />
```

## Wordmark animado

- Use `RnAnimatedWordmark` em hero principal ou abertura institucional; previews documentais podem mostrar o estado final estático. O padrão não se repete durante o mesmo fluxo.
- A prop `size` define o contexto: `hero` para `RnStoryHero`; `showcase` para a rota oficial; `panel` para Motion Studio; `compact` para Playground, Quality e miniaturas. O default `hero` preserva compatibilidade.
- As quatro escalas usam unidades relativas ao contêiner, não ao viewport, para que a simulação 375/768/1024 seja verdadeira e não transborde cards.
- A sequência oficial é determinística: `RN DESIGN` sobe letra por letra, o símbolo monta seus nove paths e o lockup termina estático.
- No hero principal, use `timing="overlap"`: o símbolo começa 100ms depois da primeira letra e as duas entradas terminam praticamente juntas. `timing="sequential"` preserva a demonstração em etapas do laboratório.
- As letras não rotacionam nem se deslocam lateralmente. Toda a entrada tipográfica ocorre no eixo vertical.
- `animated={false}` entrega a assinatura estática para miniaturas, templates e contextos onde motion desviaria atenção.
- O símbolo isolado usa `RnBrandMark size="sm|md|lg|xl|fluid"`; `fluid` é reservado para composições como loader/wordmark que já dimensionam o contêiner. Não aplique width arbitrário nos paths internos.
- Replay deve acontecer por ação explícita. `prefers-reduced-motion` mostra diretamente a marca completa.

```tsx
<RnAnimatedWordmark size="hero" timing="overlap" />
```

## Price/ticket Expressive

- Preço principal usa tabular nums e label explícita.
- Condições ficam em blocos comparáveis, não apenas texto decorativo.
- CTA aparece depois de valor, escopo e validade.
- Tilt/scan é opcional e desligado em coarse pointer/reduced motion.
- Valores não podem depender de animação de contagem para serem anunciados.

## Mapa de implementação

| Família | CSS de referência | Exemplo React |
|---|---|---|
| Button | `rn-button`, `rn-icon-button` | `RnButton.tsx` |
| Card/link | `rn-card` | `RnCard.tsx` |
| Field | `rn-field` | `RnField.tsx`, `RnFormControls.tsx` |
| Combobox/autocomplete | `rn-combobox` | `RnCombobox` |
| Date/time/range | `rn-date-picker`, `rn-date-range` | `RnDateTimeField`, `RnDateRangeField` |
| Error summary | `rn-error-summary` | `RnErrorSummary.tsx` |
| Tabs | `rn-tabs`, `rn-tab`, `rn-tab-panel` | `RnTabs.tsx` |
| Dialog | `rn-dialog` | `RnDialog.tsx` |
| Data visualization | `rn-chart` | `RnBarChart` + override `data-dashboard.md` |
| Brand loader | `rn-brand-loader` | `src/components/RnBrandLoader.tsx` |
| Animated wordmark | `rn-story-wordmark` | `src/components/RnAnimatedWordmark.tsx` + `src/components/RnBrandMark.tsx` |
| Brand canvas | `rn-brand-canvas` | `RnBrandCanvas.tsx` |
| Story hero/scene | `rn-story-*` | `RnStoryHero.tsx`, `RnStoryScene.tsx` |
| Shell/navigation/table/overlays | `rn-product-shell`, `rn-sidebar`, `rn-table`, `rn-drawer`, `rn-popover` | `RnBreadcrumb`, `RnDataTable`, `RnPagination`, `RnDialog`, `RnDrawer`, `RnPopover` |
