# Voz, conteúdo e microcopy

## Personalidade

A RN fala como um especialista próximo: segura sem arrogância, técnica sem jargão desnecessário e sempre ligada ao resultado real do cliente.

Quatro atributos:

- **Clara:** frase curta, verbo direto e um assunto por bloco.
- **Humana:** usa “você”, reconhece contexto e não culpa o usuário.
- **Confiável:** evita exagero e explica o que acontecerá.
- **Prática:** mostra ação, impacto e recuperação.

## Estrutura da mensagem

Prefira: **resultado → contexto → tecnologia**.

Bom: “Centralize projetos e prazos em um só lugar, com automações para reduzir tarefas repetitivas.”

Evite: “Nossa plataforma usa uma arquitetura inovadora de IA para revolucionar processos.”

## Vocabulário

Preferir:

- criar, organizar, acompanhar, integrar, automatizar, validar, publicar, evoluir;
- operação, projeto, prazo, equipe, cliente, resultado;
- “tecnologia sob medida”, “valor real”, “próximos passos”.

Evitar:

- revolucionário, disruptivo, mágico, game changer;
- excesso de “solução”, “ecossistema” e “sinergia”;
- sigla sem explicação;
- promessa absoluta sem prova.

## Headings

- Informam a ideia principal, não apenas o nome da seção.
- Podem destacar uma palavra-chave em azul, sem depender apenas da cor para hierarquia.
- Sentence case em produto; uppercase só em eyebrow curto.

Exemplos:

- “Projetos que precisam da sua atenção”
- “Investimento para colocar o sistema em operação”
- “Seu próximo passo começa aqui”

## Botões

Use verbo + objeto/contexto:

- “Criar projeto”
- “Salvar alterações”
- “Ver orçamento”
- “Tentar novamente”
- “Alinhar início do projeto”

Evite “OK”, “Sim”, “Enviar” ou “Continuar” quando uma ação mais precisa couber.

## Status e feedback

### Sucesso

Confirme o que aconteceu e, quando útil, o próximo passo.

“Projeto criado. Agora você pode convidar a equipe.”

### Erro

Estrutura: problema + motivo conhecido + recuperação.

“Não foi possível salvar porque a conexão foi interrompida. Verifique sua internet e tente novamente.”

Não use “Algo deu errado” sem orientação.

### Empty state

Estado + benefício da ação + CTA.

“Nenhum projeto ainda. Crie o primeiro para acompanhar entregas e responsáveis em um só lugar.”

### Loading

Use presente contínuo específico: “Salvando proposta…”, “Carregando projetos…”. Não use “Aguarde” isolado.

## Formulários

- Label nomeia o dado: “E-mail profissional”.
- Helper explica formato/uso: “Usaremos este endereço para avisos do projeto.”
- Placeholder é exemplo: “nome@empresa.com”.
- Erro descreve correção: “Digite um e-mail no formato nome@empresa.com.”
- Required deve ser explicado uma vez no início quando houver muitos campos.

## Datas, números e dinheiro

- Locale padrão: `pt-BR`.
- Moeda: `R$ 25.000,00` quando centavos importam; `R$ 25.000` em apresentação comercial.
- Data curta: `22/08/2026`; em prosa: `22 de agosto de 2026`.
- Número tabular em tabela, KPI e preço.
- Não esconda unidade ou período: “R$ 6.000/mês”, “32 horas mensais”.

## IA

Trate IA como capacidade aplicada:

Bom: “Classifica solicitações e sugere a próxima ação; você revisa antes do envio.”

Evite: “IA que faz tudo por você.”

Explique limite, revisão humana e impacto quando a decisão for sensível.

## Taglines aprovadas

- “Design • Desenvolvimento • IA”
- “Onde ideias se transformam em inovação”

Não criar nova tagline por tela. Produto pode usar descriptor funcional abaixo do logo.
