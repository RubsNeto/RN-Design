# DNA visual e hierarquia de autoridade

Versão: **2.3.0**
Status: **regra de desempate para qualquer decisão visual RN**

## Decisão central

O Design System RN é baseado **majoritariamente na página do orçamento** localizada originalmente em `C:\Users\ruben\Documents\GitHub\proposta`.

Essa página define a aparência, a sensação e o ritmo da marca:

- Montserrat em escala ampla;
- azul-celeste e gradiente celeste/ciano;
- hero branco com grid editorial;
- wordmark RN monumental;
- círculos orbitais, halo, pixels e linhas finas;
- composição assimétrica e espaçosa;
- alternância deliberada de capítulos brancos e carvão;
- navegação curta com linha de progresso;
- chips em pill;
- prova visual em devices e cards;
- ticket como superfície de decisão;
- motion editorial com progressão por scroll.

O projeto `email` não é uma segunda direção visual equivalente. Ele fornece apenas soluções funcionais para áreas que a proposta não cobre: densidade de listas, formulários, toolbar, tabela, sidebar e estados operacionais.

## Ordem de autoridade

Quando duas fontes entrarem em conflito, use esta ordem:

1. instrução explícita mais recente do proprietário;
2. acessibilidade, segurança e semântica nativa;
3. página do orçamento e `docs/BUDGET-FRONT-REFERENCE.md`;
4. tokens e componentes canônicos deste repositório;
5. comportamento Product extraído do RN Mail;
6. recomendações genéricas de bibliotecas, frameworks ou ferramentas.

O orçamento vence em cor, escala, composição, tipografia, forma, textura, narrativa e movimento. O RN Mail só vence quando existe uma necessidade operacional que o orçamento não demonstra.

## Tradução para dois contextos

### Story / Expressive

Usa o vocabulário completo do orçamento:

- hero branco monumental;
- wordmark e orbitais;
- grid 160 × 180px;
- capítulos brancos, charcoal, stage e deep;
- headings 38–80px; wordmark até 212px;
- scroll storytelling, reveal, progress e parallax controlado;
- media frames, rail de projetos, timeline, ticket e fechamento visual.

### Product

Não adota a aparência do SOGo. Ele é uma redução do mesmo DNA do orçamento:

- canvas branco;
- Montserrat;
- azul-celeste como primária;
- grid mais fino de 40px;
- marcas de canto ou halo em baixa opacidade;
- pills e bordas frias;
- labels curtas e progress indicators;
- cards amplos apenas para unidades conceituais;
- motion reduzido a feedback e continuidade espacial;
- capítulos escuros somente em momentos institucionais, nunca atrás de tabelas ou formulários densos.

## Proporção de influência

Use esta regra prática ao criar uma interface nova:

- **80% Orçamento:** identidade, hierarquia, ritmo, superfícies, cor, tipografia e motion.
- **20% Product:** densidade, estados, padrões de formulário, dados e navegação recorrente.

Essa proporção não é uma métrica visual rígida. É uma instrução para evitar que padrões genéricos de SaaS apaguem a personalidade demonstrada no orçamento.

## Elementos obrigatórios de reconhecimento

Uma experiência RN deve conter pelo menos cinco destes sinais, escolhidos conforme contexto:

1. Montserrat RN;
2. azul-celeste `#47ABE1`;
3. palavra importante destacada em azul;
4. grid fino ou editorial;
5. logo/ícone oficial;
6. wordmark em grande escala;
7. orbitais ou halo radial;
8. chips em pill com borda azul translúcida;
9. linha de progresso/handoff;
10. seção de prova visual;
11. ticket/card de decisão;
12. transição branco → carvão → branco em experiências narrativas.

Product pode usar os sinais em intensidade baixa. Story/Expressive deve usar o conjunto completo definido pela página do orçamento.

## O que não deve dominar

- aparência padrão de dashboard gerado por template;
- branco com cards cinza sem assinatura RN;
- navy como cor primária no lugar do celeste;
- estética herdada do SOGo/Mailcow;
- fonte Inter, Arial, serif ou “luxury”;
- bento grid genérico como estrutura principal;
- glassmorphism em toda superfície;
- gradiente roxo, dourado ou cor externa à marca;
- animação decorativa sem progressão narrativa;
- dark mode confundido com os capítulos carvão prescritos.

## Teste de fidelidade

Antes de aprovar uma tela, responda:

1. Ela poderia pertencer ao front do orçamento sem parecer de outra empresa?
2. Montserrat e o celeste dominam a percepção correta?
3. Existe um ponto focal claro em vez de vários cards equivalentes?
4. A composição possui escala, respiro e prova visual?
5. Em Product, a redução preserva o DNA sem prejudicar trabalho recorrente?
6. A interface funciona com teclado, touch e reduced motion?

Se a primeira resposta for “não”, o resultado ainda não está suficientemente baseado no orçamento.
