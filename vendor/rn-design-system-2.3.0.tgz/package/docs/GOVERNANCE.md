# Governança e evolução

## Fonte de verdade

1. `design-system/rn-design-system/MASTER.md` define decisões.
2. `tokens/rn.css` é a implementação canônica de tema.
3. `scripts/sync-tokens.mjs` gera o manifesto completo em JSON, JS e TS a partir do CSS.
4. `src/react/` e `styles/rn-components.css` implementam os componentes públicos.
5. `scripts/generate-component-contracts.mjs` gera os contratos individuais para agentes.
6. `docs/ART-DIRECTION.md`, `agent/art-direction.json` e `agent/prompts/create-brand-art.md` definem, respectivamente, a leitura humana, o contrato e a instrução operacional para artes.

Em conflito, corrija todas as camadas no mesmo change set; não aceite divergência temporária em release.

## Versionamento

Use SemVer:

- **Patch:** correção visual, documentação, contraste ou bug sem mudar API.
- **Minor:** novo token, variante, componente ou padrão compatível.
- **Major:** remoção/renomeação de token, mudança de API ou rebranding.

## Proposta de mudança

Toda mudança relevante registra:

- problema e contexto;
- evidência em produtos reais;
- modo afetado: Core, Product ou Expressive;
- alternativa considerada;
- impacto no canvas Product, scene surfaces, responsive, a11y e motion;
- estratégia de migração;
- screenshots/estados e resultado da validação.

## Novo token

Um token só entra quando:

1. representa decisão reutilizável, não exceção de uma tela;
2. não existe token semântico equivalente;
3. possui nome por papel, não por aparência local;
4. é adicionado a `tokens/rn.css` e propagado com `npm run tokens:sync`;
5. é demonstrado no catálogo ou componente;
6. tem contraste verificado sobre branco e sobre todas as superfícies claras em que aparece.

## Novo componente

Exige:

- propósito e quando não usar;
- anatomia e API;
- variantes e todos os estados;
- semântica/ARIA e teclado;
- responsive e touch;
- canvas Product branco, cenas Story canônicas e reduced motion;
- exemplo real e teste proporcional ao risco.
- export em `src/react/index.ts` quando houver comportamento React reutilizável;
- contrato individual gerado, schema válido e critérios de aceite;
- demonstração no Playground e fixture Playwright quando aplicável.

## Direção de arte e assets exportáveis

Mudanças em formatos, safe area, prompt, proibições ou saídas de arte exigem atualização conjunta de:

- `docs/ART-DIRECTION.md`;
- `agent/art-direction.json` e seu schema;
- `agent/prompts/create-brand-art.md` e `agent/create-art.md`;
- aba `#direcao-de-arte`;
- testes estruturais, de schema, de distribuição e Playwright.

O vídeo oficial é derivado da primitive, não editado manualmente como uma identidade paralela. `npm run motion:export` atualiza WebM, poster, bytes e checksum; valide também dimensões, duração, áudio, peso e quadro final antes de publicar. O símbolo SVG pode escalar; o lockup completo continua PNG até existir um vetor oficialmente aprovado.

## Depreciação

- Marque como deprecated na documentação e nos tipos.
- Ofereça substituto e instrução de migração.
- Mantenha por pelo menos uma versão minor, salvo falha crítica de segurança/a11y.
- Remova apenas em major.

## Review gates

- Brand: asset, fonte e assinatura coerentes.
- Design: token, hierarquia, estados e modos.
- Engenharia: API, performance e manutenção.
- Acessibilidade: teclado, foco, contraste, zoom e reduced motion.
- Conteúdo: voz, clareza e recuperação de erro.
- Arte: brief completo, asset oficial, direitos/fontes, negative prompt, alt text, proveniência e revisão humana.

## Release

1. Rode `npm run tokens:sync` e `npm run contracts:sync`; confirme que o diff gerado é intencional.
2. Rode `npm run release:check` e `npm run audit` após instalar dev dependencies.
3. Teste catálogo em 375, 768, 1024 e 1440px, confirme canvas Product branco, scene contrast, escalas contextuais, aba de arte e reduced motion.
4. Atualize `CHANGELOG.md` e a versão conforme SemVer.
5. Publique/marque commit somente depois dos gates.

`npm run audit` inclui contratos, schema, CLI, contraste, sincronização exata, typecheck, build, integridade das rotas, Playwright/axe, regressão visual e `npm pack --dry-run`.

Tags `vX.Y.Z` disparam a auditoria completa, GitHub Release e publicação npm com provenance. Veja `docs/RELEASES.md`.
