# Iconografia RN

Existem duas categorias diferentes de ícone e elas não devem ser confundidas.

## Símbolo de marca

`assets/brand/rn-icon.svg` é a assinatura RN escalável; `rn-icon.png` permanece como referência raster oficial. Use em favicon, avatar do produto, app icon, transição e composição de fundo.

No background oficial:

- grande no topo direito: até 608px, 6% de opacidade;
- pequeno no canto inferior esquerdo: até 120px, 14% de opacidade;
- ambos decorativos, sem nome acessível;
- não repetir como wallpaper, girar, recolorir ou usar como botão.

O componente CSS `rn-brand-canvas` implementa essa regra.

## Ícones de interface

- Preferência para novos apps React: Phosphor Outline, peso `regular`.
- Heroicons Outline é fallback quando não existir equivalente semântico.
- RN Mail legado usa Material Symbols Outlined; mantenha essa família dentro da integração, mas não misture duas famílias na mesma superfície.
- Tamanhos: 16px compacto, 20px padrão, 24px navegação/ação e 32px feature/empty state.
- Stroke regular e cantos coerentes; não misture ícones filled e outline sem que o filled indique estado selecionado.

## Semântica

- Decorativo ao lado de texto visível: `aria-hidden="true"`.
- Significativo sem texto equivalente: texto alternativo acessível.
- Dentro de botão sem label visível: o botão recebe `aria-label`.
- Toggle expõe `aria-pressed`; disclosure expõe `aria-expanded`.
- Ícone não substitui status textual, mensagem de erro ou heading.

## Proibições

- Emoji como ícone de produto.
- Redesenhar, simplificar ou recolorir os paths do SVG oficial.
- Duas bibliotecas na mesma view.
- Ícone clicável sem alvo mínimo de 44×44px.
- Tooltip como único nome acessível.
