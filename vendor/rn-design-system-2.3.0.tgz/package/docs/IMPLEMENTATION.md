# Guia de implementação

## Ordem de importação

CSS puro, Vite, Next.js ou outro bundler:

```css
@import "../tokens/rn.css";
@import "../styles/rn-base.css";
@import "../styles/rn-components.css";
```

Os tokens devem entrar primeiro. Não copie variáveis para o app; consuma a fonte única.

## Tema e cenas

O sistema possui um único tema e não implementa alternância por preferência do sistema. Product usa canvas branco. Story pode usar as superfícies fixas `scene`, `scene-stage` e `scene-deep` extraídas do orçamento; elas são capítulos editoriais, não dark mode.

`color-scheme: light` permanece declarado para controles nativos. Superfícies `soft`, `muted` e `brand` agrupam conteúdo Product; scene tokens só entram em narrativa, prova visual, processo, FAQ e fechamento.

## Consumo como pacote

O `package.json` exporta tokens, CSS, contratos, direção de arte, assets e a biblioteca React:

```ts
import "@rn-design/system/tokens.css";
import "@rn-design/system/base.css";
import "@rn-design/system/components.css";
import { rn } from "@rn-design/system/tokens";
import { rnCssTokens } from "@rn-design/system/manifest";
import { RnButton, RnCombobox } from "@rn-design/system/react";
import componentContracts from "@rn-design/system/contracts";
```

Subpaths adicionais de marca e agentes:

- `@rn-design/system/art-direction` → contrato JSON de criação de artes;
- `@rn-design/system/art-prompt` → system prompt em Markdown;
- `@rn-design/system/logo.png` → lockup oficial;
- `@rn-design/system/icon.svg` → símbolo vetorial oficial;
- `@rn-design/system/wordmark-video` → abertura WebM oficial.
- `@rn-design/system/wordmark-poster` → quadro final PNG da abertura oficial.

Markdown e WebM devem ser tratados como assets pelo bundler/servidor consumidor; não suponha que todo runtime JavaScript os importe como módulo.

Durante desenvolvimento local, use workspace, `file:../system-Design-RN` ou copie o pacote mantendo a mesma estrutura.

`rnCssTokens` é o mapa completo e gerado de todos os custom properties. `rn` mantém os grupos curados para uso cotidiano. A fonte editável é sempre `tokens/rn.css`; após mudar tokens rode `npm run tokens:sync` e nunca edite `rn.manifest.*` manualmente.

## Consumo por agentes

`agent/index.json` é a entrada estável e estruturada para ferramentas e agentes. Ele lista status, modos permitidos, estados obrigatórios, fontes, documentação, receitas de motion, templates e comandos de qualidade. O pacote também o exporta como `@rn-design/system/agent`; contratos ficam em `@rn-design/system/contracts/<id>` e o schema em `@rn-design/system/contract.schema`.

Fluxo mínimo:

1. leia `agent/index.json` e selecione Product ou Expressive;
2. siga `agent/create-frontend.md` ou `agent/refactor-frontend.md`;
3. resolva os caminhos `source`, `docs`, `starter` e `override` indicados pelo índice;
4. implemente todos os `requiredStates`, não apenas o estado ideal;
5. finalize com `agent/validate.md` e o contrato de entrega.

Para arte, campanha, post, banner, capa, imagem ou vídeo, selecione a rota `create-brand-art` do índice e siga `agent/create-art.md`. O painel `/#direcao-de-arte` gera o prompt e um JSON do brief; o contrato normativo permanece em `agent/art-direction.json`. Antes da produção, confirme CTA, mídia, conteúdo obrigatório, direitos e fontes, além dos assets e restrições derivados do contrato.

Rode `npm run agent:check` quando alterar o painel, inventário, templates, componentes, motion ou playbooks. Esse gate detecta IDs duplicados, referências ausentes e divergência entre as âncoras do índice e as seções visuais.

## React + TypeScript

`src/react/` é a fonte canônica e `examples/react/` apenas reexporta essa implementação. Consulte `docs/REACT-LIBRARY.md`. Regras:

- Componente visual não possui regra de negócio.
- Props estendem atributos nativos.
- `forwardRef` quando foco/integração precisar da referência.
- Variante é união tipada, não string livre.
- Estado semântico vem do elemento nativo (`disabled`, `required`, `aria-invalid`).
- Lógica reutilizável vira hook, não `useEffect` duplicado.
- Rotas/features pesadas usam lazy loading.

## Tailwind CSS v4

Importe tokens e a bridge:

```css
@import "@rn-design/system/tokens.css";
@import "@rn-design/system/tailwind.css";
@import "tailwindcss";
```

A bridge mapeia nomes semânticos como `bg-background`, `text-foreground`, `bg-primary`, `text-muted-foreground`, `border-border` e `ring-ring`.

Mesmo em Tailwind:

- evite arbitrary values (`[#...]`, `[13px]`) quando existe token;
- crie componente para padrão repetido;
- mantenha estados focus/disabled/loading na API;
- não replique a paleta no config.

## shadcn/ui

Mapeie os tokens semânticos já expostos pela bridge. Ajustes recomendados:

- radius padrão `var(--rn-radius-md)`;
- primary usa sky/azul-celeste com texto ink;
- accent usa ciano com texto ink;
- destructive usa token danger;
- ring usa `focus` (`#14538C`); ciano/sky continua como acento;
- font-sans usa Montserrat RN.

Preserve a semântica Radix. Branding é aplicado por tokens, não reescrevendo comportamento de dialog, popover ou menu.

## Ícones

Preferência React:

```tsx
import { ArrowRight, Gear, Plus } from "@phosphor-icons/react";

<button className="rn-icon-button" aria-label="Abrir configurações">
  <Gear aria-hidden="true" size={20} weight="regular" />
</button>
```

Não importe duas bibliotecas na mesma view. Faça code splitting se um pacote de ícones impactar o bundle e importe por módulo quando suportado.

## Assets e imagens

- Hero crítico: width/height ou aspect-ratio, sem lazy loading.
- Imagem abaixo da dobra: `loading="lazy" decoding="async"`.
- Conteúdo fotográfico: WebP/AVIF e `srcset/sizes`.
- Logo: não recomprimir nem converter sem comparar transparência/qualidade.

## Motion

CSS cobre feedback simples. GSAP/Framer Motion só entra quando a composição Expressive exige sequência, scroll ou física.

Padrão de segurança:

```ts
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

if (reduceMotion) {
  // Renderize o estado final. Não aguarde animationend.
} else {
  // Anime apenas transform/opacity e permita interrupção.
}
```

No React, encapsule a media query em hook compartilhado.

### Wordmark por superfície

Declare a escala de `RnAnimatedWordmark` no componente, sem reduzir seus filhos por CSS local:

```tsx
<RnAnimatedWordmark size="hero" timing="overlap" />
<RnAnimatedWordmark size="showcase" />
<RnAnimatedWordmark size="panel" />
<RnAnimatedWordmark animated={false} size="compact" />
```

- `hero`: hero principal e exportação oficial em vídeo;
- `showcase`: rota `/animacoes`;
- `panel`: Motion Studio e blueprint da Direção de arte;
- `compact`: Playground, Quality Lab e miniaturas.

`showcase`, `panel` e `compact` usam unidades relativas ao contêiner para caber em abas e cards. O default `hero` existe por compatibilidade e não deve ser aceito implicitamente em previews.

### Exportação da abertura oficial

```powershell
npm run motion:export
```

O script grava a rota técnica `/motion-export` em 1920×1080 e substitui `assets/brand/rn-wordmark-hero.webm`. O resultado esperado é um WebM sem áudio, com aproximadamente 4,6 segundos e quadro final estático. Depois de regenerar, atualize `assets/brand/metadata.json` e rode a auditoria completa.

## Layout

Use container + grid:

```html
<main id="main-content">
  <section class="rn-section">
    <div class="rn-container rn-auto-grid" style="--rn-grid-min: 18rem">
      <!-- cards -->
    </div>
  </section>
</main>
```

Para a assinatura de background, não crie assets ou pseudo-elementos locais:

```html
<section class="rn-brand-canvas rn-brand-canvas--editorial">
  <div class="rn-container rn-section"><!-- conteúdo --></div>
</section>
```

Use a variante base em produto, `--editorial` em landing/proposta e `--quiet` em áreas densas. Ela mantém o canvas branco, o grid, o símbolo grande no topo direito e o menor no canto inferior esquerdo.

Para novas páginas orientadas por marca, prefira as primitives extraídas do orçamento:

```html
<main class="rn-story-page">
  <section class="rn-story-hero"><!-- wordmark + conteúdo --></section>
  <section class="rn-story-scene rn-story-scene--dark">
    <div class="rn-story-scene__inner rn-story-split"><!-- capítulo --></div>
  </section>
  <section class="rn-story-scene"><!-- prova/ticket --></section>
</main>
```

Use `examples/html/budget-dna.html` ou os componentes `RnStoryHero` e `RnStoryScene` como ponto de partida. Não redesenhe hero, orbitais, progress line, handoff ou ticket em cada app.

Para produto complexo, CSS Grid controla macro layout e flex controla alinhamento interno. Filhos de grid/flex com texto recebem `min-width:0`.

## Dados

- Formate com `Intl.NumberFormat("pt-BR")` e `Intl.DateTimeFormat("pt-BR")`.
- Não armazene moeda formatada como número de domínio.
- Tabelas e KPIs usam tabular nums.
- Preserve timezone e informe período/fonte em dashboards.

## Testes esperados

- Unitários: variantes, props semânticas e formatação.
- Componentes: axe e interação por teclado.
- E2E: fluxos críticos, loading/error/success e foco após navegação/modal.
- Visual: 375, 768, 1024, 1440; fidelidade ao DNA do orçamento; Product branco; scene contrast; escalas contextuais do wordmark; aba de arte; reduced motion.
- Performance: imagens com dimensões, lazy routes e listas grandes virtualizadas.

## Comandos de qualidade

```powershell
npm run tokens:check # detecta drift entre CSS e manifestos gerados
npm run agent:check  # valida o índice estruturado e suas referências
npm run test         # contraste, seletores, links e semântica estrutural
npm run typecheck    # aplicação e exemplos React
npm run build        # artefato Vite com documentação e rota /orcamento
npm run test:dist    # integridade de rotas e links no dist
npm run audit        # todos os gates + npm pack --dry-run
```

O build publica `/`, `/orcamento`, `/animacoes`, `/carregamento`, `/quality`, `/motion-export`, `/catalog.html`, `/agent`, `/docs`, `/tokens`, `/design-system`, `/styles`, `/src`, `/examples` e `/AGENTS.md`. Assim, todo caminho citado pelo índice estruturado continua legível também no artefato web, não apenas no repositório e no pacote npm. A rota `/animacoes` demonstra a sequência oficial compartilhada por `RnAnimatedWordmark`: letras no eixo vertical, montagem do `RnBrandMark` e lockup final. `/motion-export` existe somente para a gravação reproduzível do WebM; a experiência humana de direção de arte permanece no painel em `#direcao-de-arte`. Em `/carregamento`, **Montagem com impacto — 01** é a única coreografia pública oficial e oferece escala `xl` para splash/troca de contexto; as outras nove permanecem apenas como exploração histórica do laboratório. O painel principal e o índice estruturado nunca apresentam essas alternativas como variantes de produção.

## Migração de app legado

1. Importe tokens sem alterar visual.
2. Substitua cores/spacing/radius repetidos por tokens.
3. Normalize Button, Field, Card e Navigation.
4. Corrija semântica/foco/contraste.
5. Escolha Product ou Expressive por área.
6. Remova overrides e `!important` obsoletos.
7. Só então simplifique motion e layout.

Não faça um big bang se o app estiver em produção; migre por componente/rota com comparação visual.
