# Padrões de tela

Receitas estruturais para agentes e times. Adapte conteúdo; preserve hierarquia e regras.

## Shell de produto

Estrutura medida no RN Mail: topbar de 64px, sidebar de 216px em desktop, controles de 40–44px e linhas principais de 52px. O canvas permanece branco; use `rn-brand-canvas--quiet` apenas na região vazia/de leitura, sem cobrir listas e tabelas com textura.

```text
Topbar (produto, contexto, ações)
├─ Sidebar / drawer (destinos)
└─ Main
   ├─ Breadcrumb opcional
   ├─ Page header: título + apoio + uma CTA primária
   ├─ Filtros / tabs
   ├─ Conteúdo: KPIs, lista, tabela ou form
   └─ Feedback: loading / empty / error / success
```

- Sidebar a partir de 1024px quando há seis ou mais destinos.
- Mobile prioriza título, dado principal e CTA; filtros podem abrir drawer/sheet.
- Sticky topbar compensa scroll e foco.

## Dashboard

```text
Page header + período + ação
KPI grid (2 mobile / 4 desktop)
Insight principal / gráfico
Comparações secundárias
Tabela detalhada
Fonte e atualização dos dados
```

- Não comece por um mosaico de cards sem hierarquia.
- Destaque a pergunta principal do dashboard.
- Gráfico tem resumo textual e tabela alternativa.

## Lista de gestão

```text
Título + contagem + criar
Busca + filtros ativos em chips
Bulk actions (somente após seleção)
Lista/tabela
Paginação
```

- Busca mantém label acessível.
- Chips fazem wrap; `+n` é disclosure operável.
- Empty state muda conforme filtros: “nenhum resultado” não é “nenhum item criado”.
- Preserve filtros, página e scroll ao voltar do detalhe.

## Formulário de criação/edição

```text
Título + status de salvamento
Error summary (quando necessário)
Seção: dados essenciais
Seção: configuração
Seção: permissões/avançado (progressive disclosure)
Footer: cancelar + salvar
```

- Uma coluna até 720px para leitura previsível.
- Duas colunas apenas para campos curtos e relacionados.
- Long forms têm autosave/draft ou confirmação ao sair.
- Erro não apaga entrada; submit loading evita duplicidade.

## Detalhe de entidade

```text
Breadcrumb
Identidade + status + ações
Resumo/KPIs
Tabs: visão geral, atividade, arquivos, configurações
Conteúdo da tab
```

- URL/deep link por tab quando o conteúdo é compartilhável.
- Ação destrutiva vai para menu ou zona separada.
- Back restaura contexto da lista.

## Auth

```text
Atmosfera RN sutil (grid/halo)
Card central
Logo
Eyebrow + descrição
Form
Ajuda/recuperação
Slogan opcional
```

O form é o foco; ribbons, scan e glow não podem competir nem atrasar interação.

## Landing/Proposta Expressive

```text
Intro de marca
Hero: contexto + promessa + CTA
Problema/objetivo
Solução/evidência visual
Processo
Cases/prova
Investimento/condições
FAQ
CTA final + contatos
```

- Cada capítulo é compreensível isoladamente.
- Motion reforça progressão e se reduz no mobile.
- Preço/condições aparecem sem exigir interação.
- CTA final usa linguagem específica e oferece próximo passo claro.

Este é o padrão visual de maior autoridade no sistema. Implemente com `rn-story-hero`, `rn-story-scene`, `rn-story-split`, `rn-story-media-frame` e `rn-story-ticket`. Mesmo apps Product devem reutilizar uma versão reduzida desses sinais em cabeçalhos, onboarding, empty states ou momentos de aprovação.

## Empty state

Tipos:

1. **Primeiro uso:** explique benefício + criar.
2. **Sem resultados:** diga que filtros não encontraram itens + limpar filtros.
3. **Sem permissão:** explique restrição + contato/solicitação.
4. **Erro:** descreva falha + tentar novamente/ajuda.

Não use a mesma ilustração/texto para os quatro estados.

## Error page

- Código é secundário; explique o que aconteceu.
- Ofereça rota segura: voltar, início ou tentar novamente.
- Preserve suporte/ID técnico de forma copiável quando útil.
- 404 pode ter personalidade; 401/403/500 devem priorizar clareza e segurança.

## Responsive checklist por padrão

- Header não comprime título ou CTA.
- Grids viram 1–2 colunas sem ordem incorreta.
- Tabela prioriza colunas e oferece detalhe; wrapper de scroll é fallback.
- Modal cabe em `100dvh` e footer não cobre campos.
- Sidebar vira drawer/top/bottom nav sem duplicar hierarquia.
- Touch targets e labels permanecem visíveis.
