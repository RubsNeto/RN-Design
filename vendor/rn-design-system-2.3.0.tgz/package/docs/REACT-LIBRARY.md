# Biblioteca React

`@rn-design/system/react` é a implementação canônica e tipada dos componentes do RN Design System. O painel e a fixture de qualidade consomem este mesmo código; `examples/react/` apenas reexporta a fonte para não criar cópias divergentes.

## Instalação e CSS

```bash
npm install @rn-design/system react react-dom
```

```ts
import "@rn-design/system/tokens.css";
import "@rn-design/system/base.css";
import "@rn-design/system/components.css";
```

React e React DOM são `peerDependencies` compatíveis com React 18.2 ou superior.

## Import público

```tsx
import {
  RnButton,
  RnCombobox,
  RnDateTimeField,
  RnDialog,
  RnField,
} from "@rn-design/system/react";
```

Imports individuais também são públicos:

```tsx
import { RnButton } from "@rn-design/system/react/RnButton";
```

## Famílias

| Família | Exports principais |
|---|---|
| ações e superfícies | `RnButton`, `RnCard`, `RnCardLink` |
| formulários | `RnField`, `RnSelect`, `RnTextarea`, `RnCheckbox`, `RnSwitch`, `RnSearch` |
| seleção avançada | `RnCombobox`, `RnDateTimeField`, `RnDateRangeField`, `RnSegmented`, `RnTabs` |
| feedback | `RnAlert`, `RnToast`, `RnEmptyState`, `RnSkeleton`, `RnProgress`, `RnErrorSummary` |
| navegação e dados | `RnBreadcrumb`, `RnPagination`, `RnStepper`, `RnDataTable`, `RnBarChart` |
| overlays | `RnDialog`, `RnDrawer`, `RnPopover`, `RnPopoverTrigger`, `RnTooltip` |
| identidade e marca | `RnAvatar`, `RnBrandMark`, `RnBrandCanvas`, `RnAnimatedWordmark`, `RnBrandLoader` |
| narrativa | `RnStoryHero`, `RnStoryScene` |

## Exemplo acessível

```tsx
const [clientId, setClientId] = useState<string | null>(null);

<RnCombobox
  label="Cliente"
  options={clients}
  value={clientId}
  onValueChange={(option) => setClientId(option?.id ?? null)}
  loading={query.isPending}
  error={errors.clientId}
/>
```

O componente implementa label, `aria-expanded`, `aria-controls`, `aria-activedescendant`, listbox, option, anúncio de resultados, setas, Home, End, Enter e Escape. A regra de negócio e a busca remota continuam no app consumidor.

## Data e intervalo

Use controles nativos antes de um calendário composto:

```tsx
<RnDateTimeField kind="date" label="Vencimento" min={today} />

<RnDateRangeField
  legend="Período"
  startValue={range.start}
  endValue={range.end}
  onRangeChange={setRange}
/>
```

## Visualização de dados

`RnBarChart` limita a cinco séries, mantém o plot fora da leitura duplicada e sempre produz uma tabela equivalente. Declare `state="loading|ready|empty|error|partial|no-permission"` quando o estado vier de uma consulta.

## Wordmark e escalas contextuais

```tsx
<RnAnimatedWordmark size="hero" timing="overlap" />
```

`size` aceita `hero`, `showcase`, `panel` e `compact`. Use `hero` no hero e na gravação institucional, `showcase` na demonstração dedicada, `panel` em áreas documentais amplas e `compact` em cards/fixtures. `timing="overlap"` é a abertura do hero; `sequential` demonstra as etapas separadamente. Para miniatura sem motion, use `animated={false}`.

As escalas menores respondem ao contêiner. Não envolva o componente em uma classe que reduza letras ou símbolo por seletores internos; escolha a prop correta para impedir que o tamanho monumental vaze para outras abas.

Para usar apenas o símbolo vetorial, `RnBrandMark` aceita `size="sm|md|lg|xl|fluid"`. Use `sm` em affordances compactas, `md` como padrão de conteúdo, `lg` em destaques, `xl` em splash/brand showcase e `fluid` somente quando o contêiner já controlar largura e altura. A geometria e as cores continuam sendo as nove peças oficiais em qualquer escala.

## Critério de estabilidade

Um export é `stable` somente quando possui:

- implementação pública tipada;
- contrato em `agent/contracts/components/`;
- estados e teclado documentados;
- axe, interação e/ou regressão visual aplicáveis;
- comportamento final em `prefers-reduced-motion`.
