# Releases

O pacote, o índice de agentes, os tokens e o Master compartilham a mesma versão SemVer.

## Preparação

1. atualize `package.json`, `agent/index.json`, `tokens/rn.tokens.json` e a versão do Master;
2. documente a versão em `CHANGELOG.md`;
3. execute `npm run tokens:sync` e `npm run contracts:sync`;
4. execute `npm run audit`;
5. inspecione o conteúdo com `npm pack --dry-run`.

`npm run release:check` falha se qualquer versão, changelog ou tag estiver divergente.

## Publicação

Uma tag `vX.Y.Z` dispara:

1. auditoria completa em Windows, incluindo snapshots;
2. auditoria estática em Linux;
3. geração do tarball;
4. GitHub Release;
5. `npm publish --provenance --access public`.

O ambiente GitHub `npm` deve conter `NPM_TOKEN`. Nenhuma publicação ocorre por push comum em `main`.

## SemVer

- patch: correção compatível de comportamento, estilo ou documentação;
- minor: componente/export/template novo compatível;
- major: remoção, rename, mudança de prop/semântica ou token incompatível.
