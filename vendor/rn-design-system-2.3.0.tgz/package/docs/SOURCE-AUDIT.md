# Auditoria das fontes

Data da análise: 22/08/2026.

## Escopo analisado

### Proposta comercial

Origem: `C:\Users\ruben\Documents\GitHub\proposta`

- Stack: React 19, TypeScript, Vite, GSAP/ScrollTrigger, Framer Motion e Lenis.
- CSS principal: `src/styles/global.css`.
- Assets oficiais: `public/assets/brand` e `public/assets/fonts`.
- Componentes relevantes: BrandNav, SectionLabel, Typewriter, ScrollProgress, invitation/envelope, portfolio, process, pricing e FAQ.
- Breakpoints legados: 600, 900, 1150 e 1500px.
- Evidência visual validada no app em execução e nos arquivos da pasta `reference/`; os screenshots BROUD dessa pasta servem somente como referência de composição.

O ZIP aberto anteriormente em `C:\tmp\template-proposta-empresa-exemplo` é o mesmo build. O CSS compilado e o logo possuem os mesmos hashes SHA-256 do repositório; ele não representa uma terceira direção visual.

### RN Mail

Origem: `C:\Users\ruben\Documents\GitHub\email`

- Produto customizado sobre Mailcow e SOGo 5.12.
- CSS relevante: `rn-overrides.css` e `mailcow-ui-light.css`.
- Tema Angular Material: `custom-theme.js`.
- Login: `rn-login.js`.
- A mesma fonte Montserrat e os mesmos assets de marca da proposta.

## Evidência convergente

Os dois produtos repetem:

- Montserrat variável 100–900.
- Navy `#0A2540`, azul `#1A6FAE`, sky `#47ABE1`, azul suave `#5A9AEE` e ciano `#3FD0E9`.
- Neutros frios e superfícies off-white/brancas.
- Gradiente navy/azul em chrome e gradiente sky/ciano em acento.
- Grid fino, halo radial, scan de brilho e motif pixelado.
- Controles de 40–56px, pills e raios entre 8–24px.
- O legado usava focus ring ciano/sky com 3px; o sistema consolidado usa `#14538C` para alcançar contraste não textual em canvas branco.
- `prefers-reduced-motion` explícito.
- Linguagem direta, próxima e orientada a resultado.

## Medidas visuais encontradas

| Evidência | Valor observado | Decisão do sistema |
|---|---:|---|
| Grid do hero da proposta | 160×180px; azul a 3,5% | `gridEditorialX/Y` |
| Orbitais do hero | 120px e 360px; traço a 7% | até dois orbitais editoriais |
| Wordmark/display | 84–212px; peso 800 | display RN limitado a 96px em apps comuns |
| H1 da proposta | 64–80px; peso 500; tracking −0,045em | título fluido 40–72px; peso 650 |
| Composição do hero | 920/432px; gap 88px; container 1440px | grid editorial 2/3 + 1/3 |
| Topbar da proposta | 60px | topbar editorial 60–64px |
| Topbar do RN Mail | 64px | topbar Product 64px |
| Sidebar do RN Mail | 216px | rail Product 216px desktop |
| Linhas do RN Mail | 42–52px; 62px mobile | densidade Product |
| Grid do RN Mail | 32–44px; azul a 2,2–4,5% | grid Product 40px |
| Marca d’água do rail | ícone 124px; 3,5% | marca pequena até 120px; variante quiet |
| Marca d’água da leitura | logo 260–440px; 1,8–2,4% | símbolo grande até 608px; 3–6% |

## Decisão explícita de direção

A direção mais recente do proprietário torna a página do orçamento a fonte majoritária do Design System. Portanto:

- a proposta define visual, composição, tipografia, escala, cor e motion;
- Product permanece white-first, mas é uma redução do orçamento — não uma reprodução visual do SOGo;
- capítulos carvão/navy da proposta são superfícies editoriais canônicas, não dark mode;
- o RN Mail contribui somente com comportamento operacional de tabelas, listas, formulários, toolbar e sidebar;
- a composição com símbolo grande no topo direito e pequeno no canto inferior esquerdo permanece como variante Product/Brand Canvas;
- o hero Story usa a composição original do orçamento: wordmark monumental, grid 160×180px, halo e orbitais de 120/360px.

## Assets oficiais preservados

| Asset | Dimensão | SHA-256 |
|---|---:|---|
| `rn-logo.png` | 821×400 | `D81E993CF61F3B5E4A6EE613A6B7DB986B50C2EB9DC9E1318A4C3586AA389AD0` |
| `rn-icon.png` | 384×384 | `21E0BEEB6797B89849552D8351FD68B92EB9DC1846404DEB6202023881ACE544` |
| `rn-icon.svg` | viewBox 384×384, 9 paths | `1F42F2791FC243F09B799CBCF087FE36A75C0F4B79A4E57AEF0251C355B4B529` |
| `montserrat.woff2` | variável | `66E30997A2F0237C8A932EEDAED76476883628A503ED88647DCB0BC47288C4A1` |

Os hashes das cópias em `proposta` e `email` são idênticos.

## Decisões de síntese

### Um Core e dois modos

`proposta` é o DNA visual dominante. `email` demonstra apenas disciplina operacional. O sistema não faz uma média estética entre eles: deriva Product do orçamento e importa do e-mail somente os comportamentos ausentes na referência principal.

### Paleta oficial acima de recomendações genéricas

A busca auxiliar de design sugeriu uma direção genérica de brutalismo, rosa e Archivo/Space Grotesk. Essa estética foi rejeitada porque conflita com a página do orçamento e com a instrução de branding. Foram aproveitados apenas o padrão de scroll storytelling e os guardrails de performance, foco, responsividade e reduced motion.

### Contraste ajustado

O RN Mail usa, em um ponto, branco sobre `#287FAA`, relação calculada de 4.46:1. A direção atual promove o azul-celeste `#47ABE1` e usa ink `#07141F` sobre ele, relação 7.25:1. Links sobre branco usam `#1A6FAE`, relação 5.35:1.

## O que não herdar literalmente

- A pasta `reference/` da proposta contém screenshots da marca BROUD usados como referência de composição; não são assets nem branding RN.
- `rn-overrides.css` acumulou várias camadas históricas e muitos `!important` por restrição do SOGo. Isso não é arquitetura recomendada para apps novos.
- Motion cinematográfico, cursor customizado, tilt e scroll scrub pertencem ao modo Expressive, não a produto operacional.
- Glyphs como setas Unicode não devem virar o sistema de ícones. Novos apps usam Phosphor Outline.
- Valores raw de cor, raio, sombra e espaçamento encontrados nos legados foram normalizados em tokens.
- Blur/glass é limitado a login, modal e cena de marca; não é base para tabela ou lista densa.

## Resultado

O sistema resultante preserva a identidade real do orçamento como centro e acrescenta portabilidade, contraste, semântica, consistência, manutenção e capacidade de geração por agentes de IA.
