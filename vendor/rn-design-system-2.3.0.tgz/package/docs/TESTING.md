# Estratégia de qualidade

## Pirâmide de prova

| Camada | Comando | Cobre |
|---|---|---|
| integridade gerada | `npm run tokens:check`, `npm run contracts:check` | drift entre fontes e artefatos |
| contrato do sistema | `npm run agent:check`, `npm run validate` | IDs, links, assets, rotas, estados e autoridade |
| unidade/estrutura | `npm test` | contraste, semântica, schema, CLI e pacote ESM |
| tipos/build | `npm run typecheck`, `npm run build` | APIs React, exemplos e produção |
| navegador | `npm run test:e2e` | axe, teclado, foco, interações e snapshots |
| entrega | `npm run audit` | todas as camadas e `npm pack --dry-run` |

## Viewports oficiais

- 375 × 812: mobile;
- 768 × 1024: tablet;
- 1024 × 900: desktop;
- 1440 × 1000: wide.

Playwright executa a rota determinística `/quality` e o painel principal. A fixture cobre componentes canônicos; o painel cobre Playground, Motion Studio, Direção de arte e documentação integrada.

## Regressão visual

Atualize snapshots somente após revisar a alteração:

```bash
npm run test:e2e:update
```

Snapshots Windows são intencionais porque a CI visual usa `windows-latest`. Uma atualização sem mudança explicável em código, tokens ou fonte deve ser rejeitada.

## Acessibilidade

```bash
npm run test:a11y
```

Axe verifica WCAG A/AA. A revisão manual ainda cobre leitura por screen reader, zoom 200%, landscape, ordem de foco, retorno de foco, conteúdo sem CSS/JS e preferências de movimento.

## Motion

Testes usam reduced motion por padrão para estabilidade. O Motion Studio mantém controles explícitos de replay, pause, velocidade, scrub e comparação do fallback; nenhum fluxo depende de `animationend`.

As escalas do wordmark são verificadas por superfície e por contenção: `hero`, `showcase`, `panel` e `compact` não podem transbordar o contêiner nem criar scroll horizontal. O WebM oficial também é validado por assinatura de arquivo, checksum, dimensões 1920×1080, duração entre 2 e 6 segundos, ausência de áudio declarada e budget máximo de 5 MB.

## Direção de arte

Os testes do painel confirmam:

- âncora canônica `#direcao-de-arte` alinhada ao índice;
- atualização de dimensões, proporção, safe area e objetivo no prompt;
- extração do negative prompt;
- brief JSON com `generateLogo: false`, `generateText: false` e revisão humana obrigatória;
- links de download do logo PNG, símbolo SVG/PNG, animação WebM, halo e pixels;
- filename sugerido e metadata real do vídeo;
- snapshot da aba nos quatro viewports;
- contrato e prompt presentes no build/pacote.

A revisão manual precisa conferir CTA, mídia, conteúdo obrigatório, direitos e fontes preenchidos no Prompt Studio, além dos assets e restrições derivados do contrato.
