# Gramática visual RN

Este documento transforma a página do orçamento em uma composição reproduzível por pessoas e agentes de IA. O RN Mail aparece somente como referência secundária para interfaces operacionais. Ele complementa o `MASTER.md`; em caso de conflito visual, prevalece o orçamento.

## Evidência consolidada

| Elemento | Proposta/orçamento | RN Mail | Regra consolidada |
|---|---|---|---|
| Fonte | Montserrat variável 100–900 | Montserrat variável 100–900 | Uma única família: Montserrat RN |
| Canvas | Hero branco; capítulos `#202020`, `#1A1D1D` e `#16191C` | Branco em lista e toolbar | Product branco; Story alterna superfícies como o orçamento |
| Grid editorial | 160×180px, azul a 3,5% | — | Marketing, proposta e onboarding |
| Grid de produto | — | 32–44px, azul a 2,2–4,5% | App, dashboard e leitura vazia |
| Assinatura | Wordmark monumental, ícone, halo e orbitais | Ícone 124px; logo 260–440px em baixa opacidade | Story usa wordmark/orbitais; Product usa marcas de canto |
| Círculos/orbitais | 120px e 360px, traço azul a 7% | Halo radial leve | Até dois orbitais em momentos editoriais |
| Layout amplo | Container 1440px; composição 920/432px | Shell 64/216px; linhas 42–52px | Duas organizações oficiais: editorial e produto |

O orçamento é a evidência dominante. Suas cenas escuras foram promovidas a capítulos Story canônicos; não são dark mode e não devem contaminar áreas densas de Product.

## Duas composições oficiais de background

### Story Hero — composição primária

O hero do orçamento é a assinatura de maior autoridade:

1. papel branco/quase branco;
2. grid azul de 160 × 180px a aproximadamente 3,5%;
3. wordmark RN DESIGN em 84–212px;
4. ícone oficial em 84–172px;
5. halo radial azul;
6. orbitais de 120px e 360px;
7. conteúdo assimétrico 920/432px com gap de 88px;
8. linha de handoff e indicador de scroll.

Use as primitives `rn-story-hero`, `rn-story-wordmark`, `rn-story-title`, `rn-story-support`, `rn-capability-chips` e `rn-story-handoff`. A réplica integral vive em `src/`.

### Product Brand Canvas — composição derivada

O fundo não é apenas `background-color`. Ele possui quatro camadas:

1. papel branco puro;
2. grid azul-celeste quase imperceptível;
3. símbolo RN grande no topo direito, parcialmente recortado;
4. símbolo RN menor no canto inferior esquerdo, preferencialmente inteiro.

Use `rn-brand-canvas` para obter as quatro camadas sem elementos decorativos no DOM:

```html
<section class="rn-brand-canvas rn-brand-canvas--editorial">
  <div class="rn-container rn-section">
    <!-- conteúdo semântico -->
  </div>
</section>
```

### Geometria das marcas

| Marca | Desktop | Mobile | Opacidade | Posição |
|---|---:|---:|---:|---|
| Grande | até 608px | 208–288px | 6% | topo direito, recorte de 10–25% |
| Pequena | até 120px | 48–72px | 14% | canto inferior esquerdo, respiro ≥16px |

- As marcas usam `assets/brand/rn-icon.svg`; `rn-icon.png` é o fallback raster oficial.
- Não use o logo completo como textura repetida.
- Não gire, distorça ou recolora o símbolo.
- Não posicione texto crítico sobre as partes mais densas da marca.
- As marcas são decorativas: pseudo-elemento CSS ou `aria-hidden="true"` e `alt=""`.
- Em telas abaixo de 600px, reduza a escala e aumente o recorte da marca grande; não remova a assinatura inteira.

### Densidades

`rn-brand-canvas` usa grid de 40px e marcas discretas. É a escolha para produto.

`rn-brand-canvas--editorial` usa grid de 160×180px, marca grande a 6% e pequena a 14%. É uma alternativa derivada para onboarding, auth e páginas que não precisam do wordmark monumental.

`rn-brand-canvas--quiet` remove o halo e reduz as marcas pela metade. Use atrás de listas, formulários, tabelas ou leitura longa.

O grid nunca deve competir com texto. Se ele for percebido antes do conteúdo, sua opacidade está alta demais.

## Tipografia oficial

Carregue `assets/fonts/montserrat.woff2` antes da primeira pintura. A família cobre 100–900, mas o sistema usa deliberadamente quatro pesos:

| Papel | Tamanho | Peso | Line-height | Tracking |
|---|---:|---:|---:|---:|
| Wordmark RN | 84–212px | 800 | 0.94 | −0.035em |
| Hero Story | 64–80px | 500 | 1.14 | −0.045em |
| Brand display Product | 56–96px | 700 | 0.98 | −0.055em |
| Título de seção | 38–56px | 400–500 | 1.12 | −0.035em |
| Título de card | 20–24px | 650 | 1.25 | −0.02em |
| Corpo grande | 18–20px | 400 | 1.60 | normal |
| Corpo | 16px | 400 | 1.60 | normal |
| UI compacta | 13–14px | 500 | 1.40–1.55 | até 0.015em |
| Eyebrow | 12px | 700 | 1.30 | 0.12em |

Regras de composição:

- Use apenas Montserrat RN; Arial é fallback técnico, não uma segunda voz.
- Wordmark usa 800; hero Story usa 500. Product pode usar 650–700 para títulos de tarefa.
- Títulos curtos usam `text-wrap: balance`; parágrafos permanecem entre 45 e 75 caracteres por linha.
- Valores, datas e KPIs usam números tabulares.
- Uppercase fica restrito a eyebrow, navegação curta e metadados.
- Em mobile, display reduz para 40–56px e mantém a hierarquia; não encolha corpo abaixo de 16px.

As classes de referência são `rn-display`, `rn-title`, `rn-lead`, `rn-eyebrow`, `rn-muted` e `rn-tabular`.

## Organização editorial

Use para proposta, landing, portfólio e apresentações:

```text
Topbar branca: logo — linha/progresso — navegação curta
Hero Story branco: grid + orbitais + wordmark
├─ Selo/contexto
├─ H1 com uma expressão azul
├─ Chips + credencial
└─ Explicação + CTA em coluna secundária
Capítulo charcoal: objetivo
Capítulo stage/deep: devices e telas
Capítulo branco: pessoa/prova
Capítulo charcoal: processo
Capítulo branco: portfólio + ticket
Capítulo deep: FAQ + fechamento
```

- Container máximo: 1440px.
- Em desktop, use composição assimétrica próxima de 2/3 + 1/3; o projeto de origem usa 920/432px com gap de 88px.
- Em tablet e mobile, transforme em uma coluna na ordem semântica: contexto, título, apoio, CTA, evidência.
- Uma seção possui um ponto focal; não distribua o mesmo peso visual entre todos os cards.
- Preserve a alternância branco → carvão/stage → branco; ela é a cadência principal do orçamento.

## Organização de produto

Use para SaaS, ERP, CRM, portal, dashboard e ferramentas internas:

```text
Topbar 64px
├─ Identidade/contexto
├─ Busca ou navegação
└─ Ações do usuário
Shell
├─ Sidebar 216px em desktop
└─ Main fluido
   ├─ Page header
   ├─ Filtros/tabs
   ├─ Conteúdo principal plano
   └─ Feedback
```

- Ritmo de 8px; controles de 40–44px e alvos mínimos de 44px.
- Linhas de lista: 52px em desktop e 62px em mobile quando há duas linhas de texto.
- Tabelas e listas permanecem brancas; azul claro identifica hover/seleção.
- Cards são usados apenas para unidades conceituais, não em cada linha.
- O grid de 40px e as marcas d’água usam a variante `quiet` em áreas densas.

## Hierarquia visual

1. Título ou tarefa atual.
2. Dado, conteúdo ou decisão principal.
3. Uma ação primária azul-celeste.
4. Ações secundárias neutras.
5. Metadados e ajuda em texto sutil.

Azul-celeste aparece em CTA, seleção, wordmark, palavra de destaque, linha de progresso e reflexos. O foco usa o azul escuro semântico `focus` para manter contraste, podendo receber ciano apenas como acento adicional. Em Story o celeste pode dominar o wordmark; em Product continua concentrado em ação e estado.

## Contrato para agentes

Ao criar uma página RN:

1. leia `docs/DESIGN-DNA.md` e trate o orçamento como fonte principal;
2. escolha `Product` ou `Expressive` apenas como nível de intensidade;
3. em Story, comece com `rn-story-hero` e componha capítulos `rn-story-scene`;
4. em Product, use canvas branco e `rn-brand-canvas`/`quiet` como tradução reduzida;
5. use Montserrat RN e a escala exata por papel;
6. preserve celeste, grid, pills, linhas e um ponto focal;
7. mantenha marcas e orbitais decorativos fora da árvore de acessibilidade;
8. implemente o estado final sem depender de motion;
9. valide 375, 768, 1024 e 1440px.

Não improvise outra textura, posição de marca d’água, fonte, segunda cor principal ou linguagem genérica de SaaS.
