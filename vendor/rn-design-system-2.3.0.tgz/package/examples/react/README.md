# Exemplos React

Componentes de referência, não um pacote fechado. O diretório inclui Button, Card/CardLink, Field, Select, Textarea, Checkbox, Error Summary, Tabs, Dialog, Brand Canvas e primitives Story. Eles demonstram:

- props nativas e tipadas;
- ref encaminhada;
- variantes restritas;
- estados semânticos;
- ligação correta de label/helper/error.

Importe primeiro os três CSS do sistema e copie/adapte os componentes para a camada compartilhada do app.

```tsx
import type { CSSProperties } from "react";
import { ArrowRight } from "@phosphor-icons/react";
import { RnButton } from "./RnButton";
import { RnField } from "./RnField";

export function ProjectForm() {
  return (
    <form className="rn-stack" style={{ "--rn-stack-gap": "var(--rn-space-5)" } as CSSProperties}>
      <RnField
        label="Nome do projeto"
        name="name"
        autoComplete="off"
        description="Use um nome que a equipe reconheça rapidamente."
        required
      />
      <RnButton type="submit" trailingIcon={<ArrowRight size={20} weight="regular" />}>
        Criar projeto
      </RnButton>
    </form>
  );
}
```

Para link com aparência de botão, use `<a className="rn-button">`; não renderize um `button` para navegação.

Use `RnCardLink` quando o card inteiro navega. `RnTabs` implementa nomes, relacionamento painel/tab e teclado por setas. `RnDialog` usa `<dialog>` nativo; o app consumidor deve manter o trigger e restaurar o foco a ele ao fechar. Em `RnStoryHero`, informe `brandIconSrc` se o asset não estiver publicado em `/assets/brand/rn-icon.png`.
