export { RnTabs } from "../../src/react/RnTabs";
export type { RnTabItem, RnTabsProps } from "../../src/react/RnTabs";
