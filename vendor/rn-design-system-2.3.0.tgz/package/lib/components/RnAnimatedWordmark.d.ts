import type { HTMLAttributes } from "react";
export interface RnAnimatedWordmarkProps extends HTMLAttributes<HTMLDivElement> {
    animated?: boolean;
    size?: RnAnimatedWordmarkSize;
    timing?: "sequential" | "overlap";
}
export type RnAnimatedWordmarkSize = "hero" | "showcase" | "panel" | "compact";
export declare function RnAnimatedWordmark({ animated, className, size, timing, ...props }: RnAnimatedWordmarkProps): import("react").JSX.Element;
//# sourceMappingURL=RnAnimatedWordmark.d.ts.map