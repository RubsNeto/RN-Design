import type { HTMLAttributes } from "react";
export declare const RN_BRAND_LOADER_VARIANTS: readonly ["radial", "pulse", "orbit", "wave", "focus", "scan", "breathe", "magnetic", "cascade", "eclipse"];
export type RnBrandLoaderVariant = typeof RN_BRAND_LOADER_VARIANTS[number];
export interface RnBrandLoaderProps extends HTMLAttributes<HTMLDivElement> {
    announce?: boolean;
    iconSrc?: string;
    label?: string;
    paused?: boolean;
    size?: "sm" | "md" | "lg" | "xl";
    variant?: RnBrandLoaderVariant;
}
export declare function RnBrandLoader({ announce, className, iconSrc, label, paused, size, variant, ...props }: RnBrandLoaderProps): import("react").JSX.Element;
//# sourceMappingURL=RnBrandLoader.d.ts.map