import { type SVGAttributes } from "react";
interface MarkPiece {
    d: string;
    name: string;
    rotation: string;
    sequence: number;
    x: string;
    y: string;
}
export declare const RN_MARK_PIECES: MarkPiece[];
export interface RnBrandMarkProps extends Omit<SVGAttributes<SVGSVGElement>, "children"> {
    pieceClassName?: string;
    size?: "sm" | "md" | "lg" | "xl" | "fluid";
}
export declare function RnBrandMark({ className, pieceClassName, size, ...props }: RnBrandMarkProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=RnBrandMark.d.ts.map