import { type HTMLAttributes, type ReactNode } from "react";
export interface RnChartSeries {
    id: string;
    label: string;
}
export interface RnChartDatum {
    label: string;
    values: Readonly<Record<string, number>>;
}
export type RnChartState = "loading" | "ready" | "empty" | "error" | "partial" | "no-permission";
export interface RnBarChartProps extends Omit<HTMLAttributes<HTMLElement>, "title"> {
    title: string;
    description?: string;
    series: readonly RnChartSeries[];
    data: readonly RnChartDatum[];
    max?: number;
    state?: RnChartState;
    stateMessage?: string;
    stateAction?: ReactNode;
    showTable?: boolean;
    valueFormatter?: (value: number) => string;
}
export declare function RnBarChart({ title, description, series, data, max, state, stateMessage, stateAction, showTable, valueFormatter, className, ...props }: RnBarChartProps): import("react").JSX.Element;
//# sourceMappingURL=RnBarChart.d.ts.map