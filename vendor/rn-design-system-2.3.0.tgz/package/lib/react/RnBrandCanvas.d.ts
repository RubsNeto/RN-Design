import { type HTMLAttributes } from "react";
export type RnBrandCanvasDensity = "product" | "editorial";
export interface RnBrandCanvasProps extends HTMLAttributes<HTMLElement> {
    density?: RnBrandCanvasDensity;
    quiet?: boolean;
}
export declare const RnBrandCanvas: import("react").ForwardRefExoticComponent<RnBrandCanvasProps & import("react").RefAttributes<HTMLElement>>;
//# sourceMappingURL=RnBrandCanvas.d.ts.map