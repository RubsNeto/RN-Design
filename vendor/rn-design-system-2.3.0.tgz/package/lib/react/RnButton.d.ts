import { type ButtonHTMLAttributes, type ReactNode } from "react";
export type RnButtonVariant = "primary" | "accent" | "secondary" | "ghost" | "danger";
export type RnButtonSize = "sm" | "md" | "lg";
export interface RnButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: RnButtonVariant;
    size?: RnButtonSize;
    loading?: boolean;
    leadingIcon?: ReactNode;
    trailingIcon?: ReactNode;
}
export declare const RnButton: import("react").ForwardRefExoticComponent<RnButtonProps & import("react").RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=RnButton.d.ts.map