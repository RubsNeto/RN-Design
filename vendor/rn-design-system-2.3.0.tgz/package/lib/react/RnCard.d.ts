import { type AnchorHTMLAttributes, type HTMLAttributes } from "react";
export type RnCardVariant = "base" | "soft" | "raised" | "glass" | "brand";
export interface RnCardProps extends HTMLAttributes<HTMLDivElement> {
    variant?: RnCardVariant;
}
export declare const RnCard: import("react").ForwardRefExoticComponent<RnCardProps & import("react").RefAttributes<HTMLDivElement>>;
export interface RnCardLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
    variant?: RnCardVariant;
}
export declare const RnCardLink: import("react").ForwardRefExoticComponent<RnCardLinkProps & import("react").RefAttributes<HTMLAnchorElement>>;
//# sourceMappingURL=RnCard.d.ts.map