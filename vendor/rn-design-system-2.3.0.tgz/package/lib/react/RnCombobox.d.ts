import { type InputHTMLAttributes } from "react";
export interface RnComboboxOption {
    id: string;
    label: string;
    keywords?: readonly string[];
    disabled?: boolean;
}
export interface RnComboboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange"> {
    label: string;
    options: readonly RnComboboxOption[];
    value?: string | null;
    defaultValue?: string | null;
    onValueChange?: (option: RnComboboxOption | null) => void;
    description?: string;
    error?: string;
    loading?: boolean;
    loadingText?: string;
    noResultsText?: string;
}
export declare const RnCombobox: import("react").ForwardRefExoticComponent<RnComboboxProps & import("react").RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=RnCombobox.d.ts.map