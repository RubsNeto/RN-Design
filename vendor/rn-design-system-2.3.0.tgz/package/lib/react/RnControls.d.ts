import { type ButtonHTMLAttributes, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type ReactElement } from "react";
export interface RnSwitchProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onChange"> {
    checked: boolean;
    label: ReactNode;
    onCheckedChange?: (checked: boolean) => void;
}
export declare const RnSwitch: import("react").ForwardRefExoticComponent<RnSwitchProps & import("react").RefAttributes<HTMLButtonElement>>;
export type RnSearchStatus = "empty" | "typing" | "results" | "no-results" | "loading" | "error";
export interface RnSearchProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
    label?: string;
    icon?: ReactNode;
    status?: RnSearchStatus;
    resultCount?: number;
    statusMessage?: ReactNode;
}
export declare const RnSearch: import("react").ForwardRefExoticComponent<RnSearchProps & import("react").RefAttributes<HTMLInputElement>>;
export interface RnTooltipProps extends Omit<HTMLAttributes<HTMLSpanElement>, "children" | "content"> {
    content: ReactNode;
    open?: boolean;
    children: ReactElement<{
        "aria-describedby"?: string;
    }>;
}
export declare const RnTooltip: import("react").ForwardRefExoticComponent<RnTooltipProps & import("react").RefAttributes<HTMLSpanElement>>;
export type RnAvatarSize = "sm" | "md" | "lg" | "xl";
export interface RnAvatarProps extends HTMLAttributes<HTMLSpanElement> {
    name: string;
    src?: string;
    size?: RnAvatarSize;
}
export declare const RnAvatar: import("react").ForwardRefExoticComponent<RnAvatarProps & import("react").RefAttributes<HTMLSpanElement>>;
export interface RnProgressProps extends HTMLAttributes<HTMLDivElement> {
    label: string;
    value?: number;
    max?: number;
    status?: "default" | "complete" | "error";
    errorMessage?: string;
    showValue?: boolean;
    valueFormatter?: (value: number, max: number) => string;
}
export declare const RnProgress: import("react").ForwardRefExoticComponent<RnProgressProps & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=RnControls.d.ts.map