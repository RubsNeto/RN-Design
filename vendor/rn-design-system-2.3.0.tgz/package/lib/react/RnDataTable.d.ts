import type { Key, ReactNode } from "react";
export type RnSortDirection = "ascending" | "descending" | "none";
export type RnDataTableStatus = "ready" | "loading" | "error" | "partial";
export interface RnDataColumn<Row> {
    id: string;
    header: ReactNode;
    cell: (row: Row) => ReactNode;
    numeric?: boolean;
    sortDirection?: RnSortDirection;
    onSort?: (direction: Exclude<RnSortDirection, "none">) => void;
}
export interface RnDataTableProps<Row> {
    caption: string;
    columns: readonly RnDataColumn<Row>[];
    rows: readonly Row[];
    rowKey: (row: Row) => Key;
    emptyMessage?: string;
    status?: RnDataTableStatus;
    statusMessage?: ReactNode;
    isRowSelected?: (row: Row) => boolean;
    className?: string;
}
export declare function RnDataTable<Row>({ caption, columns, rows, rowKey, emptyMessage, status, statusMessage, isRowSelected, className, }: RnDataTableProps<Row>): import("react").JSX.Element;
//# sourceMappingURL=RnDataTable.d.ts.map