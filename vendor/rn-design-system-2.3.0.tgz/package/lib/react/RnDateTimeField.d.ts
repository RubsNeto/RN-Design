import { type HTMLAttributes, type InputHTMLAttributes } from "react";
export type RnDateTimeKind = "date" | "time" | "datetime-local";
export interface RnDateTimeFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "defaultValue" | "onChange"> {
    kind?: RnDateTimeKind;
    label: string;
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    description?: string;
    error?: string;
}
export declare const RnDateTimeField: import("react").ForwardRefExoticComponent<RnDateTimeFieldProps & import("react").RefAttributes<HTMLInputElement>>;
export interface RnDateRangeFieldProps extends Omit<HTMLAttributes<HTMLFieldSetElement>, "onChange"> {
    legend: string;
    startLabel?: string;
    endLabel?: string;
    startValue?: string;
    endValue?: string;
    min?: string;
    max?: string;
    disabled?: boolean;
    required?: boolean;
    error?: string;
    onRangeChange?: (range: {
        start: string;
        end: string;
    }) => void;
}
export declare const RnDateRangeField: import("react").ForwardRefExoticComponent<RnDateRangeFieldProps & import("react").RefAttributes<HTMLFieldSetElement>>;
//# sourceMappingURL=RnDateTimeField.d.ts.map