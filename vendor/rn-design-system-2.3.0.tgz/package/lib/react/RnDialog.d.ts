import { type DialogHTMLAttributes, type ReactNode } from "react";
export interface RnDialogProps extends Omit<DialogHTMLAttributes<HTMLDialogElement>, "open"> {
    open: boolean;
    title: string;
    description?: string;
    footer?: ReactNode;
    closeLabel?: string;
    onRequestClose: () => void;
}
export declare const RnDialog: import("react").ForwardRefExoticComponent<RnDialogProps & import("react").RefAttributes<HTMLDialogElement>>;
//# sourceMappingURL=RnDialog.d.ts.map