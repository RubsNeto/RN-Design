import { type HTMLAttributes } from "react";
export interface RnFormError {
    fieldId: string;
    message: string;
}
export interface RnErrorSummaryProps extends HTMLAttributes<HTMLDivElement> {
    errors: readonly RnFormError[];
    title?: string;
}
export declare const RnErrorSummary: import("react").ForwardRefExoticComponent<RnErrorSummaryProps & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=RnErrorSummary.d.ts.map