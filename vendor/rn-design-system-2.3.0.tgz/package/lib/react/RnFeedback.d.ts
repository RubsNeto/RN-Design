import { type HTMLAttributes, type ReactNode } from "react";
export type RnStatusTone = "info" | "success" | "warning" | "danger";
export interface RnAlertProps extends HTMLAttributes<HTMLDivElement> {
    tone?: RnStatusTone;
    title: string;
    icon?: ReactNode;
}
export declare const RnAlert: import("react").ForwardRefExoticComponent<RnAlertProps & import("react").RefAttributes<HTMLDivElement>>;
export interface RnChipProps extends HTMLAttributes<HTMLSpanElement> {
    tone?: "brand" | "neutral" | "success" | "warning" | "danger";
}
export declare const RnChip: import("react").ForwardRefExoticComponent<RnChipProps & import("react").RefAttributes<HTMLSpanElement>>;
export declare const RnBadge: import("react").ForwardRefExoticComponent<HTMLAttributes<HTMLSpanElement> & import("react").RefAttributes<HTMLSpanElement>>;
export interface RnToastProps extends HTMLAttributes<HTMLDivElement> {
    title: string;
    icon?: ReactNode;
    action?: ReactNode;
    announce?: "polite" | "assertive" | "off";
}
export declare const RnToast: import("react").ForwardRefExoticComponent<RnToastProps & import("react").RefAttributes<HTMLDivElement>>;
export interface RnEmptyStateProps extends HTMLAttributes<HTMLDivElement> {
    title: string;
    description?: ReactNode;
    illustration?: ReactNode;
    action?: ReactNode;
}
export declare const RnEmptyState: import("react").ForwardRefExoticComponent<RnEmptyStateProps & import("react").RefAttributes<HTMLDivElement>>;
export interface RnSkeletonProps extends HTMLAttributes<HTMLDivElement> {
    label?: string;
}
export declare const RnSkeleton: import("react").ForwardRefExoticComponent<RnSkeletonProps & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=RnFeedback.d.ts.map