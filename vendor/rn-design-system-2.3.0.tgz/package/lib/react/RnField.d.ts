import { type InputHTMLAttributes, type ReactNode } from "react";
export interface RnFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "size"> {
    label: string;
    description?: ReactNode;
    error?: ReactNode;
}
export declare const RnField: import("react").ForwardRefExoticComponent<RnFieldProps & import("react").RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=RnField.d.ts.map