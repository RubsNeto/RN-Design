import { type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
export interface RnSharedFieldProps {
    label: string;
    description?: string;
    error?: string;
}
export interface RnSelectProps extends SelectHTMLAttributes<HTMLSelectElement>, RnSharedFieldProps {
}
export declare const RnSelect: import("react").ForwardRefExoticComponent<RnSelectProps & import("react").RefAttributes<HTMLSelectElement>>;
export interface RnTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement>, RnSharedFieldProps {
}
export declare const RnTextarea: import("react").ForwardRefExoticComponent<RnTextareaProps & import("react").RefAttributes<HTMLTextAreaElement>>;
export interface RnCheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
    label: string;
}
export declare const RnCheckbox: import("react").ForwardRefExoticComponent<RnCheckboxProps & import("react").RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=RnFormControls.d.ts.map