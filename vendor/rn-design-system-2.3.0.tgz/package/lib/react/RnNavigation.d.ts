import { type ReactNode } from "react";
export interface RnSegmentedItem {
    id: string;
    label: ReactNode;
    disabled?: boolean;
}
export interface RnSegmentedProps {
    label: string;
    items: readonly RnSegmentedItem[];
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    className?: string;
}
export declare function RnSegmented({ label, items, value, defaultValue, onValueChange, className }: RnSegmentedProps): import("react").JSX.Element;
export type RnStepState = "upcoming" | "current" | "complete" | "error" | "disabled";
export interface RnStepItem {
    id: string;
    label: ReactNode;
    state?: RnStepState;
}
export interface RnStepperProps {
    label: string;
    steps: readonly RnStepItem[];
    currentStep?: string;
    className?: string;
}
export declare function RnStepper({ label, steps, currentStep, className }: RnStepperProps): import("react").JSX.Element;
export interface RnBreadcrumbItem {
    label: string;
    href?: string;
}
export interface RnBreadcrumbProps {
    label?: string;
    items: readonly RnBreadcrumbItem[];
    className?: string;
}
export declare function RnBreadcrumb({ label, items, className }: RnBreadcrumbProps): import("react").JSX.Element;
export interface RnPaginationProps {
    page: number;
    pageCount: number;
    onPageChange: (page: number) => void;
    label?: string;
    siblingCount?: number;
    className?: string;
}
export declare function RnPagination({ page, pageCount, onPageChange, label, siblingCount, className, }: RnPaginationProps): import("react").JSX.Element | null;
//# sourceMappingURL=RnNavigation.d.ts.map