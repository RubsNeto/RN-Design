import { type ButtonHTMLAttributes, type DialogHTMLAttributes, type HTMLAttributes, type ReactNode } from "react";
export interface RnDrawerProps extends Omit<DialogHTMLAttributes<HTMLDialogElement>, "open" | "title"> {
    open: boolean;
    title: ReactNode;
    description?: string;
    footer?: ReactNode;
    closeLabel?: string;
    onRequestClose: () => void;
}
export declare const RnDrawer: import("react").ForwardRefExoticComponent<RnDrawerProps & import("react").RefAttributes<HTMLDialogElement>>;
export interface RnPopoverProps extends Omit<HTMLAttributes<HTMLDivElement>, "id"> {
    id: string;
}
export declare const RnPopover: import("react").ForwardRefExoticComponent<RnPopoverProps & import("react").RefAttributes<HTMLDivElement>>;
export interface RnPopoverTriggerProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    popoverId: string;
}
export declare const RnPopoverTrigger: import("react").ForwardRefExoticComponent<RnPopoverTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=RnOverlays.d.ts.map