import { type HTMLAttributes, type ReactNode } from "react";
import { type RnAnimatedWordmarkProps } from "../components/RnAnimatedWordmark";
export interface RnStoryHeroProps extends Omit<HTMLAttributes<HTMLElement>, "title"> {
    title: ReactNode;
    support: ReactNode;
    capabilities?: readonly string[];
    action?: ReactNode;
    wordmarkTiming?: RnAnimatedWordmarkProps["timing"];
}
export declare const RnStoryHero: import("react").ForwardRefExoticComponent<RnStoryHeroProps & import("react").RefAttributes<HTMLElement>>;
//# sourceMappingURL=RnStoryHero.d.ts.map