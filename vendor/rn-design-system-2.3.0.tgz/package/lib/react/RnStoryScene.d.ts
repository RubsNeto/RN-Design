import { type HTMLAttributes } from "react";
export type RnStorySceneTone = "light" | "dark" | "stage" | "deep";
export interface RnStorySceneProps extends HTMLAttributes<HTMLElement> {
    tone?: RnStorySceneTone;
    contained?: boolean;
}
export declare const RnStoryScene: import("react").ForwardRefExoticComponent<RnStorySceneProps & import("react").RefAttributes<HTMLElement>>;
//# sourceMappingURL=RnStoryScene.d.ts.map