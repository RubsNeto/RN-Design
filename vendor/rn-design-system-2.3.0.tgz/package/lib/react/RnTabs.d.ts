import { type ReactNode } from "react";
export interface RnTabItem {
    id: string;
    label: string;
    content: ReactNode;
    disabled?: boolean;
}
export interface RnTabsProps {
    label: string;
    items: readonly RnTabItem[];
    defaultTab?: string;
    onTabChange?: (id: string) => void;
}
export declare function RnTabs({ label, items, defaultTab, onTabChange }: RnTabsProps): import("react").JSX.Element | null;
//# sourceMappingURL=RnTabs.d.ts.map