import { lazy, Suspense } from "react";
import { RnBrandLoader } from "./components/RnBrandLoader";

const SystemDesignPage = lazy(async () => {
  const module = await import("./pages/SystemDesignPage");
  return { default: module.SystemDesignPage };
});

const ProposalPage = lazy(async () => {
  const module = await import("./pages/ProposalPage");
  return { default: module.ProposalPage };
});

const MotionLabPage = lazy(async () => {
  const module = await import("./pages/MotionLabPage");
  return { default: module.MotionLabPage };
});

const LoaderLabPage = lazy(async () => {
  const module = await import("./pages/LoaderLabPage");
  return { default: module.LoaderLabPage };
});

const QualityLabPage = lazy(async () => {
  const module = await import("./pages/QualityLabPage");
  return { default: module.QualityLabPage };
});

const MotionExportPage = lazy(async () => {
  const module = await import("./pages/MotionExportPage");
  return { default: module.MotionExportPage };
});

export default function App() {
  const isBudgetReference = window.location.pathname === "/orcamento"
    || window.location.pathname.startsWith("/orcamento/");
  const isMotionLab = window.location.pathname === "/animacoes"
    || window.location.pathname.startsWith("/animacoes/");
  const isLoaderLab = window.location.pathname === "/carregamento"
    || window.location.pathname.startsWith("/carregamento/");
  const isQualityLab = window.location.pathname === "/quality"
    || window.location.pathname.startsWith("/quality/");
  const isMotionExport = window.location.pathname === "/motion-export"
    || window.location.pathname.startsWith("/motion-export/");

  return (
    <Suspense fallback={<div className="rn-route-loader"><RnBrandLoader label="Carregando RN Design" size="xl" /></div>}>
      {isBudgetReference ? <ProposalPage /> : isMotionExport ? <MotionExportPage /> : isMotionLab ? <MotionLabPage /> : isLoaderLab ? <LoaderLabPage /> : isQualityLab ? <QualityLabPage /> : <SystemDesignPage />}
    </Suspense>
  );
}
