import { useMemo, useState } from "react";
import artDirection from "../../agent/art-direction.json";
import canonicalPrompt from "../../agent/prompts/create-brand-art.md?raw";
import { RnAnimatedWordmark } from "./RnAnimatedWordmark";
import { SystemIcon } from "./SystemIcon";
import "../styles/art-direction.css";

type ArtMode = "expressive" | "product";
type PromptView = "complete" | "negative" | "json";

function greatestCommonDivisor(a: number, b: number): number {
  return b === 0 ? a : greatestCommonDivisor(b, a % b);
}

function downloadText(filename: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

export function ArtDirectionPanel() {
  const [presetId, setPresetId] = useState("portrait");
  const [mode, setMode] = useState<ArtMode>("expressive");
  const [objective, setObjective] = useState("Apresentar uma solução digital da RN Design");
  const [message, setMessage] = useState("Onde ideias se transformam em inovação");
  const [cta, setCta] = useState("Conhecer a solução");
  const [audience, setAudience] = useState("Empresas que precisam transformar operação em produto digital");
  const [subject, setSubject] = useState("Tecnologia sob medida com presença humana e precisão editorial");
  const [medium, setMedium] = useState("Composição editorial digital");
  const [requiredContent, setRequiredContent] = useState("Mensagem principal, CTA e assinatura oficial RN Design");
  const [rights, setRights] = useState("Assets oficiais RN e conteúdo próprio ou autorizado");
  const [view, setView] = useState<PromptView>("complete");
  const [copied, setCopied] = useState(false);

  const preset = artDirection.presets.find((item) => item.id === presetId) ?? artDirection.presets[0];
  const divisor = greatestCommonDivisor(preset.width, preset.height);
  const aspectRatio = `${preset.width / divisor}:${preset.height / divisor}`;

  const prompt = useMemo(() => canonicalPrompt
    .replaceAll("{{OBJECTIVE}}", objective || "[definir objetivo]")
    .replaceAll("{{DELIVERABLE}}", preset.label)
    .replaceAll("{{WIDTH}}", String(preset.width))
    .replaceAll("{{HEIGHT}}", String(preset.height))
    .replaceAll("{{ASPECT_RATIO}}", aspectRatio)
    .replaceAll("{{AUDIENCE}}", audience || "[definir público]")
    .replaceAll("{{MESSAGE}}", message || "[definir mensagem]")
    .replaceAll("{{SUBJECT}}", subject || "[definir assunto visual]")
    .replaceAll("{{MODE}}", mode === "expressive" ? "Expressive" : "Product/quiet")
    .replaceAll("{{CTA}}", cta || "[definir CTA]")
    .replaceAll("{{MEDIUM}}", medium)
    .replaceAll("{{REQUIRED_ASSETS}}", "rn-logo.png e/ou rn-icon.svg oficiais; rn-glow.svg e rn-pixels.svg apenas quando servirem à composição")
    .replaceAll("{{REQUIRED_CONTENT}}", requiredContent || "[listar conteúdo obrigatório]")
    .replaceAll("{{CONSTRAINTS}}", `safe area de ${preset.safeAreaPercent}% e um único ponto focal`)
    .replaceAll("{{RIGHTS_AND_SOURCES}}", rights || "[informar fontes e autorizações]"),
  [aspectRatio, audience, cta, medium, message, mode, objective, preset, requiredContent, rights, subject]);

  const negativePrompt = useMemo(() => {
    const marker = "## Negative prompt obrigatório";
    const nextMarker = "## Processo e resposta";
    return prompt.split(marker)[1]?.split(nextMarker)[0]?.trim() ?? "";
  }, [prompt]);

  const briefJson = useMemo(() => JSON.stringify({
    designSystem: "RN Design System",
    version: artDirection.version,
    mode,
    objective,
    deliverable: preset.label,
    dimensions: { width: preset.width, height: preset.height, aspectRatio, safeAreaPercent: preset.safeAreaPercent },
    audience,
    message,
    cta,
    subject,
    medium,
    requiredContent,
    rightsAndSources: rights,
    officialAssets: artDirection.officialAssets.map(({ id, path }) => ({ id, path })),
    generation: artDirection.generation,
    requiredOutputs: artDirection.outputs,
  }, null, 2), [aspectRatio, audience, cta, medium, message, mode, objective, preset, requiredContent, rights, subject]);

  const output = view === "complete" ? prompt : view === "negative" ? negativePrompt : briefJson;
  const outputLabel = view === "complete" ? "Prompt completo" : view === "negative" ? "Negative prompt" : "Brief JSON";

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section className="hub-section hub-art-direction" id="direcao-de-arte" aria-labelledby="art-direction-title">
      <header className="hub-section-heading">
        <div className="hub-section-heading__copy">
          <p className="hub-eyebrow"><span aria-hidden="true">‹ ◉ ›</span>13 — Direção de arte IA</p>
          <h2 id="art-direction-title">A identidade RN convertida em <span>prompt operacional.</span></h2>
          <p>Preencha o brief, copie o prompt e entregue ao agente. Logo, texto e assets oficiais entram depois da geração da imagem-base, sem aproximações.</p>
        </div>
        <div className="hub-section-heading__actions">
          <a className="hub-text-link" href="/agent/art-direction.json">Abrir contrato JSON <SystemIcon name="external" /></a>
        </div>
      </header>

      <div className="hub-art-direction__layout">
        <form className="hub-art-direction__brief" onSubmit={(event) => event.preventDefault()}>
          <header><span>BRIEF DINÂMICO</span><strong>{preset.width} × {preset.height}</strong></header>
          <div className="hub-art-direction__form-grid">
            <label>
              <span>Formato</span>
              <select value={presetId} onChange={(event) => setPresetId(event.target.value)}>
                {artDirection.presets.map((item) => <option value={item.id} key={item.id}>{item.label} · {item.width}×{item.height}</option>)}
              </select>
            </label>
            <fieldset>
              <legend>Intensidade</legend>
              <div role="group" aria-label="Intensidade visual">
                <button type="button" aria-pressed={mode === "expressive"} onClick={() => setMode("expressive")}>Expressive</button>
                <button type="button" aria-pressed={mode === "product"} onClick={() => setMode("product")}>Product / quiet</button>
              </div>
            </fieldset>
            <label className="hub-art-direction__wide">
              <span>Objetivo</span>
              <input value={objective} onChange={(event) => setObjective(event.target.value)} />
            </label>
            <label className="hub-art-direction__wide">
              <span>Mensagem principal</span>
              <input value={message} onChange={(event) => setMessage(event.target.value)} />
            </label>
            <label>
              <span>CTA</span>
              <input value={cta} onChange={(event) => setCta(event.target.value)} />
            </label>
            <label>
              <span>Mídia</span>
              <select value={medium} onChange={(event) => setMedium(event.target.value)}>
                <option>Composição editorial digital</option>
                <option>Fotografia</option>
                <option>Ilustração / 3D</option>
                <option>Produto / screenshot</option>
                <option>Motion / vídeo</option>
              </select>
            </label>
            <label className="hub-art-direction__wide">
              <span>Público</span>
              <input value={audience} onChange={(event) => setAudience(event.target.value)} />
            </label>
            <label className="hub-art-direction__wide">
              <span>Assunto visual</span>
              <textarea rows={3} value={subject} onChange={(event) => setSubject(event.target.value)} />
            </label>
            <label className="hub-art-direction__wide">
              <span>Conteúdo obrigatório</span>
              <textarea rows={2} value={requiredContent} onChange={(event) => setRequiredContent(event.target.value)} />
            </label>
            <label className="hub-art-direction__wide">
              <span>Direitos e fontes</span>
              <textarea rows={2} value={rights} onChange={(event) => setRights(event.target.value)} />
            </label>
          </div>
          <footer>
            <span><SystemIcon name="shield" /> Safe area {preset.safeAreaPercent}%</span>
            <span><SystemIcon name="check" /> Composição humana final</span>
          </footer>
        </form>

        <article className="hub-art-direction__blueprint" data-mode={mode}>
          <header><span>BLUEPRINT / {mode === "expressive" ? "EXPRESSIVE" : "PRODUCT QUIET"}</span><small>Preview estrutural</small></header>
          <div className="hub-art-direction__preview rn-brand-canvas rn-brand-canvas--editorial">
            <span className="hub-art-direction__safe-area" aria-hidden="true" />
            <RnAnimatedWordmark animated={false} size="panel" />
            <div>
              <strong>{message || "Mensagem principal"}</strong>
              <span>Um ponto focal · composição {aspectRatio}</span>
            </div>
          </div>
          <footer className="hub-art-direction__swatches" aria-label="Paleta principal RN">
            {[
              ["sky", "Sky"], ["cyan", "Ciano"], ["blue", "Blue soft"], ["navy", "Navy"], ["ink", "Ink"],
            ].map(([id, label]) => <span key={id}><i data-swatch={id} aria-hidden="true" />{label}</span>)}
          </footer>
        </article>
      </div>

      <article className="hub-art-direction__prompt">
        <header>
          <div><span>PROMPT STUDIO</span><strong>{outputLabel}</strong></div>
          <div className="hub-art-direction__view-control" role="group" aria-label="Conteúdo exibido">
            <button type="button" aria-pressed={view === "complete"} onClick={() => setView("complete")}>Completo</button>
            <button type="button" aria-pressed={view === "negative"} onClick={() => setView("negative")}>Negative</button>
            <button type="button" aria-pressed={view === "json"} onClick={() => setView("json")}>JSON</button>
          </div>
          <div className="hub-art-direction__prompt-actions">
            <button type="button" onClick={copyPrompt}><SystemIcon name={copied ? "check" : "copy"} />{copied ? "Copiado" : "Copiar"}</button>
            <button type="button" onClick={() => downloadText(view === "json" ? "rn-art-brief.json" : "rn-art-prompt.md", output, view === "json" ? "application/json" : "text/markdown")}><SystemIcon name="download" />Baixar</button>
          </div>
        </header>
        <pre tabIndex={0} aria-label={`${outputLabel} gerado`}><code>{output}</code></pre>
        <p role="status" aria-live="polite" aria-atomic="true">{copied ? `${outputLabel} copiado para a área de transferência.` : "O prompt acompanha o brief acima e preserva as regras oficiais."}</p>
      </article>

      <article className="hub-art-direction__kit" aria-labelledby="brand-kit-title">
        <header>
          <div><p className="hub-eyebrow"><span aria-hidden="true">‹ ◉ ›</span>KIT OFICIAL</p><h3 id="brand-kit-title">Assets prontos para baixar.</h3></div>
          <p>Use estes arquivos na composição final. Nunca peça ao gerador para recriá-los.</p>
        </header>
        <div>
          {artDirection.officialAssets.map((asset) => (
            <a href={`/${asset.path}`} download={asset.downloadName} key={asset.id} aria-label={`Baixar ${asset.label} em ${asset.format}`}>
              <SystemIcon name="download" />
              <span><strong>{asset.label}</strong><small>{asset.format} · {asset.dimensions}</small></span>
              <SystemIcon name="arrow" />
            </a>
          ))}
        </div>
        <div className="hub-art-direction__video">
          <video controls muted playsInline preload="metadata" poster="/assets/brand/rn-wordmark-hero-poster.png" aria-label="Prévia da animação oficial RN Design">
            <source src="/assets/brand/rn-wordmark-hero.webm" type="video/webm" />
            Seu navegador não reproduz WebM. Use o botão de download acima.
          </video>
          <p>Abertura oficial em 1920 × 1080, sem áudio e com quadro final estático.</p>
        </div>
      </article>
    </section>
  );
}
