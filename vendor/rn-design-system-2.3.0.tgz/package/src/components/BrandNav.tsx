import { useEffect, useRef } from "react";

export function BrandNav() {
  const progressRef = useRef<HTMLElement>(null);

  useEffect(() => {
    let frame = 0;

    const updateProgress = () => {
      frame = 0;
      const scrollable = Math.max(document.documentElement.scrollHeight - window.innerHeight, 1);
      const progress = Math.min(Math.max(window.scrollY / scrollable, 0), 1);
      progressRef.current?.style.setProperty("--page-progress", String(progress));
    };

    const scheduleUpdate = () => {
      if (!frame) frame = window.requestAnimationFrame(updateProgress);
    };

    updateProgress();
    window.addEventListener("scroll", scheduleUpdate, { passive: true });
    window.addEventListener("resize", scheduleUpdate, { passive: true });

    return () => {
      window.removeEventListener("scroll", scheduleUpdate);
      window.removeEventListener("resize", scheduleUpdate);
      window.cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <header className="brand-nav" data-testid="brand-nav">
      <a
        className="brand-nav__logo"
        href="#hero"
        aria-label="Voltar ao início"
        data-cursor="Início"
        data-magnetic
      >
        <img src="/assets/brand/rn-logo.png" alt="RN Design &amp; Serviços" decoding="async" />
      </a>
      <span ref={progressRef} className="brand-nav__line" aria-hidden="true">
        <i />
      </span>
      <nav aria-label="Navegação principal">
        <a href="#hero" data-cursor="Início">RN DESIGN</a>
        <a href="#portfolio" data-cursor="Soluções">SOLUÇÕES</a>
        <a href="#pricing" data-cursor="Proposta">PROPOSTA</a>
      </nav>
    </header>
  );
}
