import { useMemo, useState, type CSSProperties, type ReactNode } from "react";
import {
  RnAlert,
  RnAnimatedWordmark,
  RnBarChart,
  RnBrandLoader,
  RnButton,
  RnCombobox,
  RnField,
  RnProgress,
} from "../react";
import "../styles/component-playground.css";

type PlaygroundComponent = "button" | "field" | "alert-toast" | "progress" | "combobox" | "animated-wordmark" | "brand-loader" | "data-viz";
type PlaygroundState = "default" | "disabled" | "loading" | "error";
type PlaygroundViewport = "375" | "768" | "1024";

const options: Array<{ id: PlaygroundComponent; label: string; exportName: string }> = [
  { id: "button", label: "Button", exportName: "RnButton" },
  { id: "field", label: "Field", exportName: "RnField" },
  { id: "alert-toast", label: "Alert", exportName: "RnAlert" },
  { id: "progress", label: "Progress", exportName: "RnProgress" },
  { id: "combobox", label: "Combobox", exportName: "RnCombobox" },
  { id: "animated-wordmark", label: "Animated wordmark", exportName: "RnAnimatedWordmark" },
  { id: "brand-loader", label: "Brand loader", exportName: "RnBrandLoader" },
  { id: "data-viz", label: "Bar chart", exportName: "RnBarChart" },
];

const clientOptions = [
  { id: "aurora", label: "Projeto Aurora" },
  { id: "atlas", label: "Proposta Atlas" },
  { id: "portal", label: "Portal RN" },
];

const chartSeries = [{ id: "delivery", label: "Entregas" }];
const chartData = [
  { label: "Jan", values: { delivery: 54 } },
  { label: "Fev", values: { delivery: 72 } },
  { label: "Mar", values: { delivery: 88 } },
];

const snippets: Record<PlaygroundComponent, string> = {
  button: `<RnButton variant="primary">Salvar alterações</RnButton>`,
  field: `<RnField label="Nome do projeto" required />`,
  "alert-toast": `<RnAlert tone="success" title="Projeto atualizado">As mudanças já estão disponíveis.</RnAlert>`,
  progress: `<RnProgress label="Importando projetos" value={68} />`,
  combobox: `<RnCombobox label="Projeto" options={projects} value={projectId} onValueChange={selectProject} />`,
  "animated-wordmark": `<RnAnimatedWordmark size="compact" timing="overlap" />`,
  "brand-loader": `<RnBrandLoader variant="radial" size="md" label="Carregando projetos…" />`,
  "data-viz": `<RnBarChart title="Entregas" series={series} data={data} />`,
};

export function ComponentPlayground() {
  const [selected, setSelected] = useState<PlaygroundComponent>("button");
  const [state, setState] = useState<PlaygroundState>("default");
  const [viewport, setViewport] = useState<PlaygroundViewport>("1024");
  const [replayKey, setReplayKey] = useState(0);
  const [client, setClient] = useState<string | null>("aurora");
  const [copied, setCopied] = useState(false);
  const selectedMeta = options.find((option) => option.id === selected) ?? options[0];

  const code = useMemo(() => {
    const stateProps = state === "disabled" ? " disabled" : state === "loading" && selected === "button" ? " loading" : "";
    const example = stateProps ? snippets[selected].replace(/\s*(\/?>)/, `${stateProps}$1`) : snippets[selected];
    return `import { ${selectedMeta.exportName} } from "@rn-design/system/react";\n\n${example}`;
  }, [selected, selectedMeta.exportName, state]);

  const preview = (() => {
    const disabled = state === "disabled";
    const error = state === "error" ? "Informe um valor válido para continuar." : undefined;
    const loading = state === "loading";
    const components: Record<PlaygroundComponent, ReactNode> = {
      button: <RnButton disabled={disabled} loading={loading}>{loading ? "Salvando" : "Salvar alterações"}</RnButton>,
      field: <RnField label="Nome do projeto" defaultValue="Portal RN" disabled={disabled} error={error} required />,
      "alert-toast": <RnAlert tone={state === "error" ? "danger" : loading ? "warning" : "success"} title={state === "error" ? "Não foi possível salvar" : loading ? "Sincronizando projeto" : "Projeto atualizado"}>{state === "error" ? "Revise a conexão e tente novamente." : loading ? "Aguarde enquanto os dados são processados." : "As mudanças já estão disponíveis."}</RnAlert>,
      progress: <RnProgress label="Importando projetos" value={loading ? undefined : state === "error" ? 42 : 68} />,
      combobox: <RnCombobox label="Projeto" options={clientOptions} value={client} onValueChange={(option) => setClient(option?.id ?? null)} disabled={disabled} error={error} />,
      "animated-wordmark": <RnAnimatedWordmark animated={!disabled} size="compact" timing="overlap" key={`wordmark-${replayKey}`} />,
      "brand-loader": <RnBrandLoader announce={false} paused={disabled} size="md" variant="radial" label={state === "error" ? "Tentando novamente…" : "Carregando projetos…"} key={`loader-${replayKey}`} />,
      "data-viz": <RnBarChart title="Entregas por mês" description="Dados e tabela equivalente." series={chartSeries} data={state === "error" ? [] : chartData} />,
    };
    return components[selected];
  })();

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <article className="hub-playground" aria-labelledby="component-playground-title">
      <header className="hub-playground__header">
        <div>
          <span>PLAYGROUND · EXPORTS REAIS</span>
          <h3 id="component-playground-title">Teste o contrato antes de implementar.</h3>
          <p>O preview, o snippet e o JSON apontam para a mesma API pública.</p>
        </div>
        <a href={`/agent/contracts/components/${selected}.json`}>Abrir contrato JSON</a>
      </header>

      <div className="hub-playground__toolbar">
        <label className="rn-field">
          <span className="rn-field__label">Componente</span>
          <select className="rn-field__control" value={selected} onChange={(event) => { setSelected(event.target.value as PlaygroundComponent); setState("default"); setReplayKey((value) => value + 1); }}>
            {options.map((option) => <option value={option.id} key={option.id}>{option.label} · {option.exportName}</option>)}
          </select>
        </label>

        <fieldset>
          <legend>Estado</legend>
          <div className="rn-segmented">
            {(["default", "disabled", "loading", "error"] as PlaygroundState[]).map((value) => (
              <button className="rn-segmented__item" type="button" aria-pressed={state === value} onClick={() => setState(value)} key={value}>{value}</button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend>Viewport</legend>
          <div className="rn-segmented">
            {(["375", "768", "1024"] as PlaygroundViewport[]).map((value) => (
              <button className="rn-segmented__item" type="button" aria-pressed={viewport === value} onClick={() => setViewport(value)} key={value}>{value}</button>
            ))}
          </div>
        </fieldset>

        <button className="hub-playground__replay" type="button" onClick={() => setReplayKey((value) => value + 1)}>Reproduzir motion</button>
      </div>

      <div className="hub-playground__workspace">
        <div className="hub-playground__canvas" data-component={selected}>
          <div
            className="hub-playground__viewport"
            style={{ "--hub-playground-width": `${viewport}px` } as CSSProperties}
          >
            <span className="hub-playground__viewport-label">{viewport}px · Product / light</span>
            <div className="hub-playground__preview" key={`${selected}-${replayKey}`}>{preview}</div>
          </div>
        </div>

        <div className="hub-playground__code">
          <header><span>TSX</span><button type="button" onClick={copyCode}>{copied ? "Copiado" : "Copiar"}</button></header>
          <pre><code>{code}</code></pre>
          <p aria-live="polite">{copied ? "Snippet copiado para a área de transferência." : "Import público e props sincronizados com o preview."}</p>
        </div>
      </div>
    </article>
  );
}
