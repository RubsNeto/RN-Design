import type { CSSProperties, HTMLAttributes } from "react";
import { RnBrandMark } from "./RnBrandMark";

export interface RnAnimatedWordmarkProps extends HTMLAttributes<HTMLDivElement> {
  animated?: boolean;
  size?: RnAnimatedWordmarkSize;
  timing?: "sequential" | "overlap";
}

export type RnAnimatedWordmarkSize = "hero" | "showcase" | "panel" | "compact";

export function RnAnimatedWordmark({ animated = true, className, size = "hero", timing = "sequential", ...props }: RnAnimatedWordmarkProps) {
  const classes = ["rn-story-wordmark", className]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={classes} data-animated={animated ? "true" : "false"} data-size={size} data-timing={timing} role="img" aria-label="RN Design" {...props}>
      <strong className="rn-story-wordmark__letters" aria-hidden="true" data-text="RN DESIGN">
        {"RN DESIGN".split("").map((letter, index) => {
          const letterIndex = "RN DESIGN".slice(0, index).replaceAll(" ", "").length;

          return (
            <span
              className={letter === " " ? "rn-story-wordmark__letter rn-story-wordmark__letter--space" : "rn-story-wordmark__letter"}
              key={`${letter}-${index}`}
              style={{ "--rn-letter-index": letterIndex } as CSSProperties}
            >
              {letter === " " ? "\u00a0" : letter}
            </span>
          );
        })}
      </strong>

      <span className="rn-story-wordmark__symbol" aria-hidden="true">
        <span className="rn-story-wordmark__symbol-aura" />
        <span className="rn-story-wordmark__symbol-ring" />
        <RnBrandMark
          className="rn-story-wordmark__symbol-mark"
          pieceClassName="rn-story-wordmark__symbol-piece"
          size="fluid"
        />
      </span>
    </div>
  );
}
