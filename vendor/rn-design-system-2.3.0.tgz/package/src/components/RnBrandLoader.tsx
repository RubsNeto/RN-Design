import type { HTMLAttributes } from "react";
import { RnBrandMark } from "./RnBrandMark";

export const RN_BRAND_LOADER_VARIANTS = [
  "radial",
  "pulse",
  "orbit",
  "wave",
  "focus",
  "scan",
  "breathe",
  "magnetic",
  "cascade",
  "eclipse",
] as const;

export type RnBrandLoaderVariant = typeof RN_BRAND_LOADER_VARIANTS[number];

export interface RnBrandLoaderProps extends HTMLAttributes<HTMLDivElement> {
  announce?: boolean;
  iconSrc?: string;
  label?: string;
  paused?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  variant?: RnBrandLoaderVariant;
}

export function RnBrandLoader({
  announce = true,
  className,
  iconSrc,
  label = "Carregando experiência RN…",
  paused = false,
  size = "md",
  variant = "radial",
  ...props
}: RnBrandLoaderProps) {
  const classes = ["rn-brand-loader", `rn-brand-loader--${size}`, className].filter(Boolean).join(" ");

  return (
    <div
      className={classes}
      data-paused={paused ? "true" : "false"}
      data-variant={variant}
      role={announce ? "status" : undefined}
      aria-atomic={announce ? "true" : undefined}
      aria-hidden={announce ? undefined : "true"}
      aria-live={announce ? "polite" : undefined}
      {...props}
    >
      <span className="rn-brand-loader__visual" aria-hidden="true">
        <span className="rn-brand-loader__aura" />
        <span className="rn-brand-loader__rings"><i /><i /></span>

        {iconSrc ? (
          <img className="rn-brand-loader__fallback-image" src={iconSrc} alt="" width="384" height="384" />
        ) : (
          <RnBrandMark className="rn-brand-loader__mark" pieceClassName="rn-brand-loader__piece" size="fluid" />
        )}

        <span className="rn-brand-loader__scan" />
      </span>

      {label ? (
        <span className="rn-brand-loader__label">
          {label}
          <span className="rn-brand-loader__dots" aria-hidden="true"><i /><i /><i /></span>
        </span>
      ) : null}
    </div>
  );
}
