import { useId, type CSSProperties, type SVGAttributes } from "react";

interface MarkPiece {
  d: string;
  name: string;
  rotation: string;
  sequence: number;
  x: string;
  y: string;
}

export const RN_MARK_PIECES: MarkPiece[] = [
  {
    name: "center",
    x: "0px",
    y: "0px",
    rotation: "0deg",
    sequence: 8,
    d: "M217.962 124.606 216.311 125.431 194.311 147.431 189.896 149.639 165.839 125.581 162.514 126.413 161.511 162.511 125.525 163.511 125.525 166.803 132.384 174.641 143.385 185.643 149.715 193.027 125.525 217.217 125.525 220.503 162.511 222.502 163.511 258.475 166.783 258.475 189.732 235.526 194.161 234.419 202.384 242.641 209.384 250.641 216.259 257.516 220.492 258.363 221.489 221.489 257.587 220.486 258.419 217.161 235.526 194.268 234.419 189.839 257.526 166.732 258.389 163.281 256.869 162.522 220.475 161.511 220.475 126.281Z",
  },
  {
    name: "top",
    x: "4px",
    y: "-76px",
    rotation: "-10deg",
    sequence: 0,
    d: "M207.18 0.562 173.474 34.268 172.581 37.839 178.384 43.641 185.384 51.641 217.161 83.419 220.48 82.589 221.471 4.279 218.803 2.499Z",
  },
  {
    name: "top-right",
    x: "64px",
    y: "-54px",
    rotation: "12deg",
    sequence: 1,
    d: "M288.217 67.525 287.519 68.223 286.525 106.007 286.525 133.783 288.142 135.399 290.716 134.541 343.569 81.689 345.388 78.051 337.733 67.525Z",
  },
  {
    name: "right",
    x: "78px",
    y: "4px",
    rotation: "9deg",
    sequence: 2,
    d: "M346.131 172.574 340.354 177.388 300.525 217.217 300.525 220.488 340.007 221.475 379.645 221.475 381.485 216.874 382.453 207.195 376.616 201.359 369.616 193.359 349.732 173.474Z",
  },
  {
    name: "bottom-right",
    x: "58px",
    y: "58px",
    rotation: "-12deg",
    sequence: 3,
    d: "M248.525 287.525 248.525 289.783 268.384 309.641 275.384 317.641 302.268 344.526 305.895 345.433 315.48 338.723 316.473 289.119 315.676 287.525Z",
  },
  {
    name: "bottom",
    x: "-4px",
    y: "78px",
    rotation: "10deg",
    sequence: 4,
    d: "M164.081 299.661 162.525 301.217 162.525 379.719 165.179 381.488 176.801 382.457 194.635 364.622 209.556 350.696 211.384 346.126 180.621 315.364 168.665 302.411Z",
  },
  {
    name: "bottom-left",
    x: "-58px",
    y: "58px",
    rotation: "-9deg",
    sequence: 5,
    d: "M94.142 248.601 87.359 255.384 79.359 262.384 39.484 302.259 38.557 306.89 44.29 315.488 65.012 316.475 94.783 316.475 96.475 314.783 96.475 249.378Z",
  },
  {
    name: "left",
    x: "-78px",
    y: "-4px",
    rotation: "12deg",
    sequence: 6,
    d: "M3.396 162.525 1.516 169.105 0.553 176.81 34.268 210.526 37.839 211.419 82.526 166.732 83.335 163.497 60.989 162.525Z",
  },
  {
    name: "top-left",
    x: "-58px",
    y: "-56px",
    rotation: "-12deg",
    sequence: 7,
    d: "M77.105 38.567 67.525 45.273 67.525 95.783 68.217 96.475 134.475 96.475 134.475 93.217 80.732 39.474Z",
  },
];

type PieceStyle = CSSProperties & {
  "--rn-piece-index": number;
  "--rn-piece-rotation": string;
  "--rn-piece-x": string;
  "--rn-piece-y": string;
};

export interface RnBrandMarkProps extends Omit<SVGAttributes<SVGSVGElement>, "children"> {
  pieceClassName?: string;
  size?: "sm" | "md" | "lg" | "xl" | "fluid";
}

export function RnBrandMark({ className, pieceClassName, size = "md", ...props }: RnBrandMarkProps) {
  const gradientId = useId().replaceAll(":", "");
  const classes = ["rn-brand-mark", className].filter(Boolean).join(" ");

  return (
    <svg
      className={classes}
      data-size={size}
      viewBox="0 0 384 384"
      fill="none"
      focusable="false"
      shapeRendering="geometricPrecision"
      {...props}
    >
      <defs>
        <linearGradient id={`${gradientId}-fill`} x1="0" y1="0" x2="428.5" y2="325.4" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--rn-icon-fill-start)" />
          <stop offset="1" stopColor="var(--rn-icon-fill-end)" />
        </linearGradient>
        <linearGradient id={`${gradientId}-edge`} x1="0" y1="0" x2="428.5" y2="325.4" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--rn-icon-edge-start)" />
          <stop offset="1" stopColor="var(--rn-icon-edge-end)" />
        </linearGradient>
      </defs>
      <g
        fill={`url(#${gradientId}-fill)`}
        stroke={`url(#${gradientId}-edge)`}
        strokeWidth="0.375"
        strokeLinejoin="round"
      >
        {RN_MARK_PIECES.map((piece) => (
          <path
            className={pieceClassName}
            data-piece={piece.name}
            d={piece.d}
            key={piece.name}
            style={{
              "--rn-piece-index": piece.sequence,
              "--rn-piece-rotation": piece.rotation,
              "--rn-piece-x": piece.x,
              "--rn-piece-y": piece.y,
            } as PieceStyle}
          />
        ))}
      </g>
    </svg>
  );
}
