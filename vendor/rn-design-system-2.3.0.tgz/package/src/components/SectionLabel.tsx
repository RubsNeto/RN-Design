import { Typewriter } from "./Typewriter";

type SectionLabelProps = {
  children: React.ReactNode;
  tone?: "light" | "dark";
};

export function SectionLabel({ children, tone = "light" }: SectionLabelProps) {
  return (
    <div className={`section-label section-label--${tone}`}>
      <span className="section-label__glyph" aria-hidden="true">
        ‹ ◉ ›
      </span>
      <span>
        {typeof children === "string" ? <Typewriter text={children} /> : children}
      </span>
    </div>
  );
}
