import type { SVGProps } from "react";

const paths = {
  agent: "M12 3v4m0 10v4M3 12h4m10 0h4M5.64 5.64l2.83 2.83m7.06 7.06 2.83 2.83m0-12.72-2.83 2.83m-7.06 7.06-2.83 2.83M9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0Z",
  arrow: "M5 12h14m-5-5 5 5-5 5",
  brand: "M12 2v7m0 6v7M2 12h7m6 0h7M4.93 4.93l4.95 4.95m4.24 4.24 4.95 4.95m0-14.14-4.95 4.95m-4.24 4.24-4.95 4.95",
  check: "m5 12 4 4L19 6",
  code: "m8 9-3 3 3 3m8-6 3 3-3 3m-2-9-4 12",
  copy: "M9 9h10v10H9zM5 15H4V5h10v1",
  docs: "M6 3h9l3 3v15H6zM15 3v4h4M9 11h6M9 15h6",
  download: "M12 3v12m-5-5 5 5 5-5M5 21h14",
  external: "M14 5h5v5m0-5-8 8M19 13v6H5V5h6",
  grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
  layers: "m12 3 9 5-9 5-9-5 9-5Zm-9 9 9 5 9-5M3 16l9 5 9-5",
  loader: "M12 3v3m0 12v3M3 12h3m12 0h3M5.64 5.64l2.12 2.12m8.48 8.48 2.12 2.12m0-12.72-2.12 2.12m-8.48 8.48-2.12 2.12",
  menu: "M4 7h16M4 12h16M4 17h16",
  monitor: "M3 4h18v12H3zM8 20h8m-4-4v4",
  motion: "M4 12h3l2-5 4 10 2-5h5",
  palette: "M12 3a9 9 0 1 0 0 18h1.5a2 2 0 0 0 0-4H12a2 2 0 0 1 0-4 0 7 7 0 0 1 4-14ZM7.5 9h.01M10 6.5h.01M15 7h.01M17 10.5h.01",
  pause: "M8 5v14m8-14v14",
  phone: "M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm3 17h2",
  play: "m9 6 9 6-9 6Z",
  replay: "M4 8V4m0 0h4M4 4l3 3a8 8 0 1 1-2 9",
  search: "m20 20-4.4-4.4m2.4-5.1a7.5 7.5 0 1 1-15 0 7.5 7.5 0 0 1 15 0Z",
  shield: "M12 3 5 6v5c0 5 3 8 7 10 4-2 7-5 7-10V6l-7-3Zm-3 9 2 2 4-4",
  spark: "m12 2 1.4 5.6L19 9l-5.6 1.4L12 16l-1.4-5.6L5 9l5.6-1.4L12 2Zm7 13 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z",
  tablet: "M5 3h14v18H5zM10 18h4",
  type: "M4 5h16M8 5v14m8-14v14M6 19h4m4 0h4",
  x: "M6 6l12 12M18 6 6 18",
} as const;

export type SystemIconName = keyof typeof paths;

export function SystemIcon({ className, name, ...props }: SVGProps<SVGSVGElement> & { name: SystemIconName }) {
  const classes = ["rn-system-icon", className].filter(Boolean).join(" ");

  return (
    <svg
      aria-hidden="true"
      className={classes}
      fill="none"
      focusable="false"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.7"
      viewBox="0 0 24 24"
      {...props}
    >
      <path d={paths[name]} />
    </svg>
  );
}
