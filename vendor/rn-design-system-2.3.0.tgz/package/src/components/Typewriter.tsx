import { useEffect, useRef, useState } from "react";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";

type TypewriterProps = {
  text: string;
  /** ms por caractere */
  speed?: number;
  /** atraso (ms) depois de entrar na tela */
  startDelay?: number;
  /** blink = caret continua piscando; vanish = caret some ao terminar */
  caret?: "blink" | "vanish";
  className?: string;
};

/**
 * Digita o texto quando o elemento entra na viewport, com caret "|" piscando.
 * Um fantasma invisível reserva a largura final para o layout não pular.
 */
export function Typewriter({
  text,
  speed = 44,
  startDelay = 150,
  caret = "vanish",
  className = "",
}: TypewriterProps) {
  const reducedMotion = useReducedMotionPreference();
  const rootRef = useRef<HTMLSpanElement>(null);
  const [started, setStarted] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const root = rootRef.current;
    if (!root || reducedMotion) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        setStarted(true);
        observer.disconnect();
      },
      { threshold: 0.5, rootMargin: "0px 0px -6% 0px" },
    );
    observer.observe(root);
    return () => observer.disconnect();
  }, [reducedMotion]);

  useEffect(() => {
    if (!started || reducedMotion) return;

    let interval = 0;
    const delay = window.setTimeout(() => {
      interval = window.setInterval(() => {
        setCount((current) => {
          if (current >= text.length) {
            window.clearInterval(interval);
            return current;
          }
          return current + 1;
        });
      }, speed);
    }, startDelay);

    return () => {
      window.clearTimeout(delay);
      window.clearInterval(interval);
    };
  }, [started, reducedMotion, text, speed, startDelay]);

  const done = count >= text.length;
  const showCaret = !reducedMotion && started && (caret === "blink" || !done);

  return (
    <span ref={rootRef} className={`typewriter ${className}`.trim()}>
      <span className="typewriter__ghost" aria-hidden="true">
        {text}
      </span>
      <span className="typewriter__live" aria-label={text}>
        {reducedMotion ? text : text.slice(0, count)}
        {showCaret && <i className="typing-caret" aria-hidden="true" />}
      </span>
    </span>
  );
}
