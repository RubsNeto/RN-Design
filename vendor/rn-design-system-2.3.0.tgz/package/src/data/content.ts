// ====================================================================
//  RN DESIGN & SERVIÇOS — CONFIGURAÇÃO DA PROPOSTA
//
//  Este arquivo concentra TUDO que muda de uma proposta para outra.
//  Para criar uma nova proposta, edite apenas os blocos abaixo:
//    1. cliente        → nome e serviço solicitado
//    2. investimento   → valores e formas de pagamento
//    3. (opcional) textos do hero, objetivo, processo, portfólio e FAQ
// ====================================================================

// --------------------------------------------------------------
// 1. CLIENTE — troque a cada proposta
// --------------------------------------------------------------
export const client = {
  // Nome exibido no envelope (animação de digitação) e no selo do hero
  name: "Empresa Exemplo",
  // Índice/carimbo exibido no canto do cartão
  proposalTag: "PROPOSTA / 01",
};

// --------------------------------------------------------------
// 2. INVESTIMENTO — troque a cada proposta
// --------------------------------------------------------------
export const pricing = {
  // O que o cliente pediu (aparece acima do ticket)
  requestedService: "Sistema de gestão sob medida",
  requestedDetail: "Mapeamento + desenvolvimento + implantação assistida",

  // Valor cheio do projeto
  projectValue: 25000,

  // Validade da proposta (aparece como selo abaixo do ticket)
  validUntil: "23/08/2026",

  // Formas de pagamento exibidas no ticket
  paymentOptions: {
    integralDiscountLabel: "5% OFF",
    integralValue: 23750, // à vista
    splitFirst: 12500, // 50% na assinatura
    splitSecond: 12500, // 50% na entrega
    cardInstallments: "12x de", // parcelamento no cartão
    cardValue: 2290,
  },
};

// --------------------------------------------------------------
// 3. CONTATO E EMPRESA — raramente muda
// --------------------------------------------------------------
export const company = {
  name: "RN Design & Serviços",
  shortName: "RN Design",
  site: "rndesign.dev",
  siteUrl: "https://www.rndesign.dev",
  email: "rubensneto.016@gmail.com",
  whatsapp: "5562999299020",
  whatsappMessage: "Olá! Quero fechar o projeto. Quais os próximos passos?",
  cnpj: "48.483.977/0001-33",
  city: "Goiânia · GO",
  instagram: "https://www.instagram.com/rubs_neto/",
  linkedin: "https://www.linkedin.com/in/dev-rubens/",
  // Tagline da transição de entrada da proposta (igual à do site)
  tagline: "DESIGN • DESENVOLVIMENTO • IA",
};

export const whatsappLink = `https://wa.me/${company.whatsapp}?text=${encodeURIComponent(company.whatsappMessage)}`;

// --------------------------------------------------------------
// 4. CARTÃO/ENVELOPE — faixas de letreiro do fundo
// --------------------------------------------------------------
export const marquees = {
  cyan: "Experiências digitais excepcionais",
  black: "Sua proposta está pronta",
};

// --------------------------------------------------------------
// 5. HERO — título e apoio
// --------------------------------------------------------------
export const hero = {
  // "Proposta de <destaque>orçamento</destaque> {serviceLine}"
  serviceLine: "para o seu sistema sob medida",
  description:
    "Interfaces, performance e inteligência artificial aplicadas ao seu produto: da regra de negócio à implantação, com automações, integrações e gestão em um só lugar.",
  // Selos de capacidade exibidos no lugar dos avatares
  capabilities: ["Sistemas & ERP", "UI/UX Design", "Automações & IA", "Desenvolvimento Web"],
  credential: "MBA Eng. de Software (USP) · Mestrando em IA (HGU) · CC (UFJ)",
};

// --------------------------------------------------------------
// 6. OBJETIVO — texto de apresentação da RN
// --------------------------------------------------------------
export const objective = {
  paragraphs: [
    {
      before: "Na RN Design, criamos experiências digitais que inspiram. Design e engenharia pensados juntos — do primeiro rascunho ao deploy — para construir sistemas que ",
      strong: "centralizam dados, automatizam processos e sustentam decisões",
      after: ".",
    },
    {
      before: "Obsessão por detalhe: microinterações, performance e acessibilidade fazem parte do projeto, não são um extra. Tudo nasce do mapeamento da sua operação, para que o sistema ",
      strong: "trabalhe do jeito que a sua empresa funciona",
      after: " — e não o contrário.",
    },
    {
      before: "Tecnologia com propósito: IA e automação aplicadas ",
      strong: "onde geram valor real",
      after: ", nunca como enfeite — com quem vai acompanhar o sistema também depois da entrega.",
    },
  ],
};

// --------------------------------------------------------------
// 6b. TELAS DOS PROJETOS — seção própria com o letreiro de páginas
// --------------------------------------------------------------
export const screens = {
  label: "Projetos RN Design",
  // "Telas de <destaque>projetos</destaque> que saíram do papel"
  titleBefore: "Telas de ",
  titleStrong: "projetos",
  titleAfter: " que saíram do papel",
  ctaLabel: "Veja todos os projetos em",
};

// --------------------------------------------------------------
// 7. FUNDADOR
// --------------------------------------------------------------
export const founder = {
  name: "Rubens Neto",
  role: "Fundador e responsável técnico da RN Design",
  label: "A mente por trás da RN Design",
  paragraphs: [
    {
      before: "Prazer, sou o Rubens — engenheiro de software e fundador da RN Design. ",
      strong: "Sou o responsável técnico pelo seu projeto, do início ao fim.",
      after: "",
    },
    {
      before: "Minha formação une MBA em Engenharia de Software pela USP, Ciência da Computação pela UFJ e mestrado em Inteligência Artificial (HGU) — base que aplico em ",
      strong: "sistemas que sustentam operações reais",
      after: ": ERP, e-commerce, integrações e automações com IA.",
    },
    {
      before: "Da demanda simples à mais complexa, o objetivo aqui é um só: ",
      strong: "te entregar resultado",
      after: " por meio de tecnologia sob medida, construída perto da sua operação.",
    },
  ],
};

// --------------------------------------------------------------
// 8. PROCESSO — etapas do desenvolvimento
// --------------------------------------------------------------
export const processSteps = [
  {
    title: "Descoberta",
    description:
      "Entendimento profundo do negócio, dos objetivos e das necessidades. Mapeamos a operação, as regras e as prioridades — é aqui que o rumo do projeto é definido junto com você.",
  },
  {
    title: "Estratégia",
    description:
      "Definição de personas, jornadas do usuário e arquitetura da solução. Cada fluxo é desenhado para o jeito que a sua empresa realmente trabalha.",
  },
  {
    title: "Design",
    description:
      "Wireframes de alta fidelidade e protótipos interativos. Você navega pelas telas e valida o caminho antes de qualquer linha de código definitiva.",
  },
  {
    title: "Desenvolvimento",
    description:
      "Código limpo, performático e otimizado, construído em entregas curtas com demonstrações ao longo do caminho — sem surpresas no final.",
  },
  {
    title: "Lançamento",
    description:
      "Deploy seguro em ambiente de produção, testes com cenários reais, treinamento da equipe e virada acompanhada de perto.",
  },
  {
    title: "Evolução",
    description:
      "Monitoramento constante de métricas e melhorias orientadas por dados. O sistema cresce junto com a sua operação — novos módulos, integrações e IA.",
  },
];

// --------------------------------------------------------------
// 9. PORTFÓLIO — soluções apresentadas
// --------------------------------------------------------------
// Projetos reais (capturas coletadas de rndesign.dev)
export const portfolioProjects = [
  {
    title: "Pandia",
    image: "/assets/images/projects/pandia.webp",
    type: "Gestão para padarias",
    year: "2026",
  },
  {
    title: "Subsolo",
    image: "/assets/images/projects/subsolo.webp",
    type: "Estoque & Vendas",
    year: "2026",
  },
  {
    title: "Amanda Castro Estética",
    image: "/assets/images/projects/amanda-castro.webp",
    type: "Agenda & Gestão clínica",
    year: "2026",
  },
  {
    title: "Palmiex",
    image: "/assets/images/projects/palmiex.webp",
    type: "Controle de produção",
    year: "2026",
  },
];

// --------------------------------------------------------------
// 10. FAQ
// --------------------------------------------------------------
export const faqs = [
  {
    question: "A hospedagem e a infraestrutura estão incluídas?",
    answer:
      "O projeto já nasce publicado em infraestrutura adequada, com backups e monitoramento configurados. A contratação do servidor e do domínio fica em nome da sua empresa — eu te oriento em cada passo e deixo tudo funcionando.",
  },
  {
    question: "Posso pedir alterações durante o projeto?",
    answer:
      "Sim! O desenvolvimento por fases existe justamente para isso: você valida cada entrega e os ajustes acontecem ao longo do caminho. Mudanças que ampliam o escopo são avaliadas e orçadas antes de qualquer surpresa.",
  },
  {
    question: "E se eu quiser evoluir o sistema depois?",
    answer:
      "O sistema é construído para crescer: novos módulos, integrações, automações com IA e relatórios podem ser adicionados em novas fases. Avaliamos o escopo e seguimos com a mesma forma de trabalho.",
  },
  {
    question: "Como fica a manutenção depois da entrega?",
    answer:
      "Você não fica sozinho: ofereço planos de acompanhamento mensal com correções, atualizações e melhorias priorizadas junto com você. Os detalhes e valores são definidos conforme o tamanho da operação.",
  },
];
