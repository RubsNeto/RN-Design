import registryJson from "../../agent/index.json";

export type SystemMode = "product" | "expressive";
export type SystemStatus = "stable" | "reference" | "experimental" | "planned" | "deprecated";

export interface RegistrySection {
  group: string;
  href: string;
  id: string;
  keywords: string[];
  label: string;
}

export interface RegistryColor {
  id: string;
  name: string;
  role: string;
  token: string;
  value: string;
}

export interface RegistryComponent {
  docs: string;
  family: string;
  id: string;
  modes: SystemMode[];
  motion: string;
  name: string;
  requiredStates: string[];
  source: string;
  status: SystemStatus;
}

export interface RegistryMotion {
  avoid: string;
  durationToken: string;
  easingToken: string;
  id: string;
  name: string;
  properties: string[];
  replayPolicy?: string;
  reducedMotion: string;
  sequence?: string[];
  status: SystemStatus;
  tier: "functional" | "structural" | "expressive" | "continuous";
  use: string;
}

export interface RegistryTemplate {
  id: string;
  mode: SystemMode;
  name: string;
  override: string;
  starter: string;
  states: string[];
  status: SystemStatus;
}

interface AgentRegistry {
  artDirection: {
    contract: string;
    docs: string;
    humanSection: string;
    playbook: string;
    prompt: string;
    schema: string;
  };
  authority: Array<{ order: number; path: string; purpose: string }>;
  components: RegistryComponent[];
  deliveryContract: string[];
  foundations: {
    colors: RegistryColor[];
    font: { asset: string; family: string; weights: number[] };
    radius: number[];
    spacing: number[];
    viewports: number[];
  };
  icons: {
    brand: string;
    fallbackFamily: string;
    interfaceFamily: string;
    rules: string[];
    sizes: number[];
  };
  loading: {
    decision: Array<{ condition: string; example: string; pattern: string }>;
    experimentalLab: string;
    official: {
      component: string;
      id: string;
      labelPattern: string;
      name: string;
      number: string;
      sizes: Array<"sm" | "md" | "lg" | "xl">;
    };
  };
  meta: {
    defaultMode: SystemMode;
    humanPanel: string;
    id: string;
    language: string;
    name: string;
    platforms: string[];
    primaryReference: string;
    status: string;
    updatedAt: string;
    version: string;
  };
  modes: Array<{
    id: SystemMode;
    motion: string;
    name: string;
    override: string;
    status: SystemStatus;
    surface: string;
    useFor: string[];
  }>;
  motion: RegistryMotion[];
  playbooks: {
    brief: string;
    art: { path: string; steps: string[] };
    create: { path: string; steps: string[] };
    refactor: { path: string; steps: string[] };
    validate: { path: string; steps: string[] };
  };
  prohibited: string[];
  quality: {
    accessibilityTarget: string;
    commands: string[];
    manualChecks: string[];
    viewports: number[];
  };
  sections: RegistrySection[];
  taskRouter: Array<{
    id: string;
    intents: string[];
    mode: SystemMode | "contextual";
    name: string;
    outputs: string[];
    playbook: string;
    reads: string[];
  }>;
  templates: RegistryTemplate[];
}

export const systemRegistry = registryJson as AgentRegistry;

export const navigationGroups = systemRegistry.sections.reduce<Array<{ group: string; items: RegistrySection[] }>>(
  (groups, section) => {
    const existing = groups.find((entry) => entry.group === section.group);
    if (existing) existing.items.push(section);
    else groups.push({ group: section.group, items: [section] });
    return groups;
  },
  [],
);

export interface SystemSearchEntry {
  description: string;
  href: string;
  id: string;
  keywords: string;
  kind: "Seção" | "Componente" | "Motion" | "Template" | "Documento" | "Roteiro";
  label: string;
  status?: SystemStatus;
}

export const systemSearchEntries: SystemSearchEntry[] = [
  ...systemRegistry.sections.map((section) => ({
    description: `Abrir ${section.label} no painel`,
    href: section.href,
    id: `section-${section.id}`,
    keywords: [section.label, section.group, ...section.keywords].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Seção" as const,
    label: section.label,
  })),
  ...systemRegistry.components.map((component) => ({
    description: `${component.family} · ${component.requiredStates.length} estados · ${component.modes.join(" + ")}`,
    href: `#component-${component.id}`,
    id: `component-${component.id}`,
    keywords: [component.name, component.family, component.status, ...component.requiredStates].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Componente" as const,
    label: component.name,
    status: component.status,
  })),
  ...systemRegistry.motion.map((recipe) => ({
    description: `${recipe.tier} · ${recipe.durationToken}`,
    href: `#motion-${recipe.id}`,
    id: `motion-${recipe.id}`,
    keywords: [recipe.name, recipe.tier, recipe.use, recipe.status].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Motion" as const,
    label: recipe.name,
    status: recipe.status,
  })),
  ...systemRegistry.templates.map((template) => ({
    description: `${template.mode} · ${template.states.length} estados`,
    href: `#template-${template.id}`,
    id: `template-${template.id}`,
    keywords: [template.name, template.mode, template.status, ...template.states].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Template" as const,
    label: template.name,
    status: template.status,
  })),
  ...systemRegistry.taskRouter.map((route) => ({
    description: `${route.mode} · ${route.outputs.length} entregáveis`,
    href: "#agentes",
    id: `route-${route.id}`,
    keywords: [route.name, route.mode, ...route.intents, ...route.outputs].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Roteiro" as const,
    label: route.name,
  })),
  ...systemRegistry.authority.map((document) => ({
    description: document.purpose,
    href: `/${document.path}`,
    id: `document-${document.order}`,
    keywords: [document.path, document.purpose].join(" ").toLocaleLowerCase("pt-BR"),
    kind: "Documento" as const,
    label: document.path.split("/").at(-1) ?? document.path,
  })),
];

export const statusLabels: Record<SystemStatus, string> = {
  deprecated: "Depreciado",
  experimental: "Experimental",
  planned: "Planejado",
  reference: "Referência",
  stable: "Estável",
};
