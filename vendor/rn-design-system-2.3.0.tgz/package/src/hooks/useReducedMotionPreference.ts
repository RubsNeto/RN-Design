import { useMediaQuery } from "./useMediaQuery";

export const useReducedMotionPreference = () =>
  useMediaQuery("(prefers-reduced-motion: reduce)");
