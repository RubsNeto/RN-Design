import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "../tokens/rn.css";
import "../styles/rn-base.css";
import "../styles/rn-components.css";

const isBudgetReference = window.location.pathname === "/orcamento"
  || window.location.pathname.startsWith("/orcamento/");
const isMotionLab = window.location.pathname === "/animacoes"
  || window.location.pathname.startsWith("/animacoes/");
const isLoaderLab = window.location.pathname === "/carregamento"
  || window.location.pathname.startsWith("/carregamento/");
const isQualityLab = window.location.pathname === "/quality"
  || window.location.pathname.startsWith("/quality/");
const isMotionExport = window.location.pathname === "/motion-export"
  || window.location.pathname.startsWith("/motion-export/");

document.documentElement.classList.toggle("rn-system-document", !isBudgetReference);
document.title = isBudgetReference
  ? "Referência Orçamento — RN Design System"
  : isMotionLab
    ? "Animação oficial — RN Design System"
  : isLoaderLab
    ? "Laboratório de loading — RN Design System"
  : isQualityLab
    ? "Quality fixture — RN Design System"
  : isMotionExport
    ? "Animação para exportação — RN Design System"
  : "RN Design System — Painel humano + agente";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
