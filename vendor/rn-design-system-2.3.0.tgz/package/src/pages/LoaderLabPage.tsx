import { useState } from "react";
import { RnBrandLoader, type RnBrandLoaderVariant } from "../components/RnBrandLoader";
import "../styles/loader-lab.css";

interface LoaderVariation {
  description: string;
  id: RnBrandLoaderVariant;
  name: string;
  number: string;
  signature: string;
}

const LOADER_VARIATIONS: LoaderVariation[] = [
  {
    id: "radial",
    number: "01",
    name: "Montagem com impacto",
    description: "Os nove fragmentos convergem, ultrapassam levemente o encaixe e assentam na geometria oficial com precisão elástica.",
    signature: "Montagem · impacto · repouso",
  },
  {
    id: "pulse",
    number: "02",
    name: "Pulso modular",
    description: "O núcleo inicia uma sequência de expansão que percorre a marca em sentido horário.",
    signature: "Escala · propagação",
  },
  {
    id: "orbit",
    number: "03",
    name: "Órbita precisa",
    description: "Cada módulo descreve um arco limpo antes de encontrar sua posição definitiva.",
    signature: "Órbita · desaceleração",
  },
  {
    id: "wave",
    number: "04",
    name: "Onda ascendente",
    description: "Uma subida vertical com bounce delicado organiza as peças sem deslocamento lateral.",
    signature: "Subida · bounce",
  },
  {
    id: "focus",
    number: "05",
    name: "Foco cristalino",
    description: "Volumes amplos convergem para a escala exata e criam uma sensação óptica de foco.",
    signature: "Profundidade · nitidez",
  },
  {
    id: "scan",
    number: "06",
    name: "Varredura luminosa",
    description: "Uma linha de luz reconstrói a assinatura de cima para baixo, módulo por módulo.",
    signature: "Scan · revelação",
  },
  {
    id: "breathe",
    number: "07",
    name: "Respiração modular",
    description: "A marca permanece inteira enquanto um pulso orgânico percorre cada fragmento.",
    signature: "Presença · continuidade",
  },
  {
    id: "magnetic",
    number: "08",
    name: "Campo magnético",
    description: "As extremidades são atraídas ao centro, ultrapassam o ponto de repouso e assentam.",
    signature: "Atração · encaixe",
  },
  {
    id: "cascade",
    number: "09",
    name: "Cascata alternada",
    description: "Módulos pares e ímpares cruzam sentidos opostos em uma sequência contínua e leve.",
    signature: "Contrafluxo · ritmo",
  },
  {
    id: "eclipse",
    number: "10",
    name: "Eclipse RN",
    description: "A assinatura colapsa em um ponto de energia e retorna acompanhada por uma onda expansiva.",
    signature: "Colapso · expansão",
  },
];

export function LoaderLabPage() {
  const [paused, setPaused] = useState(false);
  const [replayKey, setReplayKey] = useState(0);
  const [selectedId, setSelectedId] = useState<RnBrandLoaderVariant>("radial");
  const selected = LOADER_VARIATIONS.find((variation) => variation.id === selectedId) ?? LOADER_VARIATIONS[0];

  const replay = () => {
    setPaused(false);
    setReplayKey((value) => value + 1);
  };

  return (
    <main className="loader-lab rn-story-page" id="main-content">
      <div className="loader-lab__shell">
        <header className="loader-lab__header">
          <div className="loader-lab__intro">
            <p className="rn-eyebrow">RN Motion · 10 estudos de loading</p>
            <h1>Movimento à altura da <span>marca.</span></h1>
            <p>
              Dez coreografias construídas com os nove fragmentos do ícone vetorial oficial. Selecione uma opção para ampliar e comparar o ritmo.
            </p>
          </div>

          <div className="loader-lab__actions" aria-label="Controles das animações">
            <a className="rn-button rn-button--secondary rn-button--pill" href="/">Voltar ao sistema</a>
            <button
              className="rn-button rn-button--secondary rn-button--pill"
              type="button"
              aria-pressed={paused}
              onClick={() => setPaused((value) => !value)}
            >
              {paused ? "Retomar movimento" : "Pausar movimento"}
            </button>
            <button className="rn-button rn-button--pill" type="button" onClick={replay}>
              Reiniciar todas
            </button>
          </div>
        </header>

        <section className="loader-lab__spotlight" aria-labelledby="loader-spotlight-title">
          <div className="loader-lab__spotlight-copy">
            <span className="loader-lab__counter">Variação {selected.number} / 10</span>
            <h2 id="loader-spotlight-title">{selected.name}</h2>
            <p>{selected.description}</p>
            <dl>
              <div><dt>Construção</dt><dd>9 paths vetoriais</dd></div>
              <div><dt>Movimento</dt><dd>{selected.signature}</dd></div>
              <div><dt>Render</dt><dd>Transform + opacity</dd></div>
            </dl>
          </div>

          <div className="loader-lab__hero-demo" key={`hero-${selected.id}-${replayKey}`}>
            <RnBrandLoader
              label={`Carregando · ${selected.name}`}
              paused={paused}
              size="xl"
              variant={selected.id}
            />
          </div>

          <div className="loader-lab__spotlight-footer" aria-label="Qualidades compartilhadas">
            <span>SVG original</span>
            <span>Ciclo contínuo</span>
            <span>GPU friendly</span>
            <span>Reduced motion</span>
          </div>
        </section>

        <section className="loader-lab__gallery" aria-labelledby="loader-gallery-title">
          <div className="loader-lab__gallery-heading">
            <div>
              <p className="rn-eyebrow">Escolha a direção</p>
              <h2 id="loader-gallery-title">As dez variações</h2>
            </div>
            <p>Clique em uma animação para levá-la ao palco principal.</p>
          </div>

          <ol className="loader-lab__grid">
            {LOADER_VARIATIONS.map((variation) => {
              const isSelected = variation.id === selected.id;
              return (
                <li key={variation.id}>
                  <button
                    className="loader-variant-card"
                    type="button"
                    aria-label={`Selecionar ${variation.name}`}
                    aria-pressed={isSelected}
                    data-selected={isSelected ? "true" : "false"}
                    onClick={() => setSelectedId(variation.id)}
                  >
                    <span className="loader-variant-card__preview" key={`${variation.id}-${replayKey}`}>
                      <RnBrandLoader announce={false} label="" paused={paused} size="md" variant={variation.id} />
                    </span>
                    <span className="loader-variant-card__body">
                      <span className="loader-variant-card__meta">
                        <span>{variation.number}</span>
                        <span>{isSelected ? "Selecionada" : variation.signature}</span>
                      </span>
                      <strong>{variation.name}</strong>
                      <span>{variation.description}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </section>
      </div>
    </main>
  );
}
