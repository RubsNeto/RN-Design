import { useEffect, useState } from "react";
import { RnAnimatedWordmark } from "../components/RnAnimatedWordmark";
import "../styles/motion-export.css";

export function MotionExportPage() {
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const timeout = window.setTimeout(() => setStarted(true), 700);
    return () => window.clearTimeout(timeout);
  }, []);

  return (
    <main className="rn-motion-export" data-export-state={started ? "ready" : "waiting"}>
      <span className="rn-motion-export__orbit rn-motion-export__orbit--large" aria-hidden="true" />
      <span className="rn-motion-export__orbit rn-motion-export__orbit--small" aria-hidden="true" />
      <div className="rn-motion-export__stage">
        {started ? <RnAnimatedWordmark size="hero" timing="overlap" /> : null}
      </div>
      <p>RN DESIGN · ABERTURA OFICIAL</p>
    </main>
  );
}
