import { useState } from "react";
import { RnAnimatedWordmark } from "../components/RnAnimatedWordmark";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";
import "../styles/motion-lab.css";

function Wordmark({ replayKey }: { replayKey: number }) {
  return <RnAnimatedWordmark className="motion-lab__wordmark" key={replayKey} size="showcase" />;
}

export function MotionLabPage() {
  const reducedMotion = useReducedMotionPreference();
  const [replayKey, setReplayKey] = useState(0);

  return (
    <main className="motion-lab rn-story-page rn-brand-canvas rn-brand-canvas--editorial" id="main-content">
      <div className="motion-lab__shell">
        <header className="motion-lab__header">
          <div className="motion-lab__intro">
            <p className="rn-eyebrow">RN Motion · animação principal</p>
            <h1>Subida com <span>bounce.</span></h1>
            <p>
              A animação oficial começa com RN DESIGN: letras retas sobem uma a uma com bounce vertical. Depois, os nove fragmentos do símbolo convergem e fecham a marca completa.
            </p>
          </div>

          <div className="motion-lab__header-actions">
            <a className="rn-button rn-button--secondary rn-button--pill" href="/">Voltar ao sistema</a>
            <button className="rn-button rn-button--pill" type="button" onClick={() => setReplayKey((value) => value + 1)}>
              Reproduzir animação
            </button>
          </div>
        </header>

        {reducedMotion && (
          <p className="motion-lab__notice" role="status">
            “Reduzir movimento” está ativo no sistema. A marca está sendo mostrada no estado final estático.
          </p>
        )}

        <section className="motion-lab__official" aria-label="Animação oficial do wordmark RN Design">
          <div className="motion-lab__official-label">
            <span>Oficial</span>
            <h2>Subida com bounce</h2>
          </div>
          <div className="motion-lab__stage">
            <Wordmark replayKey={replayKey} />
          </div>
          <ol className="motion-lab__sequence" aria-label="Sequência da animação oficial">
            <li><span>01</span><strong>Letras</strong><small>Entrada vertical, uma a uma</small></li>
            <li><span>02</span><strong>Símbolo</strong><small>Nove peças convergem ao centro</small></li>
            <li><span>03</span><strong>Lockup</strong><small>Marca completa em repouso</small></li>
          </ol>
        </section>
      </div>
    </main>
  );
}
