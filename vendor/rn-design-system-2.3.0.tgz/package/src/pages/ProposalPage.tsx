import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { motion } from "framer-motion";
import { useLayoutEffect, useRef } from "react";
import { BrandNav } from "../components/BrandNav";
import { ScrollProgress } from "../components/ScrollProgress";
import { company } from "../data/content";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";
import { useSmoothScroll } from "../hooks/useSmoothScroll";
import { FaqSection } from "../sections/FaqSection";
import { FounderSection } from "../sections/FounderSection";
import { HeroSection } from "../sections/HeroSection";
import { ObjectiveSection } from "../sections/ObjectiveSection";
import { PortfolioSection } from "../sections/PortfolioSection";
import { PricingSection } from "../sections/PricingSection";
import { ProcessSection } from "../sections/ProcessSection";
import { ScreensSection } from "../sections/ScreensSection";
import "../styles/global.css";

gsap.registerPlugin(ScrollTrigger);

/** Envolve cada palavra do heading em spans para o reveal escalonado. */
function splitHeadingWords(heading: HTMLElement) {
  if (heading.dataset.split === "true") return;
  const walk = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent ?? "";
      if (!text.trim()) return;
      const fragment = document.createDocumentFragment();
      text.split(/(\s+)/).forEach((part) => {
        if (!part) return;
        if (/^\s+$/.test(part)) {
          fragment.appendChild(document.createTextNode(part));
          return;
        }
        // <u> em vez de <span> para não casar com os seletores "h2 span" de destaque
        const wrap = document.createElement("u");
        wrap.className = "reveal-word";
        const inner = document.createElement("i");
        inner.textContent = part;
        wrap.appendChild(inner);
        fragment.appendChild(wrap);
      });
      node.parentNode?.replaceChild(fragment, node);
    } else if (node.nodeType === Node.ELEMENT_NODE && (node as HTMLElement).tagName !== "BR") {
      Array.from(node.childNodes).forEach(walk);
    }
  };
  Array.from(heading.childNodes).forEach(walk);
  heading.dataset.split = "true";
}

export function ProposalPage() {
  const rootRef = useRef<HTMLElement>(null);
  const reducedMotion = useReducedMotionPreference();

  useSmoothScroll(!reducedMotion);

  useLayoutEffect(() => {
    if (!rootRef.current) return;
    if (reducedMotion) {
      gsap.set(rootRef.current.querySelectorAll("[data-reveal]"), { clearProps: "all" });
      return;
    }

    let revealObserver: IntersectionObserver | null = null;
    let revealElements: HTMLElement[] = [];

    const context = gsap.context(() => {
      gsap.fromTo(
        ".brand-nav",
        { yPercent: -115, opacity: 0 },
        { yPercent: 0, opacity: 1, duration: 0.62, delay: 0.04, ease: "power4.out" },
      );

      revealElements = gsap.utils.toArray<HTMLElement>("[data-reveal]");
      revealElements.forEach((element) => {
        if (element.dataset.reveal !== "heading") return;
        element.querySelectorAll<HTMLElement>("h2").forEach(splitHeadingWords);
        gsap.set(element.querySelectorAll(".reveal-word i"), { yPercent: 118, rotate: 4 });
      });
      const revealState = (element: HTMLElement) => {
        const kind = element.dataset.reveal;
        return kind === "heading"
          ? { opacity: 0, y: 64, rotateX: 7, clipPath: "inset(0 0 42% 0)" }
          : kind === "card"
            ? { opacity: 0, y: 68, scale: 0.965, rotateX: 5 }
            : kind === "ticket"
              ? { opacity: 0, y: 88, scale: 0.95, rotateX: 8 }
              : { opacity: 0, y: 46 };
      };

      revealElements.forEach((element) => {
        gsap.set(element, {
          ...revealState(element),
          transformPerspective: 1200,
          transformOrigin: "50% 100%",
        });
      });

      revealObserver = new IntersectionObserver(
        (entries, observer) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            const element = entry.target as HTMLElement;
            const kind = element.dataset.reveal;
            observer.unobserve(element);
            gsap.to(element, {
              opacity: 1,
              y: 0,
              scale: 1,
              rotateX: 0,
              clipPath: "inset(0 0 0% 0)",
              duration: kind === "heading" || kind === "ticket" ? 0.82 : 0.65,
              ease: "power4.out",
              overwrite: "auto",
            });
            if (kind === "heading") {
              gsap.to(element.querySelectorAll(".reveal-word i"), {
                yPercent: 0,
                rotate: 0,
                duration: 0.85,
                ease: "power4.out",
                stagger: 0.05,
                overwrite: "auto",
              });
            }
          });
        },
        { rootMargin: "0px 0px -10% 0px", threshold: 0.01 },
      );
      revealElements.forEach((element) => revealObserver?.observe(element));

      const heroScroll = gsap.timeline({
        scrollTrigger: {
          trigger: ".hero-section",
          start: "top top",
          end: "bottom top",
          scrub: 0.8,
        },
      });

      heroScroll
        .to(".hero-section__wordmark-stage", { y: -112, scale: 1.055, rotate: -0.35, ease: "none" }, 0)
        .to(".hero-section__wordmark-reflection", { opacity: 0.78, ease: "none" }, 0)
        .to(".hero-section__content", { y: -68, ease: "none" }, 0)
        .to(".hero-section__ambient", { scale: 1.12, rotate: 0.75, ease: "none" }, 0)
        .to(".hero-scroll-cue", { y: -28, opacity: 0, ease: "none" }, 0)
        .fromTo(
          ".hero-section__handoff",
          { y: 48, opacity: 0 },
          { y: -4, opacity: 1, ease: "none" },
          0.24,
        )
        .fromTo(
          ".hero-section__handoff i",
          { scaleX: 0.08 },
          { scaleX: 1, ease: "none" },
          0.3,
        );

      const objectiveScene = gsap.timeline({
        scrollTrigger: {
          trigger: ".objective-gallery",
          start: "top 92%",
          end: "top 32%",
          scrub: 0.72,
        },
      });

      objectiveScene
        .fromTo(
          ".objective-gallery__header",
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.32, ease: "power3.out" },
          0,
        )
        .fromTo(
          ".objective-gallery__header i",
          { scaleX: 0.04 },
          { scaleX: 1, duration: 0.42, ease: "power3.out" },
          0.04,
        )
        .fromTo(
          ".objective-gallery__frame",
          { opacity: 0, scale: 0.985 },
          { opacity: 1, scale: 1, duration: 0.55, ease: "power2.out" },
          0.04,
        )
        .fromTo(
          ".objective-gallery__laptop",
          { y: 158, opacity: 0.12, scale: 0.93, rotate: -1.8 },
          { y: -12, opacity: 1, scale: 1, rotate: 0, duration: 1, ease: "power2.out" },
          0,
        )
        .fromTo(
          ".objective-gallery__phones",
          { y: 218, opacity: 0.08, scale: 0.91, rotate: 1.4 },
          { y: -42, opacity: 1, scale: 1, rotate: 0, duration: 1, ease: "power2.out" },
          0,
        )
        .fromTo(
          ".objective-gallery__glow",
          { opacity: 0, scale: 0.72 },
          { opacity: 1, scale: 1, duration: 0.78, ease: "power2.out" },
          0.08,
        );

      if (window.matchMedia("(min-width: 901px)").matches) {
        gsap.to(".founder-section__portrait", {
          y: -92,
          scale: 1.025,
          ease: "none",
          scrollTrigger: {
            trigger: ".founder-section",
            start: "top bottom",
            end: "bottom top",
            scrub: true,
          },
        });

        gsap.fromTo(
          ".closing-scene__devices",
          { y: 145, scale: 0.86, rotate: 1.6 },
          {
            y: 0,
            scale: 1,
            rotate: 0,
            ease: "none",
            scrollTrigger: {
              trigger: ".closing-scene",
              start: "top bottom",
              end: "center 58%",
              scrub: 0.8,
            },
          },
        );

        gsap.fromTo(
          ".closing-scene__badge",
          { y: 90, opacity: 0, scale: 0.9 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            ease: "power3.out",
            scrollTrigger: {
              trigger: ".closing-scene",
              start: "top 65%",
              end: "top 28%",
              scrub: 0.6,
            },
          },
        );

        gsap.to(".closing-scene__glow--secondary", {
          scale: 1.16,
          y: -42,
          ease: "none",
          scrollTrigger: {
            trigger: ".closing-scene",
            start: "top bottom",
            end: "bottom bottom",
            scrub: 1,
          },
        });
      }
    }, rootRef);

    let alive = true;
    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener("load", onLoad, { once: true });
    document.fonts.ready.then(() => {
      if (alive) ScrollTrigger.refresh();
    });
    return () => {
      alive = false;
      window.removeEventListener("load", onLoad);
      revealObserver?.disconnect();
      gsap.killTweensOf(revealElements);
      context.revert();
    };
  }, [reducedMotion]);

  return (
    <motion.main
      ref={rootRef}
      className="proposal-page"
      initial={false}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: reducedMotion ? 0 : 0.32, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.div
        className="proposal-page__entry"
        aria-hidden="true"
        initial={{ y: "0%" }}
        animate={{ y: "-100%" }}
        transition={{ duration: reducedMotion ? 0 : 0.58, ease: [0.76, 0, 0.24, 1] }}
      >
        <motion.div
          className="proposal-page__entry-mark"
          initial={{ opacity: 0, y: 18, scale: 0.94 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: reducedMotion ? 0 : 0.34, delay: reducedMotion ? 0 : 0.04, ease: [0.16, 1, 0.3, 1] }}
        >
          <img src="/assets/brand/rn-icon.png" alt="" />
          <span>{company.tagline}</span>
        </motion.div>
      </motion.div>
      <div className="proposal-page__grain" aria-hidden="true" />
      <ScrollProgress />
      <BrandNav />
      <HeroSection />
      <ObjectiveSection />
      <ScreensSection />
      <FounderSection />
      <ProcessSection />
      <PortfolioSection />
      <PricingSection />
      <FaqSection />
    </motion.main>
  );
}
