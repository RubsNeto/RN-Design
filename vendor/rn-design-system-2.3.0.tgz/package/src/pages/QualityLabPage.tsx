import { useState } from "react";
import {
  RnAlert,
  RnAnimatedWordmark,
  RnAvatar,
  RnBarChart,
  RnBrandLoader,
  RnButton,
  RnCard,
  RnCheckbox,
  RnCombobox,
  RnDateTimeField,
  RnDialog,
  RnField,
  RnProgress,
  RnSegmented,
  RnStepper,
  RnSwitch,
  RnTabs,
} from "../react";
import "../styles/quality-lab.css";

const clients = [
  { id: "aurora", label: "Aurora Tecnologia", keywords: ["software", "são paulo"] },
  { id: "norte", label: "Norte Logística", keywords: ["transporte", "recife"] },
  { id: "viva", label: "Viva Saúde", keywords: ["clínica", "curitiba"] },
];

const chartSeries = [
  { id: "actual", label: "Realizado" },
  { id: "goal", label: "Meta" },
];

const chartData = [
  { label: "Jan", values: { actual: 64, goal: 72 } },
  { label: "Fev", values: { actual: 78, goal: 76 } },
  { label: "Mar", values: { actual: 86, goal: 82 } },
  { label: "Abr", values: { actual: 91, goal: 88 } },
];

export function QualityLabPage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [client, setClient] = useState<string | null>("aurora");
  const [notifications, setNotifications] = useState(true);
  const [view, setView] = useState("month");

  return (
    <main className="rn-quality-lab">
      <header className="rn-quality-lab__header">
        <div>
          <p className="rn-eyebrow">Quality fixture · RN Design 2.3</p>
          <h1>Contrato visual e acessível</h1>
          <p>Rota determinística para axe, teclado e regressão visual nos quatro viewports oficiais.</p>
        </div>
        <RnAnimatedWordmark animated={false} size="compact" />
      </header>

      <section className="rn-quality-lab__grid" aria-label="Ações e formulários">
        <RnCard className="rn-quality-lab__card" variant="soft">
          <h2>Ações e estados</h2>
          <div className="rn-quality-lab__actions">
            <RnButton onClick={() => setDialogOpen(true)}>Abrir diálogo</RnButton>
            <RnButton variant="secondary">Ação secundária</RnButton>
            <RnButton variant="danger">Excluir</RnButton>
          </div>
          <RnAlert title="Sistema operacional" tone="success">Tokens, componentes e contratos carregados.</RnAlert>
          <RnProgress label="Cobertura do fluxo" value={84} />
        </RnCard>

        <RnCard className="rn-quality-lab__card">
          <h2>Formulário canônico</h2>
          <RnField label="Nome do projeto" defaultValue="Portal RN" required />
          <RnCombobox
            label="Cliente"
            options={clients}
            value={client}
            onValueChange={(option) => setClient(option?.id ?? null)}
            description="Digite para filtrar ou use as setas."
          />
          <RnDateTimeField label="Data de entrega" defaultValue="2026-09-18" />
          <RnCheckbox label="Enviar resumo por e-mail" defaultChecked />
          <RnSwitch checked={notifications} label="Notificações do projeto" onCheckedChange={setNotifications} />
        </RnCard>
      </section>

      <section className="rn-quality-lab__section" aria-labelledby="quality-navigation-title">
        <div className="rn-quality-lab__section-heading">
          <div>
            <p className="rn-eyebrow">Navegação</p>
            <h2 id="quality-navigation-title">Seleção e progresso</h2>
          </div>
          <RnAvatar name="RN Design" size="lg" />
        </div>
        <RnSegmented
          label="Período do relatório"
          items={[{ id: "week", label: "Semana" }, { id: "month", label: "Mês" }, { id: "year", label: "Ano" }]}
          value={view}
          onValueChange={setView}
        />
        <RnTabs
          label="Detalhes do projeto"
          items={[
            { id: "overview", label: "Visão geral", content: <p>Resumo operacional com hierarquia e densidade Product.</p> },
            { id: "activity", label: "Atividade", content: <p>Eventos recentes em ordem cronológica.</p> },
            { id: "files", label: "Arquivos", content: <p>Documentos associados ao projeto.</p> },
          ]}
        />
        <RnStepper
          label="Publicação"
          currentStep="quality"
          steps={[
            { id: "brief", label: "Brief" },
            { id: "build", label: "Construção" },
            { id: "quality", label: "Qualidade" },
            { id: "release", label: "Release" },
          ]}
        />
      </section>

      <section className="rn-quality-lab__section" aria-labelledby="quality-data-title">
        <h2 id="quality-data-title">Dados equivalentes</h2>
        <RnBarChart
          title="Índice de entrega"
          description="Realizado comparado à meta trimestral."
          series={chartSeries}
          data={chartData}
        />
      </section>

      <section className="rn-quality-lab__loader" aria-label="Loading oficial pausado para comparação visual">
        <RnBrandLoader announce={false} paused size="md" label="Montagem com impacto" />
      </section>

      <RnDialog
        open={dialogOpen}
        title="Contrato de confirmação"
        description="O foco permanece no diálogo e retorna ao gatilho ao fechar."
        onRequestClose={() => setDialogOpen(false)}
        footer={<RnButton onClick={() => setDialogOpen(false)}>Confirmar</RnButton>}
      >
        <p>Este diálogo usa o elemento nativo, nome acessível e fechamento por Escape.</p>
      </RnDialog>
    </main>
  );
}
