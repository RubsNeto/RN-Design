import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
  type Ref,
} from "react";
import { useReducedMotion } from "framer-motion";
import { RnAnimatedWordmark, type RnAnimatedWordmarkSize } from "../components/RnAnimatedWordmark";
import { RnBrandLoader } from "../components/RnBrandLoader";
import { ComponentPlayground } from "../components/ComponentPlayground";
import { ArtDirectionPanel } from "../components/ArtDirectionPanel";
import { ScrollProgress } from "../components/ScrollProgress";
import { SystemIcon, type SystemIconName } from "../components/SystemIcon";
import { RnBarChart, RnCombobox, RnDateTimeField } from "../react";
import {
  navigationGroups,
  statusLabels,
  systemRegistry,
  systemSearchEntries,
  type RegistryMotion,
  type RegistryTemplate,
  type SystemMode,
  type SystemStatus,
} from "../data/systemRegistry";
import "../styles/system-hub.css";
import "../styles/motion-studio.css";

type FilterValue<T extends string> = "all" | T;
type PreviewViewport = "desktop" | "tablet" | "mobile";
type FeedbackState = "loading" | "empty" | "error" | "success" | "permission";
type MotionSpeed = "slow" | "normal" | "fast";

const importSnippet = `@import "@rn-design/system/tokens.css";
@import "@rn-design/system/base.css";
@import "@rn-design/system/components.css";`;

const componentSnippet = `<button class="rn-button" type="submit">
  Salvar alterações
</button>`;

const feedbackLabels: Record<FeedbackState, string> = {
  empty: "Empty",
  error: "Error",
  loading: "Loading",
  permission: "Permission",
  success: "Success",
};

const statusOrder: Array<FilterValue<SystemStatus>> = ["all", "stable"];
const modeOrder: Array<FilterValue<SystemMode>> = ["all", "product", "expressive"];

const surfacePrinciples = [
  ["01", "Orçamento-first", "A proposta define escala, composição, superfícies e movimento."],
  ["02", "Uma estética", "Product e Expressive usam o mesmo DNA em volumes diferentes."],
  ["03", "Estado antes do efeito", "Conteúdo e ação funcionam antes de qualquer animação."],
  ["04", "Decisão verificável", "Toda regra aponta para token, componente, documento e gate."],
] as const;

const qualityPairs = [
  ["Texto / branco", "18.60:1", "AA"],
  ["Brand text / branco", "5.35:1", "AA"],
  ["Ink / celeste", "7.25:1", "AA"],
  ["Foco / branco", "7.94:1", "UI"],
  ["Borda / branco", "4.57:1", "UI"],
  ["Story muted / deep", "6.12:1", "AA"],
] as const;

const copyExamples = [
  {
    avoid: "Ops! Algo mágico deu errado.",
    do: "Não foi possível salvar porque a conexão foi interrompida. Verifique sua internet e tente novamente.",
    label: "Erro",
  },
  {
    avoid: "Aguarde…",
    do: "Carregando projetos…",
    label: "Loading",
  },
  {
    avoid: "Enviar",
    do: "Criar projeto",
    label: "Ação",
  },
] as const;

const iconExamples: Array<{ label: string; name: SystemIconName; use: string }> = [
  { label: "Busca", name: "search", use: "Encontrar conteúdo" },
  { label: "Código", name: "code", use: "Implementação" },
  { label: "Validação", name: "shield", use: "Qualidade" },
  { label: "Movimento", name: "motion", use: "Motion" },
  { label: "Documento", name: "docs", use: "Referência" },
];

function cx(...values: Array<false | null | string | undefined>) {
  return values.filter(Boolean).join(" ");
}

function useActiveSection() {
  const [activeSection, setActiveSection] = useState("inicio");

  useEffect(() => {
    const elements = systemRegistry.sections
      .map((section) => document.getElementById(section.id))
      .filter((element): element is HTMLElement => Boolean(element));

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActiveSection(visible.target.id);
      },
      { rootMargin: "-18% 0px -68%", threshold: [0.08, 0.25, 0.5] },
    );

    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  return activeSection;
}

function Wordmark({
  animated = true,
  replayKey = 0,
  size = "hero",
  timing = "sequential",
}: {
  animated?: boolean;
  replayKey?: number;
  size?: RnAnimatedWordmarkSize;
  timing?: "sequential" | "overlap";
}) {
  return (
    <RnAnimatedWordmark
      animated={animated}
      className="hub-wordmark"
      key={replayKey}
      size={size}
      timing={timing}
    />
  );
}

function StatusBadge({ status }: { status: SystemStatus }) {
  return <span className="hub-status" data-status={status}>{statusLabels[status]}</span>;
}

function SectionHeading({
  actions,
  description,
  eyebrow,
  id,
  title,
}: {
  actions?: ReactNode;
  description: string;
  eyebrow: string;
  id: string;
  title: ReactNode;
}) {
  return (
    <header className="hub-section-heading">
      <div className="hub-section-heading__copy">
        <p className="hub-eyebrow"><span aria-hidden="true">‹ ◉ ›</span>{eyebrow}</p>
        <h2 id={id}>{title}</h2>
        <p>{description}</p>
      </div>
      {actions ? <div className="hub-section-heading__actions">{actions}</div> : null}
    </header>
  );
}

function CopyButton({ copied, label, onCopy }: { copied: boolean; label: string; onCopy: () => void }) {
  return (
    <button className="hub-copy-button" type="button" onClick={onCopy} aria-label={`Copiar ${label}`}>
      <SystemIcon name={copied ? "check" : "copy"} />
      <span>{copied ? "Copiado" : "Copiar"}</span>
    </button>
  );
}

function FilterButton<T extends string>({
  active,
  children,
  onClick,
  value,
}: {
  active: boolean;
  children: ReactNode;
  onClick: (value: FilterValue<T>) => void;
  value: FilterValue<T>;
}) {
  return (
    <button className="hub-filter" type="button" aria-pressed={active} onClick={() => onClick(value)}>
      {children}
    </button>
  );
}

function SystemSearch({ onClose }: { onClose?: () => void }) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const normalizedQuery = query.trim().toLocaleLowerCase("pt-BR");
  const results = useMemo(
    () => normalizedQuery
      ? systemSearchEntries
        .filter((entry) => `${entry.label.toLocaleLowerCase("pt-BR")} ${entry.keywords}`.includes(normalizedQuery))
        .slice(0, 8)
      : [],
    [normalizedQuery],
  );

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const isTyping = target?.matches("input, textarea, select, [contenteditable='true']");
      if ((event.key === "/" && !isTyping) || ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k")) {
        event.preventDefault();
        inputRef.current?.focus();
      }
      if (event.key === "Escape" && document.activeElement === inputRef.current) {
        setQuery("");
        inputRef.current?.blur();
        onClose?.();
      }
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, [onClose]);

  return (
    <div className="hub-search" data-open={Boolean(normalizedQuery)}>
      <label className="rn-sr-only" htmlFor="system-search">Buscar no RN Design System</label>
      <SystemIcon name="search" />
      <input
        id="system-search"
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Buscar componente, motion ou regra…"
        ref={inputRef}
        type="search"
        value={query}
      />
      <kbd>Ctrl K</kbd>
      {normalizedQuery ? (
        <div className="hub-search-results" id="system-search-results" role="region" aria-label="Resultados da busca" aria-live="polite">
          <div className="hub-search-results__meta">
            <span>{results.length ? `${results.length} resultados` : "Nenhum resultado"}</span>
            <button type="button" onClick={() => setQuery("")} aria-label="Limpar busca"><SystemIcon name="x" /></button>
          </div>
          {results.length ? (
            <ul>
              {results.map((result) => (
                <li key={result.id}>
                  <a href={result.href} onClick={() => { setQuery(""); onClose?.(); }}>
                    <span><small>{result.kind}</small><strong>{result.label}</strong><em>{result.description}</em></span>
                    {result.status ? <StatusBadge status={result.status} /> : <SystemIcon name="arrow" />}
                  </a>
                </li>
              ))}
            </ul>
          ) : (
            <div className="hub-search-empty">
              <strong>Tente buscar por “button”, “loading” ou “dashboard”.</strong>
              <p>Você também pode navegar pelas categorias na lateral.</p>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
}

function Topbar() {
  return (
    <header className="hub-topbar">
      <a className="hub-topbar__brand" href="#inicio" aria-label="RN Design System — início">
        <img src="/assets/brand/rn-logo.png" alt="" width="821" height="400" />
        <span>System <small>v{systemRegistry.meta.version}</small></span>
      </a>
      <SystemSearch />
      <div className="hub-topbar__actions">
        <a href="/agent/index.json"><SystemIcon name="agent" /> Índice IA</a>
        <a className="hub-topbar__primary" href="/orcamento">Referência <SystemIcon name="external" /></a>
      </div>
    </header>
  );
}

function Sidebar({ activeSection }: { activeSection: string }) {
  return (
    <aside className="hub-sidebar" aria-label="Seções do RN Design System">
      <div className="hub-sidebar__status">
        <span><i aria-hidden="true" /> Fonte oficial</span>
        <strong>Humano + agente</strong>
      </div>
      <nav>
        {navigationGroups.map((group) => (
          <div className="hub-sidebar__group" key={group.group}>
            <span>{group.group}</span>
            {group.items.map((item) => (
              <a aria-current={activeSection === item.id ? "location" : undefined} href={item.href} key={item.id}>
                <i aria-hidden="true" />
                {item.label}
              </a>
            ))}
          </div>
        ))}
      </nav>
      <div className="hub-sidebar__footer">
        <span>Web responsiva</span>
        <span>WCAG 2.2 AA</span>
      </div>
    </aside>
  );
}

function BrandSection({ copyValue }: { copyValue: (id: string, value: string) => void }) {
  const [copied, setCopied] = useState("");
  const handleCopy = (id: string, value: string) => {
    copyValue(id, value);
    setCopied(id);
    window.setTimeout(() => setCopied(""), 1400);
  };

  return (
    <section className="hub-section" id="marca" aria-labelledby="brand-title">
      <SectionHeading
        id="brand-title"
        eyebrow="01 — Marca"
        title={<>Uma assinatura <span>sem aproximações.</span></>}
        description="O símbolo vetorial, o lockup, as margens e os fundos são decisões oficiais. Agentes usam os assets; nunca redesenham a marca."
      />

      <div className="hub-brand-grid">
        <article className="hub-brand-stage">
          <div className="hub-brand-stage__safe-area" aria-label="Área de proteção do símbolo RN">
            <img src="/assets/brand/rn-icon.svg" alt="Símbolo RN Design" width="384" height="384" loading="lazy" decoding="async" />
          </div>
          <div className="hub-brand-stage__meta">
            <span><strong>09</strong> paths vetoriais</span>
            <span><strong>384</strong> viewBox oficial</span>
            <span><strong>25%</strong> área de proteção</span>
          </div>
        </article>

        <div className="hub-brand-assets">
          <article className="hub-panel-card hub-brand-lockup">
            <header><span>LOCKUP PRINCIPAL</span><StatusBadge status="stable" /></header>
            <div><img src="/assets/brand/rn-logo.png" alt="RN Design & Serviços" width="821" height="400" loading="lazy" decoding="async" /></div>
            <footer>
              <code>assets/brand/rn-logo.png</code>
              <CopyButton copied={copied === "logo"} label="caminho do logo" onCopy={() => handleCopy("logo", "assets/brand/rn-logo.png")} />
            </footer>
          </article>
          <article className="hub-panel-card hub-brand-file">
            <header><span>VETOR CANÔNICO</span><StatusBadge status="stable" /></header>
            <div className="hub-brand-file__row">
              <img src="/assets/brand/rn-icon.svg" alt="" width="384" height="384" loading="lazy" decoding="async" aria-hidden="true" />
              <div><strong>rn-icon.svg</strong><p>Gradientes, contornos e nove fragmentos preservados.</p></div>
            </div>
            <footer>
              <a href="/assets/brand/rn-icon.svg">Abrir SVG <SystemIcon name="external" /></a>
              <CopyButton copied={copied === "icon"} label="caminho do ícone" onCopy={() => handleCopy("icon", "assets/brand/rn-icon.svg")} />
            </footer>
          </article>
        </div>
      </div>

      <div className="hub-do-dont">
        <article data-kind="do">
          <span><SystemIcon name="check" /> Use</span>
          <strong>Arte oficial colorida, proporção preservada e fundo com contraste medido.</strong>
        </article>
        <article data-kind="avoid">
          <span><SystemIcon name="x" /> Não use</span>
          <strong>Recolorir, girar, distorcer, simplificar paths ou transformar o símbolo em ícone funcional.</strong>
        </article>
      </div>
    </section>
  );
}

function FoundationsSection() {
  return (
    <section className="hub-section hub-section--soft" id="fundamentos" aria-labelledby="foundations-title">
      <SectionHeading
        id="foundations-title"
        eyebrow="02 — Fundações"
        title={<>Uma estética. <span>Duas intensidades.</span></>}
        description="O orçamento é a fonte visual dominante. Product reduz densidade e motion para operação; Expressive preserva a narrativa completa."
      />

      <div className="hub-mode-decision">
        {systemRegistry.modes.map((mode) => (
          <article data-mode={mode.id} key={mode.id}>
            <header><span>{mode.name}</span><StatusBadge status={mode.status} /></header>
            <h3>{mode.id === "product" ? "Operar todos os dias." : "Apresentar e criar memória."}</h3>
            <p>{mode.surface}</p>
            <dl>
              <div><dt>Use para</dt><dd>{mode.useFor.join(" · ")}</dd></div>
              <div><dt>Motion</dt><dd>{mode.motion}</dd></div>
            </dl>
            <a href={`/${mode.override}`}>Abrir override <SystemIcon name="arrow" /></a>
          </article>
        ))}
      </div>

      <div className="hub-principles">
        {surfacePrinciples.map(([index, title, description]) => (
          <article key={index}>
            <span>{index}</span>
            <h3>{title}</h3>
            <p>{description}</p>
          </article>
        ))}
      </div>

      <article className="hub-authority">
        <header>
          <div><p className="hub-eyebrow"><span aria-hidden="true">‹ ◉ ›</span>ORDEM DE AUTORIDADE</p><h3>O agente sabe onde desempatar.</h3></div>
          <a href="/agent/index.json">Ver índice JSON <SystemIcon name="external" /></a>
        </header>
        <ol>
          {systemRegistry.authority.map((source) => (
            <li key={source.order}>
              <span>{String(source.order).padStart(2, "0")}</span>
              <div><strong>{source.path}</strong><p>{source.purpose}</p></div>
            </li>
          ))}
        </ol>
      </article>
    </section>
  );
}

function TokensSection({ copyValue }: { copyValue: (id: string, value: string) => void }) {
  const [copied, setCopied] = useState("");
  const handleCopy = (id: string, value: string) => {
    copyValue(id, value);
    setCopied(id);
    window.setTimeout(() => setCopied(""), 1400);
  };

  return (
    <section className="hub-section" id="tokens" aria-labelledby="tokens-title">
      <SectionHeading
        id="tokens-title"
        eyebrow="03 — Tokens"
        title={<>Decisões visuais em <span>quatro formatos.</span></>}
        description="CSS é a fonte editável. JSON, JavaScript e TypeScript são gerados para que humanos e agentes usem os mesmos valores."
        actions={<a className="hub-text-link" href="/tokens/rn.tokens.json">Abrir DTCG JSON <SystemIcon name="external" /></a>}
      />

      <div className="hub-token-grid">
        {systemRegistry.foundations.colors.map((color) => (
          <article className="hub-color-token" key={color.id}>
            <div style={{ "--hub-token-color": `var(${color.token})` } as CSSProperties} aria-hidden="true" />
            <span><strong>{color.name}</strong><small>{color.role}</small></span>
            <code>{color.token}</code>
            <CopyButton copied={copied === color.id} label={color.token} onCopy={() => handleCopy(color.id, color.token)} />
          </article>
        ))}
      </div>

      <div className="hub-foundation-grid">
        <article className="hub-foundation-card hub-type-card">
          <header><SystemIcon name="type" /><span>TIPOGRAFIA</span></header>
          <strong className="hub-type-card__sample">Aa</strong>
          <h3>Montserrat RN</h3>
          <p>Clareza operacional e escala editorial na mesma família.</p>
          <div>{systemRegistry.foundations.font.weights.map((weight) => <span key={weight} style={{ fontWeight: weight }}>{weight}</span>)}</div>
        </article>

        <article className="hub-foundation-card">
          <header><SystemIcon name="grid" /><span>ESPAÇAMENTO</span></header>
          <div className="hub-space-ramp">
            {systemRegistry.foundations.spacing.slice(1, 10).map((space, index) => (
              <span key={space}><i style={{ "--hub-space-step": index + 1 } as CSSProperties} />{space}</span>
            ))}
          </div>
        </article>

        <article className="hub-foundation-card">
          <header><SystemIcon name="layers" /><span>RAIOS</span></header>
          <div className="hub-radius-ramp">
            {systemRegistry.foundations.radius.map((radius) => <span key={radius} style={{ borderRadius: radius === 999 ? "var(--rn-radius-pill)" : `${radius}px` }}>{radius === 999 ? "Pill" : radius}</span>)}
          </div>
        </article>

        <article className="hub-foundation-card">
          <header><SystemIcon name="motion" /><span>MOTION TOKENS</span></header>
          <div className="hub-duration-ramp">
            {["100", "160", "240", "420", "580", "650", "720", "820"].map((duration, index) => (
              <span key={duration}><i style={{ "--hub-duration-index": index + 1 } as CSSProperties} />{duration}ms</span>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

function LiveComponents() {
  const [notifications, setNotifications] = useState(true);
  const [segment, setSegment] = useState("month");
  const [progress, setProgress] = useState(68);
  const [saving, setSaving] = useState(false);

  const simulateSave = () => {
    if (saving) return;
    setSaving(true);
    window.setTimeout(() => setSaving(false), 1200);
  };

  return (
    <div className="hub-live-components">
      <article className="hub-demo-card hub-demo-card--actions">
        <header><span>ACTIONS</span><strong>Button</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body hub-inline-actions">
          <button className="rn-button rn-button--inline" type="button" aria-busy={saving || undefined} disabled={saving} onClick={simulateSave}>
            {saving ? "Salvando alterações" : "Salvar alterações"}
          </button>
          <button className="rn-button rn-button--secondary rn-button--inline" type="button">Cancelar</button>
          <span className="rn-tooltip">
            <button className="rn-icon-button" type="button" aria-label="Abrir documentação" aria-describedby="component-tooltip"><SystemIcon name="docs" /></button>
            <span className="rn-tooltip__content" id="component-tooltip" role="tooltip">Abrir documentação</span>
          </span>
        </div>
      </article>

      <article className="hub-demo-card">
        <header><span>PREFERENCE</span><strong>Switch</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body">
          <button className="rn-switch" type="button" role="switch" aria-checked={notifications} onClick={() => setNotifications((value) => !value)}>
            <span className="rn-switch__track" aria-hidden="true"><span className="rn-switch__thumb" /></span>
            <span>Notificações {notifications ? "ativadas" : "desativadas"}</span>
          </button>
        </div>
      </article>

      <article className="hub-demo-card">
        <header><span>VIEW</span><strong>Segmented</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body">
          <div className="rn-segmented" role="group" aria-label="Período do relatório">
            {["week", "month", "year"].map((value) => (
              <button className="rn-segmented__item" type="button" aria-pressed={segment === value} onClick={() => setSegment(value)} key={value}>
                {value === "week" ? "Semana" : value === "month" ? "Mês" : "Ano"}
              </button>
            ))}
          </div>
        </div>
      </article>

      <article className="hub-demo-card hub-demo-card--search">
        <header><span>DISCOVERY</span><strong>Search</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body">
          <label className="rn-field__label" htmlFor="demo-search">Buscar projetos</label>
          <div className="rn-search">
            <SystemIcon name="search" />
            <input className="rn-field__control" id="demo-search" placeholder="Nome, cliente ou responsável" type="search" />
          </div>
        </div>
      </article>

      <article className="hub-demo-card hub-demo-card--progress">
        <header><span>PROCESS</span><strong>Progress</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body">
          <div className="rn-progress">
            <div className="rn-progress__meta"><strong>Importando projetos</strong><span>{progress}%</span></div>
            <progress max="100" value={progress}>Importando projetos: {progress}%</progress>
          </div>
          <button className="hub-mini-action" type="button" onClick={() => setProgress((value) => value >= 100 ? 24 : Math.min(100, value + 16))}>
            Avançar demonstração
          </button>
        </div>
      </article>

      <article className="hub-demo-card hub-demo-card--identity">
        <header><span>IDENTITY</span><strong>Avatar</strong><StatusBadge status="stable" /></header>
        <div className="hub-demo-card__body hub-avatar-row">
          <span className="rn-avatar" aria-label="Ruben Nascimento">RN</span>
          <span><strong>Ruben Nascimento</strong><small>Administrador</small></span>
        </div>
      </article>
    </div>
  );
}

function AdvancedReferences() {
  const [projectId, setProjectId] = useState<string | null>("aurora");
  const projects = [
    { id: "produto", label: "Produto RN", keywords: ["PR-104"] },
    { id: "aurora", label: "Projeto Aurora", keywords: ["PR-128"] },
    { id: "atlas", label: "Proposta Atlas", keywords: ["PR-133"] },
  ];
  const chartSeries = [{ id: "completed", label: "Concluídos" }];
  const chartData = [
    { label: "Jan", values: { completed: 8 } },
    { label: "Fev", values: { completed: 11 } },
    { label: "Mar", values: { completed: 10 } },
    { label: "Abr", values: { completed: 14 } },
    { label: "Mai", values: { completed: 13 } },
    { label: "Jun", values: { completed: 17 } },
  ];

  return (
    <div className="hub-advanced-grid">
      <article className="hub-reference-card">
        <header><span>FORMS / STABLE</span><strong>Combobox</strong><StatusBadge status="stable" /></header>
        <div className="hub-reference-card__stage">
          <RnCombobox
            label="Projeto"
            options={projects}
            value={projectId}
            onValueChange={(option) => setProjectId(option?.id ?? null)}
            description="Busque por nome ou código."
          />
        </div>
        <p>Implementação pública com listbox, setas, Home/End, Enter, Escape, seleção controlada e live status.</p>
      </article>

      <article className="hub-reference-card">
        <header><span>FORMS / STABLE</span><strong>Date & time</strong><StatusBadge status="stable" /></header>
        <div className="hub-reference-card__stage">
          <RnDateTimeField
            label="Data de entrega"
            defaultValue="2026-09-18"
            min="2026-08-26"
            description="Formato e picker nativos da plataforma."
          />
        </div>
        <p>Estratégia native-first: date, time e datetime-local preservam teclado, localização, min/max e validação.</p>
      </article>

      <article className="hub-reference-card hub-reference-card--chart">
        <header><span>DATA / STABLE</span><strong>Visualization</strong><StatusBadge status="stable" /></header>
        <RnBarChart
          title="Projetos concluídos"
          description="Jan–Jun 2026 · mensal"
          series={chartSeries}
          data={chartData}
        />
        <p>O plot é visual; uma tabela equivalente com todos os valores faz parte do mesmo componente.</p>
      </article>
    </div>
  );
}

function ComponentsSection() {
  const [mode, setMode] = useState<FilterValue<SystemMode>>("all");
  const [status, setStatus] = useState<FilterValue<SystemStatus>>("all");
  const filtered = systemRegistry.components.filter((component) => (
    (mode === "all" || component.modes.includes(mode))
      && (status === "all" || component.status === status)
  ));

  return (
    <section className="hub-section hub-section--soft" id="componentes" aria-labelledby="components-title">
      <SectionHeading
        id="components-title"
        eyebrow="04 — Componentes"
        title={<>Inventário visível, estados <span>sem ambiguidade.</span></>}
        description="Todos os contratos publicados têm implementação verificável. O Playground abaixo usa os mesmos exports React, classes e JSON que um agente recebe."
        actions={<a className="hub-text-link" href="/docs/COMPONENT-SPECS.md">Especificação completa <SystemIcon name="external" /></a>}
      />

      <ComponentPlayground />
      <LiveComponents />
      <AdvancedReferences />

      <div className="hub-catalog-toolbar" role="group" aria-label="Filtros do catálogo de componentes">
        <div role="group" aria-label="Filtrar por modo"><span>Modo</span>{modeOrder.map((value) => <FilterButton key={value} value={value} active={mode === value} onClick={setMode}>{value === "all" ? "Todos" : value === "product" ? "Product" : "Expressive"}</FilterButton>)}</div>
        <div role="group" aria-label="Filtrar por status"><span>Status</span>{statusOrder.map((value) => <FilterButton key={value} value={value} active={status === value} onClick={setStatus}>{value === "all" ? "Todos" : statusLabels[value]}</FilterButton>)}</div>
        <p><strong>{filtered.length}</strong> de {systemRegistry.components.length} componentes</p>
      </div>

      <div className="hub-component-catalog">
        {systemRegistry.components.map((component) => {
          const isFiltered = !filtered.some((entry) => entry.id === component.id);
          return (
          <article className="hub-component-entry" data-filtered={isFiltered || undefined} id={`component-${component.id}`} key={component.id}>
            <header><span>{component.family}</span><StatusBadge status={component.status} /></header>
            <h3>{component.name}</h3>
            <p>{component.requiredStates.length} estados obrigatórios</p>
            <div className="hub-state-tags">{component.requiredStates.slice(0, 6).map((state) => <span key={state}>{state}</span>)}</div>
            <footer>
              <span>{component.modes.join(" + ")}</span>
              <a href={`/${component.docs}`}>Contrato <SystemIcon name="arrow" /></a>
            </footer>
          </article>
          );
        })}
      </div>
    </section>
  );
}

function FeedbackPreview({ state }: { state: FeedbackState }) {
  if (state === "loading") {
    return (
      <div className="hub-feedback-preview__loading">
        <div className="hub-skeleton-group" role="status" aria-label="Carregando lista de projetos">
          <span className="rn-skeleton" /><span className="rn-skeleton" /><span className="rn-skeleton" />
        </div>
        <RnBrandLoader announce={false} label="" size="sm" />
      </div>
    );
  }
  if (state === "empty") {
    return <div className="rn-empty-state"><div className="rn-empty-state__inner"><strong>Nenhum projeto ainda</strong><p>Crie o primeiro para acompanhar prazos e responsáveis.</p><button className="rn-button rn-button--secondary rn-button--inline" type="button">Criar projeto</button></div></div>;
  }
  if (state === "error") {
    return <div className="rn-alert rn-alert--danger" role="alert"><SystemIcon name="x" /><div><strong className="rn-alert__title">Não foi possível carregar os projetos</strong><p>Verifique sua conexão e tente novamente.</p></div><button className="rn-button rn-button--danger rn-button--inline" type="button">Tentar novamente</button></div>;
  }
  if (state === "success") {
    return <div className="rn-alert rn-alert--success" role="status"><SystemIcon name="check" /><div><strong className="rn-alert__title">Projeto criado</strong><p>Agora você pode convidar a equipe e definir o primeiro prazo.</p></div></div>;
  }
  return <div className="hub-permission-state"><SystemIcon name="shield" /><div><strong>Você não pode editar este projeto</strong><p>Solicite a um administrador a permissão de edição.</p></div><button className="rn-button rn-button--secondary rn-button--inline" type="button">Solicitar acesso</button></div>;
}

function StatesSection() {
  const [state, setState] = useState<FeedbackState>("loading");
  return (
    <section className="hub-section" id="estados" aria-labelledby="states-title">
      <SectionHeading
        id="states-title"
        eyebrow="05 — Estados e feedback"
        title={<>Nenhuma tela fica <span>sem resposta.</span></>}
        description="Loading, empty, error, success e permission fazem parte da definição da tela. O estado não pode depender apenas de cor, motion ou toast."
      />

      <div className="hub-state-layout">
        <div className="hub-state-selector" role="group" aria-label="Selecionar estado demonstrado">
          {Object.entries(feedbackLabels).map(([value, label]) => (
            <button type="button" aria-pressed={state === value} onClick={() => setState(value as FeedbackState)} key={value}>
              <span>{label}</span><SystemIcon name="arrow" />
            </button>
          ))}
        </div>
        <div className="hub-feedback-preview" aria-live="polite">
          <header><span>PREVIEW / {feedbackLabels[state].toUpperCase()}</span><small>Estado oficial</small></header>
          <div><FeedbackPreview state={state} /></div>
        </div>
      </div>

      <ol className="hub-stepper-demo rn-stepper" style={{ "--rn-step-count": 4 } as CSSProperties}>
        <li className="rn-stepper__item" data-state="complete"><span className="rn-stepper__index"><SystemIcon name="check" /></span><span>Dados essenciais</span></li>
        <li className="rn-stepper__item" data-state="current" aria-current="step"><span className="rn-stepper__index">2</span><span>Configuração</span></li>
        <li className="rn-stepper__item" data-state="upcoming"><span className="rn-stepper__index">3</span><span>Permissões</span></li>
        <li className="rn-stepper__item" data-state="upcoming"><span className="rn-stepper__index">4</span><span>Revisão</span></li>
      </ol>
    </section>
  );
}

function MotionStage({ paused, recipe, reduced, replayKey, speed, stageRef }: {
  paused: boolean;
  recipe: RegistryMotion;
  reduced: boolean;
  replayKey: number;
  speed: MotionSpeed;
  stageRef?: Ref<HTMLDivElement>;
}) {
  const content = (() => {
    if (recipe.id === "press") return <button className="rn-button rn-button--inline hub-motion-press" type="button">Pressione para confirmar</button>;
    if (recipe.id === "selection") return <div className="hub-motion-selection"><span>Visão geral</span><span data-active="true">Atividade</span><span>Arquivos</span></div>;
    if (recipe.id === "state") return <div className="hub-motion-state"><SystemIcon name="check" /><span><strong>Alterações salvas</strong><small>O estado semântico já está correto.</small></span></div>;
    if (recipe.id === "overlay") return <div className="hub-motion-overlay"><i /><div><span>CONFIRMAR AÇÃO</span><strong>Publicar esta versão?</strong><p>Você poderá criar uma nova versão depois.</p><button type="button">Publicar</button></div></div>;
    if (recipe.id === "toast") return <div className="hub-motion-toast"><SystemIcon name="check" /><span><strong>Projeto atualizado</strong><small>As mudanças já estão disponíveis.</small></span></div>;
    if (recipe.id === "layout") return <div className="hub-motion-layout"><span><i />Pesquisa</span><span><i />Prototipação</span><span><i />Desenvolvimento</span></div>;
    if (recipe.id === "wordmark-rise") return <Wordmark replayKey={replayKey} size="panel" />;
    return <RnBrandLoader announce={false} label="" paused={paused || reduced} size="lg" variant="radial" />;
  })();

  return (
    <div
      ref={stageRef}
      className="hub-motion-stage"
      data-motion={recipe.id}
      data-paused={paused}
      data-reduced={reduced}
      data-speed={speed}
      key={`${recipe.id}-${replayKey}`}
    >
      <div className="hub-motion-stage__grid" aria-hidden="true" />
      <div className="hub-motion-stage__content">{content}</div>
      <span className="hub-motion-stage__caption">
        {recipe.id === "wordmark-rise" ? "01 LETRAS → 02 SÍMBOLO → 03 LOCKUP" : `${recipe.name} · ${recipe.durationToken}`}
      </span>
    </div>
  );
}

function MotionSection() {
  const systemReduced = useReducedMotion();
  const stageRef = useRef<HTMLDivElement>(null);
  const [manualReduced, setManualReduced] = useState(false);
  const [paused, setPaused] = useState(false);
  const [replayKey, setReplayKey] = useState(0);
  const [selectedId, setSelectedId] = useState("wordmark-rise");
  const [speed, setSpeed] = useState<MotionSpeed>("normal");
  const [scrub, setScrub] = useState(0);
  const [scrubbing, setScrubbing] = useState(false);
  const [compareReduced, setCompareReduced] = useState(false);
  const [copyStatus, setCopyStatus] = useState("");
  const reduced = Boolean(systemReduced || manualReduced);
  const selected = systemRegistry.motion.find((recipe) => recipe.id === selectedId) ?? systemRegistry.motion[0];

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      const animations = stageRef.current?.getAnimations({ subtree: true }) ?? [];
      for (const animation of animations) {
        if (scrubbing) {
          const duration = animation.effect?.getTiming().duration;
          animation.pause();
          if (typeof duration === "number" && Number.isFinite(duration)) {
            animation.currentTime = duration * (Math.min(scrub, 99.9) / 100);
          }
        } else if (paused || reduced) {
          animation.pause();
        } else {
          animation.play();
        }
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, [paused, reduced, replayKey, scrub, scrubbing, selected.id, speed]);

  const replay = () => {
    setPaused(false);
    setScrubbing(false);
    setScrub(0);
    setReplayKey((value) => value + 1);
  };

  const copyMotion = async (format: "css" | "json") => {
    const value = format === "json"
      ? JSON.stringify(selected, null, 2)
      : `animation-duration: var(${selected.durationToken});\nanimation-timing-function: var(${selected.easingToken});\n/* ${selected.properties.join(", ")} */`;
    try {
      await navigator.clipboard.writeText(value);
      setCopyStatus(`${format.toUpperCase()} de ${selected.name} copiado.`);
    } catch {
      setCopyStatus("Não foi possível acessar a área de transferência.");
    }
  };

  return (
    <section className="hub-section hub-section--ink" id="movimento" aria-labelledby="motion-title">
      <SectionHeading
        id="motion-title"
        eyebrow="06 — Motion"
        title={<>Movimento que explica <span>causa e efeito.</span></>}
        description="Uma receita por intenção. As animações são interrompíveis, usam transform/opacity e chegam ao estado final sem depender de animationend."
        actions={<a className="hub-text-link" href="/animacoes">Abrir wordmark oficial <SystemIcon name="external" /></a>}
      />

      <div className="hub-motion-workbench" data-selected={selected.id}>
        <div className="hub-motion-browser">
          <header><span>RECEITAS OFICIAIS</span><small>{systemRegistry.motion.length} padrões</small></header>
          <div>
            {systemRegistry.motion.map((recipe) => (
              <button type="button" aria-pressed={selected.id === recipe.id} onClick={() => { setSelectedId(recipe.id); setCopyStatus(""); replay(); }} id={`motion-${recipe.id}`} key={recipe.id}>
                <span><i data-tier={recipe.tier} />{recipe.name}<small>{recipe.tier}</small></span>
                <StatusBadge status={recipe.status} />
              </button>
            ))}
          </div>
        </div>

        <div className="hub-motion-player">
          <div className="hub-motion-controls" role="group" aria-label="Controles da demonstração de motion">
            <button type="button" onClick={replay}><SystemIcon name="replay" /> Replay</button>
            <button type="button" aria-pressed={paused} onClick={() => { setScrubbing(false); setPaused((value) => !value); }}><SystemIcon name={paused ? "play" : "pause"} /> {paused ? "Retomar" : "Pausar"}</button>
            <div className="hub-speed-control" role="group" aria-label="Velocidade da animação">
              {(["slow", "normal", "fast"] as MotionSpeed[]).map((value) => <button type="button" aria-pressed={speed === value} onClick={() => setSpeed(value)} key={value}>{value === "slow" ? "0,5×" : value === "normal" ? "1×" : "2×"}</button>)}
            </div>
            <button type="button" aria-pressed={manualReduced || Boolean(systemReduced)} disabled={Boolean(systemReduced)} onClick={() => setManualReduced((value) => !value)}><SystemIcon name="shield" /> Reduced</button>
            <button type="button" aria-pressed={compareReduced} onClick={() => setCompareReduced((value) => !value)}>Comparar</button>
            <button type="button" onClick={() => copyMotion("css")}><SystemIcon name="code" /> CSS</button>
            <button type="button" onClick={() => copyMotion("json")}><SystemIcon name="agent" /> JSON</button>
          </div>
          <div className="hub-motion-timeline">
            <label htmlFor="motion-scrubber"><span>Timeline</span><output>{scrubbing ? `${scrub}%` : "live"}</output></label>
            <input
              id="motion-scrubber"
              type="range"
              min="0"
              max="100"
              value={scrub}
              onChange={(event) => { setScrubbing(true); setPaused(true); setScrub(Number(event.target.value)); }}
            />
            <div aria-hidden="true">
              {(selected.sequence ?? selected.properties).map((step, index, collection) => <span style={{ "--hub-timeline-position": `${collection.length <= 1 ? 0 : (index / (collection.length - 1)) * 100}%` } as CSSProperties} key={step}>{String(index + 1).padStart(2, "0")}</span>)}
            </div>
          </div>
          <div className="hub-motion-comparison" data-compare={compareReduced}>
            <div><span>Motion padrão</span><MotionStage stageRef={stageRef} paused={paused || scrubbing} recipe={selected} reduced={reduced} replayKey={replayKey} speed={speed} /></div>
            {compareReduced ? <div><span>Reduced motion</span><MotionStage paused recipe={selected} reduced replayKey={replayKey} speed={speed} /></div> : null}
          </div>
          <p className="hub-motion-copy-status" aria-live="polite">{copyStatus || "Use CSS ou JSON para copiar a receita selecionada."}</p>
          <div className="hub-motion-spec">
            <div><span>USO</span><p>{selected.use}</p></div>
            <div><span>EVITE</span><p>{selected.avoid}</p></div>
            <div><span>REDUCED MOTION</span><p>{selected.reducedMotion}</p></div>
            <div><span>TOKENS</span><code>{selected.durationToken}<br />{selected.easingToken}</code></div>
            {selected.sequence ? (
              <div className="hub-motion-spec__sequence">
                <span>SEQUÊNCIA OFICIAL</span>
                <ol>{selected.sequence.map((step) => <li key={step}>{step}</li>)}</ol>
                {selected.replayPolicy ? <small>{selected.replayPolicy}</small> : null}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}

type LoaderSize = "sm" | "md" | "lg" | "xl";

function LoadingSection() {
  const [paused, setPaused] = useState(false);
  const [replayKey, setReplayKey] = useState(0);
  const [size, setSize] = useState<LoaderSize>("xl");
  return (
    <section className="hub-section" id="carregamento" aria-labelledby="loading-title">
      <SectionHeading
        id="loading-title"
        eyebrow="07 — Loading"
        title={<>Uma assinatura oficial: <span>Montagem com impacto.</span></>}
        description="A variação 01 é o loader público. As outras nove permanecem no laboratório como estudos experimentais, fora da decisão automática dos agentes."
        actions={<StatusBadge status="stable" />}
      />

      <div className="hub-loading-layout">
        <article className="hub-loading-stage">
          <header>
            <span><i aria-hidden="true" /> OFICIAL · 01</span>
            <div role="group" aria-label="Controles do loader oficial">
              {systemRegistry.loading.official.sizes.map((value) => <button type="button" aria-pressed={size === value} onClick={() => setSize(value)} key={value}>{value.toUpperCase()}</button>)}
              <button type="button" aria-label={paused ? "Retomar loader" : "Pausar loader"} aria-pressed={paused} onClick={() => setPaused((value) => !value)}><SystemIcon name={paused ? "play" : "pause"} /></button>
              <button type="button" aria-label="Reproduzir loader novamente" onClick={() => { setPaused(false); setReplayKey((value) => value + 1); }}><SystemIcon name="replay" /></button>
            </div>
          </header>
          <div key={replayKey}><RnBrandLoader label="Carregando projetos" paused={paused} size={size} variant="radial" /></div>
          <footer>
            <strong>Montagem com impacto</strong>
            <span>9 paths oficiais · escala de destaque XL · transform + opacity · reduced motion</span>
          </footer>
        </article>

        <div className="hub-loading-rules">
          {systemRegistry.loading.decision.map((item, index) => (
            <article key={item.condition}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <div><strong>{item.pattern}</strong><p>{item.condition}</p><small>{item.example}</small></div>
            </article>
          ))}
          <a href={systemRegistry.loading.experimentalLab}>Abrir laboratório experimental <SystemIcon name="external" /></a>
        </div>
      </div>
    </section>
  );
}

function IconsSection() {
  return (
    <section className="hub-section hub-section--soft" id="icones" aria-labelledby="icons-title">
      <SectionHeading
        id="icons-title"
        eyebrow="08 — Ícones"
        title={<>Marca e função têm <span>papéis diferentes.</span></>}
        description="O símbolo RN identifica a marca. Phosphor Outline comunica ações. Misturar os dois papéis enfraquece semântica e consistência."
      />

      <div className="hub-icon-layout">
        <article className="hub-brand-icon-card">
          <span>SÍMBOLO DE MARCA</span>
          <img src="/assets/brand/rn-icon.svg" alt="Símbolo RN Design" width="384" height="384" loading="lazy" decoding="async" />
          <strong>Não é um ícone de interface.</strong>
          <p>Use em favicon, app icon, transições e composição de fundo.</p>
        </article>
        <article className="hub-interface-icons">
          <header><span>INTERFACE · {systemRegistry.icons.interfaceFamily}</span><small>peso regular</small></header>
          <div>
            {iconExamples.map((icon) => (
              <span key={icon.name}><SystemIcon name={icon.name} /><strong>{icon.label}</strong><small>{icon.use}</small></span>
            ))}
          </div>
          <footer>
            {systemRegistry.icons.sizes.map((size) => <span key={size}><SystemIcon name="spark" style={{ width: size, height: size }} /><small>{size}px</small></span>)}
          </footer>
        </article>
      </div>

      <div className="hub-rule-strip">
        {systemRegistry.icons.rules.map((rule) => <span key={rule}><SystemIcon name="check" />{rule}</span>)}
      </div>
    </section>
  );
}

function PatternSection() {
  return (
    <section className="hub-section hub-section--ink" id="padroes" aria-labelledby="patterns-title">
      <SectionHeading
        id="patterns-title"
        eyebrow="09 — Padrões de experiência"
        title={<>Componentes viram <span>fluxos completos.</span></>}
        description="O agente começa pelo padrão de tela mais próximo, preserva a hierarquia e substitui conteúdo e semântica — não reinventa o shell."
      />

      <div className="hub-pattern-grid">
        <article>
          <span>PRODUCT FLOW</span>
          <h3>Operação recorrente</h3>
          <ol><li>Shell</li><li>Page header</li><li>Filtros</li><li>Conteúdo</li><li>Feedback</li></ol>
          <p>Canvas branco, dados planos, uma ação primária e recuperação explícita.</p>
        </article>
        <article>
          <span>EXPRESSIVE FLOW</span>
          <h3>Narrativa de marca</h3>
          <ol><li>Hook</li><li>Contexto</li><li>Solução</li><li>Evidência</li><li>Decisão</li></ol>
          <p>Hero branco, capítulos prescritos, um ponto focal e motion com propósito.</p>
        </article>
      </div>

      <div className="hub-pattern-state-map">
        {[
          ["Loading", "Algo está acontecendo"],
          ["Empty", "Ainda não existe conteúdo"],
          ["No results", "Os filtros não encontraram itens"],
          ["Permission", "O usuário não pode acessar"],
          ["Error", "A ação falhou e precisa de recuperação"],
          ["Success", "A ação terminou e o próximo passo está claro"],
        ].map(([name, description], index) => <article key={name}><span>{String(index + 1).padStart(2, "0")}</span><strong>{name}</strong><p>{description}</p></article>)}
      </div>
    </section>
  );
}

function TemplatePreview({ template }: { template: RegistryTemplate }) {
  if (template.id === "auth") {
    return <div className="hub-mini-auth"><img src="/assets/brand/rn-icon.svg" alt="" width="384" height="384" loading="lazy" decoding="async" /><span /><span /><span className="hub-mini-button">Entrar</span></div>;
  }
  if (template.id === "dashboard") {
    return <div className="hub-mini-dashboard"><aside /><main><header /><div><span /><span /><span /></div><article><i /><i /><i /><i /></article></main></div>;
  }
  if (template.id === "expressive") {
    return <div className="hub-mini-expressive"><Wordmark animated={false} size="compact" /><strong>Transforme a ideia em <i>produto.</i></strong><span /></div>;
  }
  if (template.id === "entity-form") {
    return <div className="hub-mini-form"><span /><label><i /></label><label><i /></label><label><i /></label><footer><span className="hub-mini-button" /><span className="hub-mini-button" /></footer></div>;
  }
  if (template.id === "management-list") {
    return <div className="hub-mini-list"><header><span /><span className="hub-mini-button" /></header><i /><ul><li /><li /><li /><li /></ul></div>;
  }
  if (template.id === "system-feedback") {
    return <div className="hub-mini-feedback"><SystemIcon name="shield" /><strong>404</strong><span /><span className="hub-mini-button" /></div>;
  }
  return <div className="hub-mini-shell"><aside /><main><header /><span /><article /><article /></main></div>;
}

function TemplatesSection() {
  const [mode, setMode] = useState<FilterValue<SystemMode>>("all");
  const [viewport, setViewport] = useState<PreviewViewport>("desktop");
  const templates = systemRegistry.templates.filter((template) => mode === "all" || template.mode === mode);
  return (
    <section className="hub-section" id="templates" aria-labelledby="templates-title">
      <SectionHeading
        id="templates-title"
        eyebrow="10 — Templates"
        title={<>Páginas completas para <span>começar certo.</span></>}
        description="Templates mostram composição, responsive e estados esperados. Eles orientam o agente além do componente isolado."
        actions={
          <div className="hub-viewport-control" role="group" aria-label="Viewport dos templates">
            {(["desktop", "tablet", "mobile"] as PreviewViewport[]).map((value) => <button type="button" aria-label={`Viewport ${value}`} aria-pressed={viewport === value} onClick={() => setViewport(value)} key={value}><SystemIcon name={value === "desktop" ? "monitor" : value === "tablet" ? "tablet" : "phone"} /><span>{value}</span></button>)}
          </div>
        }
      />

      <div className="hub-template-toolbar">
        {modeOrder.map((value) => <FilterButton key={value} value={value} active={mode === value} onClick={setMode}>{value === "all" ? "Todos" : value === "product" ? "Product" : "Expressive"}</FilterButton>)}
      </div>
      <div className="hub-template-grid" data-viewport={viewport}>
        {systemRegistry.templates.map((template) => {
          const isFiltered = !templates.some((entry) => entry.id === template.id);
          return (
          <article className="hub-template-card" data-filtered={isFiltered || undefined} data-template={template.id} id={`template-${template.id}`} key={template.id}>
            <div className="hub-template-card__preview" aria-hidden="true"><div><TemplatePreview template={template} /></div></div>
            <div className="hub-template-card__body">
              <header><span>{template.mode}</span><StatusBadge status={template.status} /></header>
              <h3>{template.name}</h3>
              <div className="hub-state-tags">{template.states.slice(0, 5).map((state) => <span key={state}>{state}</span>)}</div>
              <a href={`/${template.starter}`}>Abrir referência <SystemIcon name="arrow" /></a>
            </div>
          </article>
          );
        })}
      </div>
    </section>
  );
}

function ContentSection() {
  return (
    <section className="hub-section hub-section--soft" id="conteudo" aria-labelledby="content-title">
      <SectionHeading
        id="content-title"
        eyebrow="11 — Conteúdo e acessibilidade"
        title={<>Clareza também é um <span>componente.</span></>}
        description="A voz RN explica resultado, contexto e recuperação. WCAG 2.2 AA, teclado, foco e reduced motion são parte do contrato."
      />

      <div className="hub-content-grid">
        <article className="hub-copy-board">
          <header><span>MICROCOPY</span><strong>Resultado → contexto → tecnologia</strong></header>
          {copyExamples.map((example) => (
            <div key={example.label}>
              <span>{example.label}</span>
              <p data-kind="do"><SystemIcon name="check" />{example.do}</p>
              <p data-kind="avoid"><SystemIcon name="x" />{example.avoid}</p>
            </div>
          ))}
        </article>

        <article className="hub-a11y-board">
          <header><span>ACCESSIBILITY</span><strong>WCAG 2.2 AA</strong></header>
          <div>{qualityPairs.map(([pair, ratio, level]) => <p key={pair}><span>{pair}</span><strong>{ratio}</strong><i>{level}</i></p>)}</div>
          <ul>
            {[
              "Teclado completo e foco visível",
              "Zoom 200% e reflow",
              "Touch target mínimo de 44×44px",
              "Estado nunca depende apenas de cor",
              "Conteúdo final visível em reduced motion",
            ].map((item) => <li key={item}><SystemIcon name="check" />{item}</li>)}
          </ul>
        </article>
      </div>
    </section>
  );
}

function ImplementationSection({ copyValue }: { copyValue: (id: string, value: string) => void }) {
  const [copied, setCopied] = useState("");
  const copy = (id: string, value: string) => {
    copyValue(id, value);
    setCopied(id);
    window.setTimeout(() => setCopied(""), 1400);
  };

  return (
    <section className="hub-section" id="implementacao" aria-labelledby="implementation-title">
      <SectionHeading
        id="implementation-title"
        eyebrow="12 — Implementação"
        title={<>O mesmo núcleo em <span>qualquer frontend web.</span></>}
        description="React é referência, não requisito. Tokens, CSS, assets, contratos e exemplos permanecem estáveis para o agente adaptar à stack encontrada."
      />

      <div className="hub-code-layout">
        <article className="hub-code-card">
          <header><span>CSS / ENTRY</span><CopyButton copied={copied === "imports"} label="imports CSS" onCopy={() => copy("imports", importSnippet)} /></header>
          <pre tabIndex={0} aria-label="Imports CSS do RN Design System"><code>{importSnippet}</code></pre>
        </article>
        <article className="hub-code-card">
          <header><span>HTML / BUTTON</span><CopyButton copied={copied === "button"} label="exemplo de Button" onCopy={() => copy("button", componentSnippet)} /></header>
          <pre tabIndex={0} aria-label="Exemplo de botão RN"><code>{componentSnippet}</code></pre>
        </article>
      </div>

      <div className="hub-format-links">
        <a href="/tokens/rn.css"><span>CSS</span><strong>Custom properties</strong><code>tokens/rn.css</code></a>
        <a href="/tokens/rn.tokens.json"><span>JSON</span><strong>DTCG tokens</strong><code>rn.tokens.json</code></a>
        <a href="/tokens/rn.js"><span>JS</span><strong>Runtime safe</strong><code>tokens/rn.js</code></a>
        <a href="/tokens/rn.ts"><span>TS</span><strong>Typed const</strong><code>tokens/rn.ts</code></a>
        <a href="/agent/index.json"><span>AGENT</span><strong>Machine index</strong><code>agent/index.json</code></a>
      </div>
    </section>
  );
}

function AgentsSection() {
  const [workflow, setWorkflow] = useState<"create" | "refactor">("create");
  const selected = systemRegistry.playbooks[workflow];
  return (
    <section className="hub-section hub-section--agent" id="agentes" aria-labelledby="agents-title">
      <SectionHeading
        id="agents-title"
        eyebrow="14 — Guia para agentes"
        title={<>Menos interpretação. <span>Mais consistência.</span></>}
        description="O agente recebe uma ordem de leitura, dois fluxos de trabalho, decisões proibidas e um contrato de entrega verificável."
        actions={<a className="hub-text-link" href="/agent/index.json">Abrir índice estruturado <SystemIcon name="external" /></a>}
      />

      <div className="hub-agent-layout">
        <div className="hub-agent-workflow">
          <div className="hub-agent-tabs" role="group" aria-label="Escolher playbook">
            <button type="button" aria-pressed={workflow === "create"} onClick={() => setWorkflow("create")}><SystemIcon name="spark" /> Criar frontend</button>
            <button type="button" aria-pressed={workflow === "refactor"} onClick={() => setWorkflow("refactor")}><SystemIcon name="layers" /> Refatorar frontend</button>
          </div>
          <ol>
            {selected.steps.map((step, index) => <li key={step}><span>{String(index + 1).padStart(2, "0")}</span><p>{step}</p></li>)}
          </ol>
          <a href={`/${selected.path}`}>Abrir playbook completo <SystemIcon name="arrow" /></a>
        </div>

        <div className="hub-agent-contract">
          <header><SystemIcon name="agent" /><span><strong>RN AGENT CONTRACT</strong><small>Saída obrigatória</small></span></header>
          <ul>{systemRegistry.deliveryContract.map((item) => <li key={item}><SystemIcon name="check" />{item}</li>)}</ul>
          <div>
            <a href="/starters/AGENT-BRIEF.md">Brief <SystemIcon name="docs" /></a>
            <a href="/agent/validate.md">Validação <SystemIcon name="shield" /></a>
            <a href="/AGENTS.md">Contrato raiz <SystemIcon name="external" /></a>
          </div>
        </div>
      </div>

      <article className="hub-prohibited">
        <header><span>DECISÕES PROIBIDAS</span><strong>O agente não improvisa estes pontos.</strong></header>
        <div>{systemRegistry.prohibited.map((rule) => <span key={rule}><SystemIcon name="x" />{rule}</span>)}</div>
      </article>
    </section>
  );
}

function QualitySection() {
  return (
    <section className="hub-section hub-section--soft" id="qualidade" aria-labelledby="quality-title">
      <SectionHeading
        id="quality-title"
        eyebrow="15 — Qualidade"
        title={<>A conformidade precisa ser <span>provada.</span></>}
        description="Os gates validam tokens, contratos, contraste, tipos, build e artefato. A revisão manual cobre o que só aparece na composição real."
      />

      <div className="hub-quality-summary">
        <article><span>ÍNDICE</span><strong>100%</strong><p>JSON válido e fonte estruturada</p></article>
        <article><span>VIEWPORTS</span><strong>04</strong><p>375 · 768 · 1024 · 1440</p></article>
        <article><span>ACCESSIBILITY</span><strong>AA</strong><p>WCAG 2.2 como baseline</p></article>
        <article><span>LOADER</span><strong>01</strong><p>Uma decisão pública oficial</p></article>
      </div>

      <div className="hub-quality-layout">
        <article className="hub-command-list">
          <header><SystemIcon name="code" /><span><strong>Gates automáticos</strong><small>Execute na ordem</small></span></header>
          <ol>{systemRegistry.quality.commands.map((command, index) => <li key={command}><span>{String(index + 1).padStart(2, "0")}</span><code>{command}</code></li>)}</ol>
        </article>
        <article className="hub-manual-list">
          <header><SystemIcon name="shield" /><span><strong>Matriz manual</strong><small>Composição real</small></span></header>
          <div>{systemRegistry.quality.manualChecks.map((check) => <span key={check}><SystemIcon name="check" />{check}</span>)}</div>
          <a href="/docs/ACCESSIBILITY.md">Abrir checklist de acessibilidade <SystemIcon name="arrow" /></a>
        </article>
      </div>
    </section>
  );
}

export function SystemDesignPage() {
  const activeSection = useActiveSection();
  const [heroReplay, setHeroReplay] = useState(0);

  const copyValue = async (_id: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      // Clipboard can be unavailable in non-secure local previews; the UI remains usable.
    }
  };

  const stableCount = systemRegistry.components.filter((component) => component.status === "stable").length;

  return (
    <div className="hub-page">
      <a className="rn-skip-link" href="#main-content">Pular para o conteúdo</a>
      <ScrollProgress />
      <Topbar />
      <Sidebar activeSection={activeSection} />

      <main className="hub-main" id="main-content">
        <section className="hub-hero rn-brand-canvas rn-brand-canvas--editorial" id="inicio" aria-labelledby="hub-title">
          <div className="hub-hero__topline">
            <span><i aria-hidden="true" /> Fonte oficial · Humano + agente</span>
            <button type="button" onClick={() => setHeroReplay((value) => value + 1)}><SystemIcon name="replay" /> Reproduzir marca</button>
          </div>
          <Wordmark replayKey={heroReplay} size="hero" timing="overlap" />
          <div className="hub-hero__content">
            <div>
              <h1 id="hub-title">
                A fonte de verdade da RN, <span>visível e executável.</span>
              </h1>
              <p>Um painel para pessoas entenderem a marca e um contrato estruturado para agentes criarem e refatorarem frontends sem improvisar.</p>
              <div className="hub-hero__actions">
                <a className="rn-button rn-button--pill rn-button--inline" href="#componentes">Explorar componentes <SystemIcon name="arrow" /></a>
                <a className="rn-button rn-button--secondary rn-button--pill rn-button--inline" href="/agent/index.json">Abrir índice para IA</a>
              </div>
            </div>
            <aside>
              <span>AGENT READY</span>
              <strong>Uma decisão oficial por contexto.</strong>
              <p>Master → override → índice → tokens → componentes → validação.</p>
              <div><SystemIcon name="agent" /><span><strong>{systemRegistry.meta.platforms.join(" · ")}</strong><small>Escopo declarado</small></span></div>
            </aside>
          </div>
          <div className="hub-hero__metrics">
            <span><strong>{systemRegistry.components.length}</strong> componentes catalogados</span>
            <span><strong>{stableCount}</strong> contratos estáveis</span>
            <span><strong>{systemRegistry.motion.length}</strong> receitas de motion</span>
            <span><strong>{systemRegistry.templates.length}</strong> templates e patterns</span>
          </div>
        </section>

        <BrandSection copyValue={copyValue} />
        <FoundationsSection />
        <TokensSection copyValue={copyValue} />
        <ComponentsSection />
        <StatesSection />
        <MotionSection />
        <LoadingSection />
        <IconsSection />
        <PatternSection />
        <TemplatesSection />
        <ContentSection />
        <ImplementationSection copyValue={copyValue} />
        <ArtDirectionPanel />
        <AgentsSection />
        <QualitySection />

        <footer className="hub-footer rn-brand-canvas rn-brand-canvas--quiet">
          <img src="/assets/brand/rn-logo.png" alt="RN Design & Serviços" width="821" height="400" loading="lazy" decoding="async" />
          <div><strong>Uma linguagem. Uma fonte de verdade.</strong><p>Design, desenvolvimento e IA trabalhando com as mesmas decisões.</p></div>
          <a className="rn-button rn-button--pill rn-button--inline" href="#inicio">Voltar ao início</a>
        </footer>
      </main>
    </div>
  );
}
