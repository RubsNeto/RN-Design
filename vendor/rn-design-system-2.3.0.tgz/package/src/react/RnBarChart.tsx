import { useId, type CSSProperties, type HTMLAttributes, type ReactNode } from "react";
import { cx } from "./cx";

export interface RnChartSeries {
  id: string;
  label: string;
}

export interface RnChartDatum {
  label: string;
  values: Readonly<Record<string, number>>;
}

export type RnChartState = "loading" | "ready" | "empty" | "error" | "partial" | "no-permission";

export interface RnBarChartProps extends Omit<HTMLAttributes<HTMLElement>, "title"> {
  title: string;
  description?: string;
  series: readonly RnChartSeries[];
  data: readonly RnChartDatum[];
  max?: number;
  state?: RnChartState;
  stateMessage?: string;
  stateAction?: ReactNode;
  showTable?: boolean;
  valueFormatter?: (value: number) => string;
}

type ChartBarStyle = CSSProperties & { "--rn-chart-value": number };

export function RnBarChart({
  title,
  description,
  series,
  data,
  max,
  state,
  stateMessage,
  stateAction,
  showTable = false,
  valueFormatter = (value) => new Intl.NumberFormat("pt-BR").format(value),
  className,
  ...props
}: RnBarChartProps) {
  const titleId = useId();
  const dataMax = Math.max(1, ...data.flatMap((datum) => series.map((item) => datum.values[item.id] ?? 0)));
  const computedMax = Math.max(1, max ?? dataMax);
  const availableSeries = series.slice(0, 5);
  const effectiveState = state ?? (data.length > 0 ? "ready" : "empty");
  const stateCopy: Record<Exclude<RnChartState, "ready" | "partial">, { title: string; message: string }> = {
    loading: { title: "Carregando dados", message: "A visualização será exibida assim que os dados estiverem disponíveis." },
    empty: { title: "Nenhum dado disponível", message: "Ajuste o período ou os filtros para consultar outras informações." },
    error: { title: "Não foi possível carregar o gráfico", message: "Tente novamente ou consulte os dados em outra fonte." },
    "no-permission": { title: "Acesso restrito", message: "Você não possui permissão para visualizar estes dados." },
  };

  return (
    <section {...props} className={cx("rn-chart", className)} aria-labelledby={titleId}>
      <header className="rn-chart__header">
        <div>
          <h3 id={titleId}>{title}</h3>
          {description ? <p>{description}</p> : null}
        </div>
        <ul className="rn-chart__legend" aria-label="Legenda">
          {availableSeries.map((item, index) => (
            <li key={item.id} data-series={index + 1}><i aria-hidden="true" />{item.label}</li>
          ))}
        </ul>
      </header>

      {effectiveState !== "ready" && effectiveState !== "partial" ? (
        <div className="rn-chart__state" role={effectiveState === "error" ? "alert" : "status"} aria-busy={effectiveState === "loading" || undefined}>
          <strong>{stateCopy[effectiveState].title}</strong>
          <p>{stateMessage ?? stateCopy[effectiveState].message}</p>
          {stateAction}
        </div>
      ) : <div className="rn-chart__plot" aria-hidden="true">
        {data.map((datum) => (
          <div className="rn-chart__group" key={datum.label}>
            {availableSeries.map((item, index) => {
              const value = Math.max(0, datum.values[item.id] ?? 0);
              return (
                <i
                  key={item.id}
                  className="rn-chart__bar"
                  data-series={index + 1}
                  style={{ "--rn-chart-value": value / computedMax } as ChartBarStyle}
                  title={`${datum.label}, ${item.label}: ${valueFormatter(value)}`}
                />
              );
            })}
            <span>{datum.label}</span>
          </div>
        ))}
      </div>}

      {effectiveState === "partial" ? <p className="rn-chart__notice" role="status">{stateMessage ?? "Os dados exibidos são parciais."}</p> : null}

      {effectiveState === "ready" || effectiveState === "partial" ? <div className={showTable ? undefined : "rn-sr-only"}>
        <table className="rn-chart__table">
          <caption>{title}: dados completos</caption>
          <thead>
            <tr><th scope="col">Categoria</th>{availableSeries.map((item) => <th scope="col" key={item.id}>{item.label}</th>)}</tr>
          </thead>
          <tbody>
            {data.map((datum) => (
              <tr key={datum.label}>
                <th scope="row">{datum.label}</th>
                {availableSeries.map((item) => <td key={item.id}>{valueFormatter(datum.values[item.id] ?? 0)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div> : null}
    </section>
  );
}
