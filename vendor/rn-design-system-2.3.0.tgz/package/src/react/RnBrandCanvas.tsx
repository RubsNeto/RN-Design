import { forwardRef, type HTMLAttributes } from "react";
import { cx } from "./cx";

export type RnBrandCanvasDensity = "product" | "editorial";

export interface RnBrandCanvasProps extends HTMLAttributes<HTMLElement> {
  density?: RnBrandCanvasDensity;
  quiet?: boolean;
}

export const RnBrandCanvas = forwardRef<HTMLElement, RnBrandCanvasProps>(
  function RnBrandCanvas({ density = "product", quiet = false, className, children, ...props }, ref) {
    return (
      <section
        {...props}
        ref={ref}
        className={cx(
          "rn-brand-canvas",
          density === "editorial" && "rn-brand-canvas--editorial",
          quiet && "rn-brand-canvas--quiet",
          className,
        )}
      >
        {children}
      </section>
    );
  },
);
