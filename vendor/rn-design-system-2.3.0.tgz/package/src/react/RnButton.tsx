import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cx } from "./cx";

export type RnButtonVariant = "primary" | "accent" | "secondary" | "ghost" | "danger";
export type RnButtonSize = "sm" | "md" | "lg";

export interface RnButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: RnButtonVariant;
  size?: RnButtonSize;
  loading?: boolean;
  leadingIcon?: ReactNode;
  trailingIcon?: ReactNode;
}

export const RnButton = forwardRef<HTMLButtonElement, RnButtonProps>(
  function RnButton(
    {
      variant = "primary",
      size = "md",
      loading = false,
      leadingIcon,
      trailingIcon,
      className,
      disabled,
      children,
      type = "button",
      ...props
    },
    ref,
  ) {
    return (
      <button
        {...props}
        ref={ref}
        type={type}
        className={cx(
          "rn-button",
          variant !== "primary" && `rn-button--${variant}`,
          size !== "md" && `rn-button--${size}`,
          className,
        )}
        disabled={disabled || loading}
        aria-busy={loading || undefined}
      >
        {!loading && leadingIcon ? <span aria-hidden="true">{leadingIcon}</span> : null}
        <span>{children}</span>
        {!loading && trailingIcon ? <span aria-hidden="true">{trailingIcon}</span> : null}
      </button>
    );
  },
);
