import { forwardRef, type AnchorHTMLAttributes, type HTMLAttributes } from "react";
import { cx } from "./cx";

export type RnCardVariant = "base" | "soft" | "raised" | "glass" | "brand";

export interface RnCardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: RnCardVariant;
}

export const RnCard = forwardRef<HTMLDivElement, RnCardProps>(function RnCard(
  { variant = "base", className, ...props },
  ref,
) {
  return (
    <div
      {...props}
      ref={ref}
      className={cx(
        "rn-card",
        variant !== "base" && `rn-card--${variant}`,
        className,
      )}
    />
  );
});

export interface RnCardLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: RnCardVariant;
}

export const RnCardLink = forwardRef<HTMLAnchorElement, RnCardLinkProps>(
  function RnCardLink({ variant = "base", className, ...props }, ref) {
    return (
      <a
        {...props}
        ref={ref}
        className={cx(
          "rn-card rn-card--interactive",
          variant !== "base" && `rn-card--${variant}`,
          className,
        )}
      />
    );
  },
);
