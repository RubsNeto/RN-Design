import {
  forwardRef,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type FocusEvent,
  type InputHTMLAttributes,
  type KeyboardEvent,
} from "react";
import { cx } from "./cx";

export interface RnComboboxOption {
  id: string;
  label: string;
  keywords?: readonly string[];
  disabled?: boolean;
}

export interface RnComboboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "defaultValue" | "onChange"> {
  label: string;
  options: readonly RnComboboxOption[];
  value?: string | null;
  defaultValue?: string | null;
  onValueChange?: (option: RnComboboxOption | null) => void;
  description?: string;
  error?: string;
  loading?: boolean;
  loadingText?: string;
  noResultsText?: string;
}

export const RnCombobox = forwardRef<HTMLInputElement, RnComboboxProps>(function RnCombobox(
  {
    label,
    options,
    value,
    defaultValue = null,
    onValueChange,
    description,
    error,
    loading = false,
    loadingText = "Carregando opções…",
    noResultsText = "Nenhuma opção encontrada.",
    id: suppliedId,
    name,
    disabled,
    required,
    className,
    placeholder,
    ...props
  },
  forwardedRef,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-combobox-${generatedId}`;
  const listboxId = `${id}-listbox`;
  const descriptionId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [internalValue, setInternalValue] = useState<string | null>(defaultValue);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const selectedId = value === undefined ? internalValue : value;
  const selected = options.find((option) => option.id === selectedId) ?? null;

  useEffect(() => {
    if (!open) setQuery(selected?.label ?? "");
  }, [open, selected?.label]);

  const filteredOptions = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    if (!needle || selected?.label === query) return options;
    return options.filter((option) => [option.label, ...(option.keywords ?? [])].join(" ").toLocaleLowerCase().includes(needle));
  }, [options, query, selected?.label]);

  const enabledOptions = loading ? [] : filteredOptions.filter((option) => !option.disabled);
  const activeIndex = enabledOptions.findIndex((option) => option.id === activeId);

  const assignInputRef = (node: HTMLInputElement | null) => {
    inputRef.current = node;
    if (typeof forwardedRef === "function") forwardedRef(node);
    else if (forwardedRef) forwardedRef.current = node;
  };

  const choose = (option: RnComboboxOption | null) => {
    if (value === undefined) setInternalValue(option?.id ?? null);
    setQuery(option?.label ?? "");
    setOpen(false);
    setActiveId(option?.id ?? null);
    onValueChange?.(option);
  };

  const moveActive = (direction: 1 | -1) => {
    if (enabledOptions.length === 0) return;
    const nextIndex = activeIndex < 0
      ? direction === 1 ? 0 : enabledOptions.length - 1
      : (activeIndex + direction + enabledOptions.length) % enabledOptions.length;
    setActiveId(enabledOptions[nextIndex].id);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      setOpen(true);
      moveActive(event.key === "ArrowDown" ? 1 : -1);
      return;
    }
    if (event.key === "Home" && open) {
      event.preventDefault();
      setActiveId(enabledOptions[0]?.id ?? null);
      return;
    }
    if (event.key === "End" && open) {
      event.preventDefault();
      setActiveId(enabledOptions.at(-1)?.id ?? null);
      return;
    }
    if (event.key === "Enter" && open && activeId) {
      const option = enabledOptions.find((item) => item.id === activeId);
      if (option) {
        event.preventDefault();
        choose(option);
      }
      return;
    }
    if (event.key === "Escape" && open) {
      event.preventDefault();
      setOpen(false);
      setQuery(selected?.label ?? "");
    }
  };

  const handleBlur = (event: FocusEvent<HTMLDivElement>) => {
    if (!rootRef.current?.contains(event.relatedTarget as Node | null)) {
      setOpen(false);
      setQuery(selected?.label ?? "");
    }
  };

  return (
    <div className="rn-field" data-invalid={error ? "true" : undefined}>
      <label className="rn-field__label" htmlFor={id}>
        {label}{required ? <span className="rn-field__required" aria-hidden="true"> *</span> : null}
      </label>
      <div
        ref={rootRef}
        className="rn-combobox"
        data-open={String(open)}
        aria-disabled={disabled ? "true" : undefined}
        aria-busy={loading || undefined}
        onBlur={handleBlur}
      >
        <div className="rn-combobox__control">
          <input
            {...props}
            ref={assignInputRef}
            id={id}
            className={cx("rn-field__control", className)}
            role="combobox"
            aria-autocomplete="list"
            aria-expanded={open}
            aria-controls={listboxId}
            aria-activedescendant={open && activeId ? `${id}-option-${activeId}` : undefined}
            aria-describedby={[descriptionId, errorId].filter(Boolean).join(" ") || undefined}
            aria-invalid={error ? true : undefined}
            autoComplete="off"
            disabled={disabled}
            required={required}
            placeholder={placeholder}
            value={query}
            onChange={(event) => {
              const nextQuery = event.target.value;
              if (selectedId !== null) {
                if (value === undefined) setInternalValue(null);
                onValueChange?.(null);
              }
              setQuery(nextQuery);
              setOpen(true);
              setActiveId(null);
            }}
            onFocus={() => setOpen(true)}
            onKeyDown={handleKeyDown}
          />
          <button
            className="rn-combobox__toggle"
            type="button"
            tabIndex={-1}
            disabled={disabled}
            aria-label={open ? "Fechar opções" : "Abrir opções"}
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => {
              setOpen((current) => !current);
              inputRef.current?.focus();
            }}
          >
            <span aria-hidden="true">⌄</span>
          </button>
        </div>
        <ul className="rn-combobox__listbox" id={listboxId} role="listbox" hidden={!open}>
          {loading ? <li className="rn-combobox__status" role="status">{loadingText}</li> : filteredOptions.length > 0 ? filteredOptions.map((option) => (
            <li
              key={option.id}
              id={`${id}-option-${option.id}`}
              className="rn-combobox__option"
              role="option"
              aria-selected={selectedId === option.id}
              aria-disabled={option.disabled || undefined}
              data-active={activeId === option.id ? "true" : undefined}
              onMouseDown={(event) => event.preventDefault()}
              onMouseEnter={() => { if (!option.disabled) setActiveId(option.id); }}
              onClick={() => { if (!option.disabled) choose(option); }}
            >
              <span>{option.label}</span>
              {selectedId === option.id ? <span aria-hidden="true">✓</span> : null}
            </li>
          )) : <li className="rn-combobox__status">{noResultsText}</li>}
        </ul>
        <div className="rn-sr-only" role="status" aria-live="polite">
          {open && !loading ? `${filteredOptions.length} opções disponíveis.` : ""}
        </div>
      </div>
      {name ? <input type="hidden" name={name} value={selectedId ?? ""} /> : null}
      {description ? <p className="rn-field__description" id={descriptionId}>{description}</p> : null}
      {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
    </div>
  );
});
