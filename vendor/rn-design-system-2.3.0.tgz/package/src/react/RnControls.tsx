import {
  forwardRef,
  cloneElement,
  useId,
  type ButtonHTMLAttributes,
  type CSSProperties,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type ReactElement,
} from "react";
import { cx } from "./cx";

export interface RnSwitchProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onChange"> {
  checked: boolean;
  label: ReactNode;
  onCheckedChange?: (checked: boolean) => void;
}

export const RnSwitch = forwardRef<HTMLButtonElement, RnSwitchProps>(function RnSwitch(
  { checked, label, onCheckedChange, onClick, ...props },
  ref,
) {
  return (
    <button
      {...props}
      ref={ref}
      type="button"
      role="switch"
      aria-checked={checked}
      className={cx("rn-switch", props.className)}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) onCheckedChange?.(!checked);
      }}
    >
      <span className="rn-switch__track" aria-hidden="true"><span className="rn-switch__thumb" /></span>
      <span>{label}</span>
    </button>
  );
});

export type RnSearchStatus = "empty" | "typing" | "results" | "no-results" | "loading" | "error";

export interface RnSearchProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: string;
  icon?: ReactNode;
  status?: RnSearchStatus;
  resultCount?: number;
  statusMessage?: ReactNode;
}

export const RnSearch = forwardRef<HTMLInputElement, RnSearchProps>(function RnSearch(
  {
    label = "Buscar",
    icon,
    status = "empty",
    resultCount,
    statusMessage,
    id: suppliedId,
    className,
    "aria-describedby": describedBy,
    ...props
  },
  ref,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-search-${generatedId}`;
  const statusId = `${id}-status`;
  const defaultMessage = status === "loading"
    ? "Buscando…"
    : status === "results"
      ? resultCount === undefined
        ? "Resultados atualizados."
        : `${resultCount} ${resultCount === 1 ? "resultado encontrado" : "resultados encontrados"}.`
      : status === "no-results"
        ? "Nenhum resultado encontrado. Tente outro termo ou ajuste os filtros."
        : status === "error"
          ? "Não foi possível concluir a busca. Tente novamente."
          : null;
  const resolvedStatusMessage = statusMessage ?? defaultMessage;
  const statusIsVisible = status === "no-results" || status === "error";
  const inputDescribedBy = [describedBy, resolvedStatusMessage ? statusId : null].filter(Boolean).join(" ") || undefined;

  return (
    <div className="rn-search" data-status={status} aria-busy={status === "loading" || undefined}>
      <label className="rn-sr-only" htmlFor={id}>{label}</label>
      <div className="rn-search__control">
        {icon ? <span className="rn-search__icon" aria-hidden="true">{icon}</span> : null}
        <input
          {...props}
          ref={ref}
          id={id}
          type="search"
          className={cx("rn-field__control", className)}
          aria-describedby={inputDescribedBy}
          aria-invalid={status === "error" || props["aria-invalid"]}
        />
        {status === "loading" ? <span className="rn-search__loader" aria-hidden="true" /> : null}
      </div>
      {resolvedStatusMessage ? (
        <p
          className={cx("rn-search__status", !statusIsVisible && "rn-sr-only")}
          id={statusId}
          role={status === "error" ? "alert" : "status"}
        >
          {resolvedStatusMessage}
        </p>
      ) : null}
    </div>
  );
});

export interface RnTooltipProps extends Omit<HTMLAttributes<HTMLSpanElement>, "children" | "content"> {
  content: ReactNode;
  open?: boolean;
  children: ReactElement<{ "aria-describedby"?: string }>;
}

export const RnTooltip = forwardRef<HTMLSpanElement, RnTooltipProps>(function RnTooltip(
  { content, open, children, className, ...props },
  ref,
) {
  const contentId = useId();
  const describedBy = [children.props["aria-describedby"], contentId].filter(Boolean).join(" ");
  return (
    <span
      {...props}
      ref={ref}
      className={cx("rn-tooltip", className)}
      data-open={open === undefined ? undefined : String(open)}
    >
      {cloneElement(children, { "aria-describedby": describedBy })}
      <span className="rn-tooltip__content" role="tooltip" id={contentId}>{content}</span>
    </span>
  );
});

export type RnAvatarSize = "sm" | "md" | "lg" | "xl";

export interface RnAvatarProps extends HTMLAttributes<HTMLSpanElement> {
  name: string;
  src?: string;
  size?: RnAvatarSize;
}

const avatarSizes: Record<RnAvatarSize, string> = {
  sm: "var(--rn-control-sm)",
  md: "var(--rn-control-md)",
  lg: "var(--rn-control-lg)",
  xl: "var(--rn-space-12)",
};

export const RnAvatar = forwardRef<HTMLSpanElement, RnAvatarProps>(function RnAvatar(
  { name, src, size = "md", style, className, ...props },
  ref,
) {
  const initials = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toLocaleUpperCase())
    .join("");
  return (
    <span
      {...props}
      ref={ref}
      className={cx("rn-avatar", className)}
      style={{ "--rn-avatar-size": avatarSizes[size], ...style } as CSSProperties}
      role="img"
      aria-label={name}
    >
      {src ? <img src={src} alt="" /> : <span aria-hidden="true">{initials}</span>}
    </span>
  );
});

export interface RnProgressProps extends HTMLAttributes<HTMLDivElement> {
  label: string;
  value?: number;
  max?: number;
  status?: "default" | "complete" | "error";
  errorMessage?: string;
  showValue?: boolean;
  valueFormatter?: (value: number, max: number) => string;
}

export const RnProgress = forwardRef<HTMLDivElement, RnProgressProps>(function RnProgress(
  { label, value, max = 100, status = "default", errorMessage = "Não foi possível concluir o processo.", showValue = true, valueFormatter, className, ...props },
  ref,
) {
  const safeMax = Math.max(1, max);
  const safeValue = value === undefined ? undefined : Math.min(Math.max(value, 0), safeMax);
  const effectiveStatus = status === "default" && safeValue === safeMax ? "complete" : status;
  const formatted = safeValue === undefined
    ? "Em andamento"
    : valueFormatter?.(safeValue, safeMax) ?? `${Math.round((safeValue / safeMax) * 100)}%`;
  return (
    <div {...props} ref={ref} className={cx("rn-progress", className)} data-status={effectiveStatus}>
      <div className="rn-progress__meta">
        <strong>{label}</strong>
        {showValue ? <span>{formatted}</span> : null}
      </div>
      <progress value={safeValue} max={safeMax} aria-label={label} aria-invalid={effectiveStatus === "error" || undefined} />
      {effectiveStatus === "error" ? <p className="rn-progress__error" role="alert">{errorMessage}</p> : null}
    </div>
  );
});
