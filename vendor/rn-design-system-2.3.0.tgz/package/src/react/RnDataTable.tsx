import type { Key, ReactNode } from "react";
import { cx } from "./cx";

export type RnSortDirection = "ascending" | "descending" | "none";
export type RnDataTableStatus = "ready" | "loading" | "error" | "partial";

export interface RnDataColumn<Row> {
  id: string;
  header: ReactNode;
  cell: (row: Row) => ReactNode;
  numeric?: boolean;
  sortDirection?: RnSortDirection;
  onSort?: (direction: Exclude<RnSortDirection, "none">) => void;
}

export interface RnDataTableProps<Row> {
  caption: string;
  columns: readonly RnDataColumn<Row>[];
  rows: readonly Row[];
  rowKey: (row: Row) => Key;
  emptyMessage?: string;
  status?: RnDataTableStatus;
  statusMessage?: ReactNode;
  isRowSelected?: (row: Row) => boolean;
  className?: string;
}

export function RnDataTable<Row>({
  caption,
  columns,
  rows,
  rowKey,
  emptyMessage = "Nenhum registro encontrado.",
  status = "ready",
  statusMessage,
  isRowSelected,
  className,
}: RnDataTableProps<Row>) {
  const blockingStatus = status === "loading" || status === "error";
  const defaultStatusMessage = status === "loading"
    ? "Carregando registros…"
    : status === "error"
      ? "Não foi possível carregar os registros. Tente novamente."
      : status === "partial"
        ? "Alguns registros não puderam ser carregados. Os dados disponíveis continuam visíveis."
        : null;
  const resolvedStatusMessage = statusMessage ?? defaultStatusMessage;
  const columnCount = Math.max(1, columns.length);

  return (
    <div
      className={cx("rn-table-wrap", className)}
      data-status={status}
      aria-busy={status === "loading" || undefined}
    >
      <table className="rn-table">
        <caption className="rn-sr-only">{caption}</caption>
        <thead>
          <tr>
            {columns.map((column) => {
              const sortable = typeof column.onSort === "function";
              const direction = sortable ? column.sortDirection ?? "none" : undefined;
              const nextDirection = direction === "ascending" ? "descending" : "ascending";
              return (
                <th
                  key={column.id}
                  scope="col"
                  aria-sort={direction}
                  style={column.numeric ? { textAlign: "right" } : undefined}
                >
                  {sortable ? (
                    <button
                      className="rn-table__sort"
                      type="button"
                      onClick={() => column.onSort?.(nextDirection)}
                    >
                      <span>{column.header}</span>
                      <span className="rn-table__sort-indicator" data-direction={direction} aria-hidden="true" />
                    </button>
                  ) : column.header}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {blockingStatus ? (
            <tr>
              <td className="rn-table__status" colSpan={columnCount}>
                <span role={status === "error" ? "alert" : "status"}>{resolvedStatusMessage}</span>
              </td>
            </tr>
          ) : (
            <>
              {status === "partial" && resolvedStatusMessage ? (
                <tr>
                  <td className="rn-table__status rn-table__status--partial" colSpan={columnCount}>
                    <span role="status">{resolvedStatusMessage}</span>
                  </td>
                </tr>
              ) : null}
              {rows.length > 0 ? rows.map((row) => {
                const selected = isRowSelected?.(row) ?? false;
                return (
                  <tr key={rowKey(row)} data-selected={selected || undefined} aria-selected={selected || undefined}>
                    {columns.map((column) => (
                      <td key={column.id} style={column.numeric ? { textAlign: "right" } : undefined}>{column.cell(row)}</td>
                    ))}
                  </tr>
                );
              }) : (
                <tr><td className="rn-table__status" colSpan={columnCount}>{emptyMessage}</td></tr>
              )}
            </>
          )}
        </tbody>
      </table>
    </div>
  );
}
