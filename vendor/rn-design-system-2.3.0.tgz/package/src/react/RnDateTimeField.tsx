import {
  forwardRef,
  useId,
  useRef,
  type HTMLAttributes,
  type InputHTMLAttributes,
} from "react";
import { cx } from "./cx";

export type RnDateTimeKind = "date" | "time" | "datetime-local";

export interface RnDateTimeFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "defaultValue" | "onChange"> {
  kind?: RnDateTimeKind;
  label: string;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  description?: string;
  error?: string;
}

export const RnDateTimeField = forwardRef<HTMLInputElement, RnDateTimeFieldProps>(function RnDateTimeField(
  {
    kind = "date",
    label,
    value,
    defaultValue,
    onValueChange,
    description,
    error,
    id: suppliedId,
    required,
    disabled,
    className,
    ...props
  },
  forwardedRef,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-date-time-${generatedId}`;
  const descriptionId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const inputRef = useRef<HTMLInputElement | null>(null);

  const assignRef = (node: HTMLInputElement | null) => {
    inputRef.current = node;
    if (typeof forwardedRef === "function") forwardedRef(node);
    else if (forwardedRef) forwardedRef.current = node;
  };

  return (
    <div className="rn-field" data-invalid={error ? "true" : undefined}>
      <label className="rn-field__label" htmlFor={id}>
        {label}{required ? <span className="rn-field__required" aria-hidden="true"> *</span> : null}
      </label>
      <div className="rn-date-picker" aria-disabled={disabled ? "true" : undefined}>
        <input
          {...props}
          ref={assignRef}
          id={id}
          type={kind}
          className={cx("rn-field__control", className)}
          value={value}
          defaultValue={defaultValue}
          required={required}
          disabled={disabled}
          aria-describedby={[descriptionId, errorId].filter(Boolean).join(" ") || undefined}
          aria-invalid={error ? true : undefined}
          onChange={(event) => onValueChange?.(event.target.value)}
        />
        <button
          className="rn-date-picker__trigger-icon"
          type="button"
          tabIndex={-1}
          disabled={disabled}
          aria-label={kind === "time" ? "Abrir seletor de horário" : "Abrir calendário"}
          onClick={() => {
            inputRef.current?.focus();
            inputRef.current?.showPicker?.();
          }}
        >
          <span aria-hidden="true">{kind === "time" ? "◷" : "▦"}</span>
        </button>
      </div>
      {description ? <p className="rn-field__description" id={descriptionId}>{description}</p> : null}
      {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
    </div>
  );
});

export interface RnDateRangeFieldProps extends Omit<HTMLAttributes<HTMLFieldSetElement>, "onChange"> {
  legend: string;
  startLabel?: string;
  endLabel?: string;
  startValue?: string;
  endValue?: string;
  min?: string;
  max?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  onRangeChange?: (range: { start: string; end: string }) => void;
}

export const RnDateRangeField = forwardRef<HTMLFieldSetElement, RnDateRangeFieldProps>(function RnDateRangeField(
  {
    legend,
    startLabel = "Data inicial",
    endLabel = "Data final",
    startValue = "",
    endValue = "",
    min,
    max,
    disabled,
    required,
    error,
    onRangeChange,
    className,
    ...props
  },
  ref,
) {
  const generatedId = useId();
  const startId = `rn-range-start-${generatedId}`;
  const endId = `rn-range-end-${generatedId}`;
  const errorId = error ? `rn-range-error-${generatedId}` : undefined;

  return (
    <fieldset {...props} ref={ref} className={cx("rn-date-range", className)} disabled={disabled} aria-describedby={errorId}>
      <legend className="rn-field__label">{legend}{required ? <span className="rn-field__required" aria-hidden="true"> *</span> : null}</legend>
      <div className="rn-date-range__fields">
        <div className="rn-field" data-invalid={error ? "true" : undefined}>
          <label className="rn-field__label" htmlFor={startId}>{startLabel}</label>
          <input
            className="rn-field__control"
            id={startId}
            type="date"
            value={startValue}
            min={min}
            max={endValue || max}
            required={required}
            aria-invalid={error ? true : undefined}
            onChange={(event) => onRangeChange?.({ start: event.target.value, end: endValue })}
          />
        </div>
        <div className="rn-field" data-invalid={error ? "true" : undefined}>
          <label className="rn-field__label" htmlFor={endId}>{endLabel}</label>
          <input
            className="rn-field__control"
            id={endId}
            type="date"
            value={endValue}
            min={startValue || min}
            max={max}
            required={required}
            aria-invalid={error ? true : undefined}
            onChange={(event) => onRangeChange?.({ start: startValue, end: event.target.value })}
          />
        </div>
      </div>
      {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
    </fieldset>
  );
});
