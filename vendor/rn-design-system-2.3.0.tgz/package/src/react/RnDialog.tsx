import {
  forwardRef,
  useEffect,
  useId,
  useImperativeHandle,
  useRef,
  type DialogHTMLAttributes,
  type ReactNode,
} from "react";
import { cx } from "./cx";

export interface RnDialogProps extends Omit<DialogHTMLAttributes<HTMLDialogElement>, "open"> {
  open: boolean;
  title: string;
  description?: string;
  footer?: ReactNode;
  closeLabel?: string;
  onRequestClose: () => void;
}

export const RnDialog = forwardRef<HTMLDialogElement, RnDialogProps>(function RnDialog(
  {
    open,
    title,
    description,
    footer,
    closeLabel = "Fechar",
    className,
    onRequestClose,
    children,
    ...props
  },
  forwardedRef,
) {
  const internalRef = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const descriptionId = useId();
  useImperativeHandle(forwardedRef, () => internalRef.current as HTMLDialogElement);

  useEffect(() => {
    const dialog = internalRef.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      {...props}
      ref={internalRef}
      className={cx("rn-dialog", className)}
      aria-labelledby={titleId}
      aria-describedby={description ? descriptionId : undefined}
      onCancel={(event) => {
        event.preventDefault();
        onRequestClose();
      }}
      onClose={() => {
        if (open) onRequestClose();
      }}
    >
      <header className="rn-dialog__header">
        <div>
          <h2 id={titleId}>{title}</h2>
          {description ? <p id={descriptionId}>{description}</p> : null}
        </div>
        <button className="rn-icon-button" type="button" aria-label={closeLabel} onClick={onRequestClose}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
            <path d="M6 6l12 12M18 6 6 18" />
          </svg>
        </button>
      </header>
      <div className="rn-dialog__body">{children}</div>
      {footer ? <footer className="rn-dialog__footer">{footer}</footer> : null}
    </dialog>
  );
});
