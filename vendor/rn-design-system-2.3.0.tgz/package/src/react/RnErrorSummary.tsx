import { forwardRef, type HTMLAttributes } from "react";
import { cx } from "./cx";

export interface RnFormError {
  fieldId: string;
  message: string;
}

export interface RnErrorSummaryProps extends HTMLAttributes<HTMLDivElement> {
  errors: readonly RnFormError[];
  title?: string;
}

export const RnErrorSummary = forwardRef<HTMLDivElement, RnErrorSummaryProps>(
  function RnErrorSummary({ errors, title = "Revise os campos abaixo", className, ...props }, ref) {
    if (errors.length === 0) return null;
    return (
      <div {...props} ref={ref} className={cx("rn-error-summary", className)} role="alert" tabIndex={-1}>
        <h2>{title}</h2>
        <ul>
          {errors.map((error) => (
            <li key={error.fieldId}><a href={`#${error.fieldId}`}>{error.message}</a></li>
          ))}
        </ul>
      </div>
    );
  },
);
