import {
  forwardRef,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { cx } from "./cx";

export type RnStatusTone = "info" | "success" | "warning" | "danger";

export interface RnAlertProps extends HTMLAttributes<HTMLDivElement> {
  tone?: RnStatusTone;
  title: string;
  icon?: ReactNode;
}

export const RnAlert = forwardRef<HTMLDivElement, RnAlertProps>(function RnAlert(
  { tone = "info", title, icon, children, className, role, ...props },
  ref,
) {
  return (
    <div
      {...props}
      ref={ref}
      className={cx("rn-alert", tone !== "info" && `rn-alert--${tone}`, className)}
      role={role ?? (tone === "danger" ? "alert" : undefined)}
    >
      {icon ? <span aria-hidden="true">{icon}</span> : null}
      <div>
        <h3 className="rn-alert__title">{title}</h3>
        {typeof children === "string" ? <p>{children}</p> : children}
      </div>
    </div>
  );
});

export interface RnChipProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: "brand" | "neutral" | "success" | "warning" | "danger";
}

export const RnChip = forwardRef<HTMLSpanElement, RnChipProps>(function RnChip(
  { tone = "brand", className, ...props },
  ref,
) {
  return (
    <span
      {...props}
      ref={ref}
      className={cx("rn-chip", tone !== "brand" && `rn-chip--${tone}`, className)}
    />
  );
});

export const RnBadge = forwardRef<HTMLSpanElement, HTMLAttributes<HTMLSpanElement>>(function RnBadge(
  { className, ...props },
  ref,
) {
  return <span {...props} ref={ref} className={cx("rn-badge", className)} />;
});

export interface RnToastProps extends HTMLAttributes<HTMLDivElement> {
  title: string;
  icon?: ReactNode;
  action?: ReactNode;
  announce?: "polite" | "assertive" | "off";
}

export const RnToast = forwardRef<HTMLDivElement, RnToastProps>(function RnToast(
  { title, icon, action, announce = "polite", children, className, ...props },
  ref,
) {
  return (
    <div
      {...props}
      ref={ref}
      className={cx("rn-toast", className)}
      role={announce === "assertive" ? "alert" : "status"}
      aria-live={announce}
      aria-atomic="true"
    >
      {icon ? <span aria-hidden="true">{icon}</span> : null}
      <div>
        <strong>{title}</strong>
        {typeof children === "string" ? <p>{children}</p> : children}
      </div>
      {action}
    </div>
  );
});

export interface RnEmptyStateProps extends HTMLAttributes<HTMLDivElement> {
  title: string;
  description?: ReactNode;
  illustration?: ReactNode;
  action?: ReactNode;
}

export const RnEmptyState = forwardRef<HTMLDivElement, RnEmptyStateProps>(function RnEmptyState(
  { title, description, illustration, action, className, ...props },
  ref,
) {
  return (
    <div {...props} ref={ref} className={cx("rn-empty-state", className)}>
      <div className="rn-empty-state__inner">
        {illustration ? <div aria-hidden="true">{illustration}</div> : null}
        <h2>{title}</h2>
        {description ? <p>{description}</p> : null}
        {action}
      </div>
    </div>
  );
});

export interface RnSkeletonProps extends HTMLAttributes<HTMLDivElement> {
  label?: string;
}

export const RnSkeleton = forwardRef<HTMLDivElement, RnSkeletonProps>(function RnSkeleton(
  { label = "Carregando conteúdo", className, ...props },
  ref,
) {
  return (
    <div
      {...props}
      ref={ref}
      className={cx("rn-skeleton", className)}
      role="status"
      aria-label={label}
    />
  );
});
