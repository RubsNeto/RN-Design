import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from "react";
import { cx } from "./cx";

export interface RnFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "size"> {
  label: string;
  description?: ReactNode;
  error?: ReactNode;
}

export const RnField = forwardRef<HTMLInputElement, RnFieldProps>(
  function RnField(
    { label, description, error, className, id: suppliedId, required, "aria-describedby": describedBy, ...props },
    ref,
  ) {
    const generatedId = useId();
    const id = suppliedId ?? `rn-field-${generatedId}`;
    const descriptionId = description ? `${id}-description` : undefined;
    const errorId = error ? `${id}-error` : undefined;
    const descriptions = [describedBy, descriptionId, errorId].filter(Boolean).join(" ") || undefined;

    return (
      <div className="rn-field" data-invalid={error ? "true" : undefined}>
        <label className="rn-field__label" htmlFor={id}>
          {label}{" "}
          {required ? <span className="rn-field__required" aria-hidden="true">*</span> : null}
        </label>
        <input
          {...props}
          ref={ref}
          id={id}
          className={cx("rn-field__control", className)}
          required={required}
          aria-describedby={descriptions}
          aria-invalid={error ? true : undefined}
        />
        {description ? <p className="rn-field__description" id={descriptionId}>{description}</p> : null}
        {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
      </div>
    );
  },
);
