import {
  forwardRef,
  useId,
  type InputHTMLAttributes,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";
import { cx } from "./cx";

export interface RnSharedFieldProps {
  label: string;
  description?: string;
  error?: string;
}

export interface RnSelectProps extends SelectHTMLAttributes<HTMLSelectElement>, RnSharedFieldProps {}

export const RnSelect = forwardRef<HTMLSelectElement, RnSelectProps>(function RnSelect(
  { label, description, error, id: suppliedId, className, children, required, ...props },
  ref,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-select-${generatedId}`;
  const helpId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;

  return (
    <div className="rn-field" data-invalid={error ? "true" : undefined}>
      <label className="rn-field__label" htmlFor={id}>
        {label}{required ? <span className="rn-field__required" aria-hidden="true"> *</span> : null}
      </label>
      <select
        {...props}
        ref={ref}
        id={id}
        required={required}
        className={cx("rn-field__control", className)}
        aria-describedby={[helpId, errorId].filter(Boolean).join(" ") || undefined}
        aria-invalid={error ? true : undefined}
      >
        {children}
      </select>
      {description ? <p className="rn-field__description" id={helpId}>{description}</p> : null}
      {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
    </div>
  );
});

export interface RnTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement>, RnSharedFieldProps {}

export const RnTextarea = forwardRef<HTMLTextAreaElement, RnTextareaProps>(function RnTextarea(
  { label, description, error, id: suppliedId, className, required, ...props },
  ref,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-textarea-${generatedId}`;
  const helpId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;

  return (
    <div className="rn-field" data-invalid={error ? "true" : undefined}>
      <label className="rn-field__label" htmlFor={id}>
        {label}{required ? <span className="rn-field__required" aria-hidden="true"> *</span> : null}
      </label>
      <textarea
        {...props}
        ref={ref}
        id={id}
        required={required}
        className={cx("rn-field__control", className)}
        aria-describedby={[helpId, errorId].filter(Boolean).join(" ") || undefined}
        aria-invalid={error ? true : undefined}
      />
      {description ? <p className="rn-field__description" id={helpId}>{description}</p> : null}
      {error ? <p className="rn-field__error" id={errorId}>{error}</p> : null}
    </div>
  );
});

export interface RnCheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  label: string;
}

export const RnCheckbox = forwardRef<HTMLInputElement, RnCheckboxProps>(function RnCheckbox(
  { label, id: suppliedId, ...props },
  ref,
) {
  const generatedId = useId();
  const id = suppliedId ?? `rn-check-${generatedId}`;
  return (
    <label className="rn-check" htmlFor={id}>
      <input {...props} ref={ref} id={id} type="checkbox" />
      <span>{label}</span>
    </label>
  );
});
