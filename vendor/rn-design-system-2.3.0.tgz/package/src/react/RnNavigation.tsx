import {
  useMemo,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { cx } from "./cx";

export interface RnSegmentedItem {
  id: string;
  label: ReactNode;
  disabled?: boolean;
}

export interface RnSegmentedProps {
  label: string;
  items: readonly RnSegmentedItem[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  className?: string;
}

export function RnSegmented({ label, items, value, defaultValue, onValueChange, className }: RnSegmentedProps) {
  const [internalValue, setInternalValue] = useState(defaultValue ?? items.find((item) => !item.disabled)?.id);
  const selected = value ?? internalValue;
  return (
    <div className={cx("rn-segmented", className)} role="group" aria-label={label}>
      {items.map((item) => (
        <button
          key={item.id}
          className="rn-segmented__item"
          type="button"
          disabled={item.disabled}
          aria-pressed={selected === item.id}
          onClick={() => {
            if (value === undefined) setInternalValue(item.id);
            onValueChange?.(item.id);
          }}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export type RnStepState = "upcoming" | "current" | "complete" | "error" | "disabled";

export interface RnStepItem {
  id: string;
  label: ReactNode;
  state?: RnStepState;
}

export interface RnStepperProps {
  label: string;
  steps: readonly RnStepItem[];
  currentStep?: string;
  className?: string;
}

const stepStateLabels: Record<RnStepState, string> = {
  upcoming: "próxima",
  current: "atual",
  complete: "concluída",
  error: "com erro",
  disabled: "indisponível",
};

function StepStateIcon({ state, index }: { state: RnStepState; index: number }) {
  if (state === "complete") {
    return <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m4.5 10.2 3.4 3.4 7.6-7.6" /></svg>;
  }
  if (state === "error") {
    return <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 5.2v5.3M10 14.2v.6" /></svg>;
  }
  return <>{index + 1}</>;
}

export function RnStepper({ label, steps, currentStep, className }: RnStepperProps) {
  const currentIndex = currentStep ? steps.findIndex((step) => step.id === currentStep) : -1;
  return (
    <nav aria-label={label}>
      <ol
        className={cx("rn-stepper", className)}
        style={{ "--rn-step-count": steps.length } as CSSProperties}
      >
        {steps.map((step, index) => {
          const state = step.state ?? (currentIndex < 0 ? "upcoming" : index < currentIndex ? "complete" : index === currentIndex ? "current" : "upcoming");
          return (
            <li
              key={step.id}
              className="rn-stepper__item"
              data-state={state}
              aria-current={state === "current" ? "step" : undefined}
              aria-disabled={state === "disabled" || undefined}
            >
              <span className="rn-stepper__index" aria-hidden="true"><StepStateIcon state={state} index={index} /></span>
              <span>{step.label}<span className="rn-sr-only">, {stepStateLabels[state]}</span></span>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export interface RnBreadcrumbItem {
  label: string;
  href?: string;
}

export interface RnBreadcrumbProps {
  label?: string;
  items: readonly RnBreadcrumbItem[];
  className?: string;
}

export function RnBreadcrumb({ label = "Navegação estrutural", items, className }: RnBreadcrumbProps) {
  return (
    <nav aria-label={label}>
      <ol className={cx("rn-breadcrumb", className)}>
        {items.map((item, index) => {
          const current = index === items.length - 1;
          return (
            <li key={`${item.label}-${index}`}>
              {!current && item.href ? <a href={item.href}>{item.label}</a> : <span aria-current={current ? "page" : undefined}>{item.label}</span>}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export interface RnPaginationProps {
  page: number;
  pageCount: number;
  onPageChange: (page: number) => void;
  label?: string;
  siblingCount?: number;
  className?: string;
}

export function RnPagination({
  page,
  pageCount,
  onPageChange,
  label = "Paginação",
  siblingCount = 1,
  className,
}: RnPaginationProps) {
  const pages = useMemo(() => {
    const visible = new Set([1, pageCount]);
    for (let value = page - siblingCount; value <= page + siblingCount; value += 1) {
      if (value > 0 && value <= pageCount) visible.add(value);
    }
    return [...visible].sort((a, b) => a - b);
  }, [page, pageCount, siblingCount]);

  if (pageCount <= 1) return null;

  return (
    <nav className={cx("rn-pagination", className)} aria-label={label}>
      <button className="rn-button rn-button--secondary rn-button--sm" type="button" disabled={page <= 1} onClick={() => onPageChange(page - 1)}>
        Anterior
      </button>
      <div className="rn-pagination__pages">
        {pages.map((pageNumber, index) => (
          <span key={pageNumber}>
            {index > 0 && pageNumber - pages[index - 1] > 1 ? <span aria-hidden="true">…</span> : null}
            <button
              className="rn-pagination__page"
              type="button"
              aria-label={`Página ${pageNumber}`}
              aria-current={pageNumber === page ? "page" : undefined}
              onClick={() => onPageChange(pageNumber)}
            >
              {pageNumber}
            </button>
          </span>
        ))}
      </div>
      <button className="rn-button rn-button--secondary rn-button--sm" type="button" disabled={page >= pageCount} onClick={() => onPageChange(page + 1)}>
        Próxima
      </button>
    </nav>
  );
}
