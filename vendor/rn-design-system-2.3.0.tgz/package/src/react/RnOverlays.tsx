import {
  forwardRef,
  useEffect,
  useId,
  useImperativeHandle,
  useRef,
  type ButtonHTMLAttributes,
  type DialogHTMLAttributes,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { cx } from "./cx";

export interface RnDrawerProps extends Omit<DialogHTMLAttributes<HTMLDialogElement>, "open" | "title"> {
  open: boolean;
  title: ReactNode;
  description?: string;
  footer?: ReactNode;
  closeLabel?: string;
  onRequestClose: () => void;
}

export const RnDrawer = forwardRef<HTMLDialogElement, RnDrawerProps>(function RnDrawer(
  {
    open,
    title,
    description,
    footer,
    closeLabel = "Fechar painel",
    onRequestClose,
    className,
    children,
    ...props
  },
  forwardedRef,
) {
  const internalRef = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const descriptionId = useId();
  useImperativeHandle(forwardedRef, () => internalRef.current as HTMLDialogElement);

  useEffect(() => {
    const drawer = internalRef.current;
    if (!drawer) return;
    if (open && !drawer.open) drawer.showModal();
    if (!open && drawer.open) drawer.close();
  }, [open]);

  return (
    <dialog
      {...props}
      ref={internalRef}
      className={cx("rn-drawer", className)}
      aria-labelledby={titleId}
      aria-describedby={description ? descriptionId : undefined}
      onCancel={(event) => {
        event.preventDefault();
        onRequestClose();
      }}
      onClose={() => { if (open) onRequestClose(); }}
    >
      <header className="rn-dialog__header">
        <div>
          <h2 id={titleId}>{title}</h2>
          {description ? <p id={descriptionId}>{description}</p> : null}
        </div>
        <button className="rn-icon-button" type="button" aria-label={closeLabel} onClick={onRequestClose}>
          <span aria-hidden="true">×</span>
        </button>
      </header>
      <div className="rn-dialog__body">{children}</div>
      {footer ? <footer className="rn-dialog__footer">{footer}</footer> : null}
    </dialog>
  );
});

export interface RnPopoverProps extends Omit<HTMLAttributes<HTMLDivElement>, "id"> {
  id: string;
}

export const RnPopover = forwardRef<HTMLDivElement, RnPopoverProps>(function RnPopover(
  { id, className, ...props },
  ref,
) {
  return <div {...props} ref={ref} id={id} className={cx("rn-popover", className)} popover="auto" />;
});

export interface RnPopoverTriggerProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  popoverId: string;
}

export const RnPopoverTrigger = forwardRef<HTMLButtonElement, RnPopoverTriggerProps>(function RnPopoverTrigger(
  { popoverId, type = "button", ...props },
  ref,
) {
  return <button {...props} ref={ref} type={type} popoverTarget={popoverId} />;
});
