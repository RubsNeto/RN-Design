import { forwardRef, type CSSProperties, type HTMLAttributes, type ReactNode } from "react";
import { RnAnimatedWordmark, type RnAnimatedWordmarkProps } from "../components/RnAnimatedWordmark";
import { cx } from "./cx";

export interface RnStoryHeroProps extends Omit<HTMLAttributes<HTMLElement>, "title"> {
  title: ReactNode;
  support: ReactNode;
  capabilities?: readonly string[];
  action?: ReactNode;
  wordmarkTiming?: RnAnimatedWordmarkProps["timing"];
}

export const RnStoryHero = forwardRef<HTMLElement, RnStoryHeroProps>(
  function RnStoryHero(
    { title, support, capabilities = [], action, wordmarkTiming = "overlap", className, ...props },
    ref,
  ) {
    return (
      <section {...props} ref={ref} className={cx("rn-story-hero", className)}>
        <RnAnimatedWordmark size="hero" timing={wordmarkTiming} />

        <div className="rn-story-hero__content">
          <h1 className="rn-story-title">{title}</h1>
          <div className="rn-stack" style={{ "--rn-stack-gap": "var(--rn-space-5)" } as CSSProperties}>
            {capabilities.length > 0 ? (
              <div className="rn-capability-chips" aria-label="Capacidades">
                {capabilities.map((capability) => <span key={capability}>{capability}</span>)}
              </div>
            ) : null}
            <p className="rn-story-support">{support}</p>
            {action}
          </div>
        </div>
      </section>
    );
  },
);
