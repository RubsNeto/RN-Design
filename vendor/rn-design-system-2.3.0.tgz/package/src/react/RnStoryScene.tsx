import { forwardRef, type HTMLAttributes } from "react";
import { cx } from "./cx";

export type RnStorySceneTone = "light" | "dark" | "stage" | "deep";

export interface RnStorySceneProps extends HTMLAttributes<HTMLElement> {
  tone?: RnStorySceneTone;
  contained?: boolean;
}

export const RnStoryScene = forwardRef<HTMLElement, RnStorySceneProps>(
  function RnStoryScene({ tone = "light", contained = true, className, children, ...props }, ref) {
    return (
      <section
        {...props}
        ref={ref}
        className={cx("rn-story-scene", tone !== "light" && `rn-story-scene--${tone}`, className)}
      >
        {contained ? <div className="rn-story-scene__inner">{children}</div> : children}
      </section>
    );
  },
);
