import { useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";

export interface RnTabItem {
  id: string;
  label: string;
  content: ReactNode;
  disabled?: boolean;
}

export interface RnTabsProps {
  label: string;
  items: readonly RnTabItem[];
  defaultTab?: string;
  onTabChange?: (id: string) => void;
}

export function RnTabs({ label, items, defaultTab, onTabChange }: RnTabsProps) {
  const baseId = useId();
  const firstEnabled = items.find((item) => !item.disabled)?.id;
  const [active, setActive] = useState(defaultTab ?? firstEnabled);
  const refs = useRef<Array<HTMLButtonElement | null>>([]);

  if (items.length === 0 || !firstEnabled) return null;

  const select = (id: string) => {
    setActive(id);
    onTabChange?.(id);
  };

  const move = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    const enabledIndexes = items.flatMap((item, itemIndex) => item.disabled ? [] : [itemIndex]);
    const current = enabledIndexes.indexOf(index);
    let target: number | undefined;

    if (event.key === "Home") target = enabledIndexes[0];
    if (event.key === "End") target = enabledIndexes.at(-1);
    if (event.key === "ArrowRight") target = enabledIndexes[(current + 1) % enabledIndexes.length];
    if (event.key === "ArrowLeft") target = enabledIndexes[(current - 1 + enabledIndexes.length) % enabledIndexes.length];
    if (target === undefined) return;

    event.preventDefault();
    refs.current[target]?.focus();
    select(items[target].id);
  };

  return (
    <div>
      <div className="rn-tabs" role="tablist" aria-label={label}>
        {items.map((item, index) => (
          <button
            key={item.id}
            ref={(element) => { refs.current[index] = element; }}
            className="rn-tab"
            id={`${baseId}-${item.id}-tab`}
            type="button"
            role="tab"
            disabled={item.disabled}
            aria-selected={active === item.id}
            aria-controls={`${baseId}-${item.id}-panel`}
            tabIndex={active === item.id ? 0 : -1}
            onClick={() => select(item.id)}
            onKeyDown={(event) => move(event, index)}
          >
            {item.label}
          </button>
        ))}
      </div>
      {items.map((item) => (
        <section
          key={item.id}
          className="rn-tab-panel"
          id={`${baseId}-${item.id}-panel`}
          role="tabpanel"
          aria-labelledby={`${baseId}-${item.id}-tab`}
          hidden={active !== item.id}
          tabIndex={0}
        >
          {item.content}
        </section>
      ))}
    </div>
  );
}
