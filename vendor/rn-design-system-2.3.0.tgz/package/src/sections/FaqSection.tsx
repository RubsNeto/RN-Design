import { useState } from "react";
import { SectionLabel } from "../components/SectionLabel";
import { company, faqs, whatsappLink } from "../data/content";

function FaqItem({
  question,
  answer,
  open,
  onToggle,
}: {
  question: string;
  answer: string;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <article className={`faq-item${open ? " is-open" : ""}`}>
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        data-cursor={open ? "Fechar" : "Abrir"}
      >
        <span>{question}</span>
        <i aria-hidden="true"><span /><span /></i>
      </button>
      <div className="faq-item__answer" aria-hidden={!open}>
        <p>{answer}</p>
      </div>
    </article>
  );
}

export function FaqSection() {
  const [openItems, setOpenItems] = useState<Set<number>>(() => new Set());
  const orderedFaqs = [faqs[0], faqs[2], faqs[1], faqs[3]];

  const toggle = (index: number) => {
    setOpenItems((current) => {
      const next = new Set(current);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  return (
    <section className="faq-section">
      <div className="faq-section__content">
        <div className="faq-section__heading" data-reveal="heading">
          <SectionLabel tone="dark">Dúvidas</SectionLabel>
          <h2>Perguntas frequentes</h2>
        </div>
        <div className="faq-grid" data-testid="faq-grid" data-reveal="copy">
          {orderedFaqs.map((faq, index) => (
            <FaqItem
              key={faq.question}
              {...faq}
              open={openItems.has(index)}
              onToggle={() => toggle(index)}
            />
          ))}
        </div>
      </div>

      <footer className="closing-scene">
        <img className="closing-scene__glow" src="/assets/images/rn-glow.svg" alt="" loading="lazy" decoding="async" />
        <img
          className="closing-scene__glow closing-scene__glow--secondary"
          src="/assets/images/rn-glow.svg"
          alt=""
          loading="lazy"
          decoding="async"
        />
        <img
          className="closing-scene__devices"
          src="/assets/images/rn-footer-devices.svg"
          alt={`Notebooks exibindo sistemas da ${company.shortName}`}
          loading="lazy"
          decoding="async"
        />
        <img
          className="closing-scene__badge"
          src="/assets/brand/rn-logo.png"
          alt={`${company.name} — ${company.site}`}
          loading="lazy"
          decoding="async"
        />
        <div className="closing-scene__contact">
          <a href={whatsappLink} target="_blank" rel="noreferrer" data-cursor="WhatsApp">
            (62) 9 9929-9020
          </a>
          <span aria-hidden="true">·</span>
          <a href={`mailto:${company.email}`} data-cursor="E-mail">{company.email}</a>
          <span aria-hidden="true">·</span>
          <a href={company.siteUrl} target="_blank" rel="noreferrer" data-cursor="Site">{company.site}</a>
          <span aria-hidden="true">·</span>
          <a href={company.instagram} target="_blank" rel="noreferrer" data-cursor="Instagram">Instagram</a>
          <span aria-hidden="true">·</span>
          <a href={company.linkedin} target="_blank" rel="noreferrer" data-cursor="LinkedIn">LinkedIn</a>
          <small>
            {company.name} · CNPJ {company.cnpj} · {company.city}
          </small>
        </div>
      </footer>
    </section>
  );
}
