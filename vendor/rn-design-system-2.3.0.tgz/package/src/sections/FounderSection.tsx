import { useEffect, useRef } from "react";
import { SectionLabel } from "../components/SectionLabel";
import { founder } from "../data/content";

/** Assinatura estilizada desenhada com stroke-dashoffset ao entrar na tela. */
function FounderSignature() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        svg.classList.add("is-signed");
        observer.disconnect();
      },
      { threshold: 0.5 },
    );
    observer.observe(svg);
    return () => observer.disconnect();
  }, []);

  return (
    <svg
      ref={svgRef}
      className="founder-signature"
      viewBox="0 0 360 130"
      role="img"
      aria-label={`Assinatura de ${founder.name}`}
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <defs>
        <linearGradient id="rn-sig-grad" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#1a6fae" />
          <stop offset="0.55" stopColor="#47abe1" />
          <stop offset="1" stopColor="#3fd0e9" />
        </linearGradient>
      </defs>
      {/* "Rubens" — letras distintas com levantes de caneta */}
      <path
        pathLength={1}
        stroke="url(#rn-sig-grad)"
        strokeWidth="3.2"
        d="M24 84 C22 68 24 44 28 35 M27 39 C38 31 51 34 50 44 C49 53 38 57 28 55 M31 55 C39 58 46 70 51 84 M61 62 C59 70 58 78 61 82 C65 86 71 82 73 74 C74 70 75 65 75 62 M75 62 C74 72 75 80 79 83 M89 36 C87 50 86 68 86 80 M86 66 C91 60 99 62 99 70 C99 78 91 82 86 78 M108 70 C113 68 115 64 112 61 C108 58 104 62 104 68 C104 76 109 80 115 77 M123 62 C122 68 121 76 121 82 M121 70 C124 63 130 60 133 64 C135 67 135 76 134 82 M148 62 C143 62 141 66 144 69 C148 72 149 75 146 78 C143 81 139 80 137 77"
      />
      {/* "Neto" */}
      <path
        pathLength={1}
        stroke="url(#rn-sig-grad)"
        strokeWidth="3.2"
        d="M196 84 C195 70 196 52 198 40 M198 40 C204 52 212 70 216 82 M216 82 C218 70 219 52 220 40 M230 70 C235 68 237 64 234 61 C230 58 226 62 226 68 C226 76 231 80 237 77 M248 40 C246 54 245 70 247 79 C248 83 252 84 255 80 M272 62 C266 64 264 72 268 78 C272 83 280 81 282 74 C284 67 279 61 272 62 M282 74 C290 72 300 68 312 62"
      />
      {/* corte do "t" */}
      <path
        pathLength={1}
        stroke="url(#rn-sig-grad)"
        strokeWidth="2.6"
        d="M242 52 C248 49 256 48 262 50"
      />
      {/* rubrica */}
      <path
        pathLength={1}
        stroke="url(#rn-sig-grad)"
        strokeWidth="2.2"
        opacity="0.55"
        d="M150 100 C205 110 265 106 322 92"
      />
    </svg>
  );
}

export function FounderSection() {
  return (
    <section className="founder-section">
      <div className="founder-section__inner">
        <div className="founder-photo-card" data-reveal="card">
          <img src="/assets/images/rn-founder-card.svg" alt={founder.name} loading="lazy" decoding="async" />
          <div className="founder-photo-card__caption">
            <span className="section-label__glyph" aria-hidden="true">
              ‹ ◉ ›
            </span>
            <h2>{founder.name}</h2>
            <p>{founder.role}</p>
          </div>
        </div>

        <div className="founder-section__copy" data-reveal="copy">
          <SectionLabel>{founder.label}</SectionLabel>
          <h2 className="founder-section__title">{founder.name}</h2>
          <p className="founder-section__role">{founder.role}</p>
          <div className="founder-section__paragraphs">
            {founder.paragraphs.map((paragraph) => (
              <p key={paragraph.strong}>
                {paragraph.before}
                <strong>{paragraph.strong}</strong>
                {paragraph.after}
              </p>
            ))}
          </div>
          <FounderSignature />
        </div>

        <img
          className="founder-section__portrait"
          src="/assets/images/rn-founder.svg"
          alt={`${founder.name}, ${founder.role}`}
          loading="lazy"
          decoding="async"
        />
      </div>
    </section>
  );
}
