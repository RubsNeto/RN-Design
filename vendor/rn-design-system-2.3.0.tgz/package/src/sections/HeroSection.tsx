import { motion } from "framer-motion";
import { useEffect, useRef } from "react";
import { Typewriter } from "../components/Typewriter";
import { client, hero } from "../data/content";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";

export function HeroSection() {
  const reducedMotion = useReducedMotionPreference();
  const wordmarkRef = useRef<HTMLDivElement>(null);
  const duration = reducedMotion ? 0 : 0.76;

  useEffect(() => {
    const wordmark = wordmarkRef.current;
    if (!wordmark || reducedMotion || !window.matchMedia("(pointer: fine)").matches) return;

    let frame = 0;
    let pointerX = 50;
    let pointerY = 46;

    const commitLight = () => {
      frame = 0;
      wordmark.style.setProperty("--hero-light-x", `${pointerX}%`);
      wordmark.style.setProperty("--hero-light-y", `${pointerY}%`);
    };

    const onPointerMove = (event: PointerEvent) => {
      pointerX = (event.clientX / Math.max(window.innerWidth, 1)) * 100;
      pointerY = (event.clientY / Math.max(window.innerHeight, 1)) * 100;
      if (!frame) frame = window.requestAnimationFrame(commitLight);
    };

    window.addEventListener("pointermove", onPointerMove, { passive: true });
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.cancelAnimationFrame(frame);
    };
  }, [reducedMotion]);

  const wordmarkLetters = "RN DESIGN".split("");
  const burstVectors = [
    [-118, -64], [-72, -128], [8, -142], [88, -118],
    [132, -46], [104, 62], [-16, 128], [-108, 74],
  ] as const;

  return (
    <section id="hero" className="hero-section">
      <div className="hero-section__ambient" aria-hidden="true" />
      <motion.div
        ref={wordmarkRef}
        className="hero-section__wordmark-stage"
        style={{ x: "-50%" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: reducedMotion ? 0 : 0.24 }}
      >
        <span className="hero-section__wordmark" role="img" aria-label="RN Design &amp; Serviços">
          <img
            className="hero-section__wordmark-icon"
            src="/assets/brand/rn-icon.png"
            alt=""
            decoding="sync"
            fetchPriority="high"
          />
          <span className="hero-section__shockwave" aria-hidden="true" />
          <span className="hero-section__burst" aria-hidden="true">
            {burstVectors.map(([bx, by], index) => (
              <i
                key={`${bx}-${by}`}
                style={{ "--bx": `${bx}px`, "--by": `${by}px`, "--bd": `${index * 28}ms` } as React.CSSProperties}
              />
            ))}
          </span>
          <b aria-hidden="true" data-text="RN DESIGN">
            {wordmarkLetters.map((letter, index) =>
              letter === " " ? (
                <i key={`sp-${index}`} className="hero-letter hero-letter--space">
                  {" "}
                </i>
              ) : (
                <i
                  key={`${letter}-${index}`}
                  className="hero-letter"
                  style={{
                    "--i": wordmarkLetters.slice(0, index).filter((character) => character !== " ").length,
                  } as React.CSSProperties}
                >
                  {letter}
                </i>
              ),
            )}
            <small>
              <Typewriter text="& SERVIÇOS" speed={62} startDelay={reducedMotion ? 0 : 1250} />
            </small>
          </b>
        </span>
        <span className="hero-section__wordmark-reflection" aria-hidden="true" />
        <span className="hero-section__wordmark-glint" aria-hidden="true" />
      </motion.div>

      <div className="hero-section__content">
        <motion.div
          className="client-pill"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: duration * 0.72, delay: reducedMotion ? 0 : 1.15 }}
        >
          <span className="client-pill__status" aria-hidden="true" />
          <span>
            Cliente:{" "}
            <strong>
              <Typewriter text={client.name} speed={64} startDelay={1500} caret="blink" />
            </strong>
          </span>
          <span className="client-pill__icons" aria-hidden="true">
            ‹ ◉ ›
          </span>
        </motion.div>

        <motion.h1
          initial={{
            opacity: 0,
            y: 42,
            rotateX: 7,
            clipPath: "inset(0 0 100% 0)",
          }}
          animate={{
            opacity: 1,
            y: 0,
            rotateX: 0,
            clipPath: "inset(0 0 0% 0)",
          }}
          transition={{ duration: duration * 1.08, delay: reducedMotion ? 0 : 1.32, ease: [0.16, 1, 0.3, 1] }}
        >
          Proposta de <span>orçamento</span>
          <br className="hero-desktop-break" />
          {" "}{hero.serviceLine}
        </motion.h1>

        <motion.div
          className="hero-section__details"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration, delay: reducedMotion ? 0 : 1.52 }}
        >
          <div className="client-count">
            <div className="capability-chips" aria-label="Frentes de atuação">
              {hero.capabilities.map((capability) => (
                <span key={capability}>{capability}</span>
              ))}
            </div>
            <span>
              <Typewriter text={hero.credential} speed={26} startDelay={1850} />
            </span>
          </div>
          <p>{hero.description}</p>
          <a
            className="proposal-button hero-section__cta"
            href="#pricing"
            data-cursor="Ver proposta"
            data-magnetic
          >
            <span>Ver orçamento</span>
            <span aria-hidden="true">↓</span>
          </a>
        </motion.div>
      </div>

      <div className="hero-section__handoff" aria-hidden="true">
        <i />
        <span>DA OPERAÇÃO AO SISTEMA</span>
        <i />
      </div>

      <motion.a
        className="hero-scroll-cue"
        href="#objective"
        aria-label="Continuar para o objetivo do projeto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: reducedMotion ? 0 : 0.62, delay: reducedMotion ? 0 : 2.3 }}
        data-cursor="Continuar"
      >
        <span>EXPLORE A PROPOSTA</span>
        <i aria-hidden="true" />
      </motion.a>
    </section>
  );
}
