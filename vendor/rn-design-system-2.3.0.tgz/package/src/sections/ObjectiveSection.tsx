import { useEffect, useRef } from "react";
import { company, objective } from "../data/content";

export function ObjectiveSection() {
  const galleryRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const gallery = galleryRef.current;
    if (
      !gallery ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
      window.matchMedia("(pointer: coarse)").matches
    ) {
      return;
    }

    let frame = 0;
    let currentX = 0;
    let currentY = 0;
    let targetX = 0;
    let targetY = 0;

    const render = () => {
      currentX += (targetX - currentX) * 0.085;
      currentY += (targetY - currentY) * 0.085;

      gallery.style.setProperty("--objective-light-x", `${50 + currentX * 19}%`);
      gallery.style.setProperty("--objective-light-y", `${47 + currentY * 13}%`);
      gallery.style.setProperty("--objective-laptop-x", `${currentX * -9}px`);
      gallery.style.setProperty("--objective-laptop-y", `${currentY * -6}px`);
      gallery.style.setProperty("--objective-phones-x", `${currentX * 15}px`);
      gallery.style.setProperty("--objective-phones-y", `${currentY * 9}px`);

      if (Math.abs(targetX - currentX) > 0.002 || Math.abs(targetY - currentY) > 0.002) {
        frame = window.requestAnimationFrame(render);
      } else {
        frame = 0;
      }
    };

    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(render);
    };

    const onPointerMove = (event: PointerEvent) => {
      const bounds = gallery.getBoundingClientRect();
      targetX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 2;
      targetY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 2;
      schedule();
    };

    const onPointerLeave = () => {
      targetX = 0;
      targetY = 0;
      schedule();
    };

    gallery.addEventListener("pointermove", onPointerMove, { passive: true });
    gallery.addEventListener("pointerleave", onPointerLeave);

    return () => {
      gallery.removeEventListener("pointermove", onPointerMove);
      gallery.removeEventListener("pointerleave", onPointerLeave);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <>
      <section id="objective" className="objective-section">
        <div className="objective-section__copy">
          <h2 data-reveal="heading">
            Qual o <span>objetivo</span> da {company.shortName} para com o seu projeto?
          </h2>
          <div className="objective-section__text" data-reveal="copy">
            {objective.paragraphs.map((paragraph) => (
              <p key={paragraph.strong}>
                {paragraph.before}
                <strong>{paragraph.strong}</strong>
                {paragraph.after}
              </p>
            ))}
          </div>
        </div>
        <a
          className="objective-section__next"
          href="#related-projects"
          aria-label="Continuar para as soluções construídas"
          data-cursor="Soluções"
        >
          <span>Próximo capítulo</span>
          <strong>Soluções construídas</strong>
          <i aria-hidden="true" />
        </a>
      </section>

      <section id="related-projects" className="objective-showcase-section" aria-label="Soluções construídas">
        <div ref={galleryRef} className="objective-gallery" aria-label={`Seleção de soluções ${company.shortName}`}>
          <div className="objective-gallery__header" aria-hidden="true">
            <span>Soluções construídas</span>
            <i />
            <span>{company.shortName}</span>
          </div>
          <div className="objective-gallery__glow" aria-hidden="true" />
          <div className="objective-gallery__device objective-gallery__laptop">
            <img
              src="/assets/images/rn-laptop.svg"
              alt="Sistema de gestão exibido em um notebook"
              loading="lazy"
              decoding="async"
            />
          </div>
          <div className="objective-gallery__device objective-gallery__phones">
            <img
              src="/assets/images/rn-phones.svg"
              alt="Aplicações exibidas em celulares"
              loading="lazy"
              decoding="async"
            />
          </div>
          <div className="objective-gallery__frame" aria-hidden="true">
            <i />
            <i />
          </div>
        </div>
      </section>
    </>
  );
}
