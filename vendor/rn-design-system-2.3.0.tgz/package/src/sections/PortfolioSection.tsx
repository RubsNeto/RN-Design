import { useEffect, useRef, useState } from "react";
import { SectionLabel } from "../components/SectionLabel";
import { portfolioProjects } from "../data/content";

type Project = (typeof portfolioProjects)[number];

function PortfolioCard({
  project,
  index,
  active,
  onToggle,
}: {
  project: Project;
  index: number;
  active: boolean;
  onToggle: () => void;
}) {
  const cardRef = useRef<HTMLElement>(null);
  const frameRef = useRef(0);
  const targetRef = useRef({ x: 0, y: 0 });
  const currentRef = useRef({ x: 0, y: 0 });

  useEffect(() => () => window.cancelAnimationFrame(frameRef.current), []);

  const animateTilt = () => {
    const card = cardRef.current;
    if (!card) return;

    currentRef.current.x += (targetRef.current.x - currentRef.current.x) * 0.16;
    currentRef.current.y += (targetRef.current.y - currentRef.current.y) * 0.16;
    card.style.setProperty("--card-tilt-y", `${currentRef.current.x * 4.5}deg`);
    card.style.setProperty("--card-tilt-x", `${currentRef.current.y * -4.2}deg`);

    const distance = Math.abs(targetRef.current.x - currentRef.current.x) + Math.abs(targetRef.current.y - currentRef.current.y);
    if (distance > 0.002) frameRef.current = window.requestAnimationFrame(animateTilt);
    else frameRef.current = 0;
  };

  const scheduleTilt = () => {
    if (!frameRef.current) frameRef.current = window.requestAnimationFrame(animateTilt);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLElement>) => {
    if (window.matchMedia("(pointer: coarse), (prefers-reduced-motion: reduce)").matches) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    targetRef.current = { x: x - 0.5, y: y - 0.5 };
    event.currentTarget.style.setProperty("--card-light-x", `${x * 100}%`);
    event.currentTarget.style.setProperty("--card-light-y", `${y * 100}%`);
    scheduleTilt();
  };

  const resetTilt = () => {
    targetRef.current = { x: 0, y: 0 };
    cardRef.current?.style.setProperty("--card-light-x", "50%");
    cardRef.current?.style.setProperty("--card-light-y", "50%");
    scheduleTilt();
  };

  return (
    <article
      ref={cardRef}
      className={`portfolio-card${active ? " is-active" : ""}`}
      onPointerMove={onPointerMove}
      onPointerLeave={resetTilt}
      data-reveal="card"
      data-cursor="Ver projeto"
    >
      <button
        className="portfolio-card__trigger"
        type="button"
        aria-label={`Visualizar ${project.title}`}
        aria-pressed={active}
        onClick={onToggle}
        onBlur={resetTilt}
      />
      <div className="portfolio-card__surface">
        <div className="portfolio-card__media">
          <img src={project.image} alt={`Projeto ${project.title}`} loading="lazy" decoding="async" />
          <span className="portfolio-card__sheen" aria-hidden="true" />
          <span className="portfolio-card__hover-label">Ver projeto <i aria-hidden="true">↗</i></span>
        </div>
        <div className="portfolio-card__meta">
          <span className="portfolio-card__marks" aria-hidden="true">
            <i />
            <i />
            <i />
          </span>
          <div>
            <h3>{project.title}</h3>
            <p>{project.year}</p>
          </div>
          <div className="portfolio-card__chips">
            <span>Portfolio</span>
            <span>{project.type}</span>
          </div>
        </div>
      </div>
    </article>
  );
}

export function PortfolioSection() {
  const [activeProject, setActiveProject] = useState<number | null>(null);

  const toggleProject = (index: number) => {
    setActiveProject((current) => (current === index ? null : index));
  };

  return (
    <section id="portfolio" className="portfolio-section">
      <div className="portfolio-section__heading" data-reveal="heading">
        <SectionLabel>Portfólio</SectionLabel>
        <h2>
          Veja na prática alguns <span>projetos recentes</span>
          <br /> feitos por aqui:
        </h2>
      </div>

      <div className="portfolio-grid">
        {portfolioProjects.map((project, index) => (
          <PortfolioCard
            key={project.title}
            project={project}
            index={index}
            active={activeProject === index}
            onToggle={() => toggleProject(index)}
          />
        ))}
      </div>
    </section>
  );
}
