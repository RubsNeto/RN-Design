import gsap from "gsap";
import { useEffect, useRef } from "react";
import { SectionLabel } from "../components/SectionLabel";
import { company, pricing, whatsappLink } from "../data/content";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";

const currencyFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 0,
});

const asCurrency = (value: number) => `R$ ${currencyFormatter.format(value)}`;

export function PricingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const reducedMotion = useReducedMotionPreference();

  useEffect(() => {
    const section = sectionRef.current;
    const ticket = section?.querySelector<HTMLElement>(".pricing-ticket");
    if (!section || !ticket) return;

    const values = Array.from(ticket.querySelectorAll<HTMLElement>("[data-count-to]"));
    let frame = 0;

    const setFinalValues = () => {
      values.forEach((element) => {
        const value = Number(element.dataset.countTo ?? 0);
        element.textContent = asCurrency(value);
      });
    };

    const energize = () => {
      ticket.classList.add("is-energized");
      if (reducedMotion) {
        setFinalValues();
        return;
      }

      const startedAt = performance.now();
      const tick = (now: number) => {
        let complete = true;
        values.forEach((element, index) => {
          const target = Number(element.dataset.countTo ?? 0);
          const elapsed = now - startedAt - index * 75;
          const progress = Math.min(Math.max(elapsed / 920, 0), 1);
          const eased = 1 - Math.pow(1 - progress, 4);
          element.textContent = asCurrency(Math.round(target * eased));
          if (progress < 1) complete = false;
        });

        if (!complete) frame = window.requestAnimationFrame(tick);
      };

      frame = window.requestAnimationFrame(tick);
    };

    if (reducedMotion) {
      energize();
      return () => window.cancelAnimationFrame(frame);
    }

    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        observer.disconnect();
        energize();
      },
      { threshold: 0.32, rootMargin: "0px 0px -6% 0px" },
    );

    observer.observe(ticket);
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(frame);
    };
  }, [reducedMotion]);

  // Tilt 3D sutil no ticket seguindo o ponteiro (como nos cards do portfólio).
  useEffect(() => {
    const ticket = sectionRef.current?.querySelector<HTMLElement>(".pricing-ticket");
    if (!ticket || reducedMotion || !window.matchMedia("(pointer: fine)").matches) return;

    const tiltX = gsap.quickTo(ticket, "rotationX", { duration: 0.55, ease: "power2.out" });
    const tiltY = gsap.quickTo(ticket, "rotationY", { duration: 0.55, ease: "power2.out" });

    const onPointerMove = (event: PointerEvent) => {
      const bounds = ticket.getBoundingClientRect();
      const nx = (event.clientX - bounds.left) / bounds.width - 0.5;
      const ny = (event.clientY - bounds.top) / bounds.height - 0.5;
      tiltY(nx * 5.5);
      tiltX(ny * -4);
    };

    const onPointerLeave = () => {
      tiltX(0);
      tiltY(0);
    };

    ticket.addEventListener("pointermove", onPointerMove, { passive: true });
    ticket.addEventListener("pointerleave", onPointerLeave);
    return () => {
      ticket.removeEventListener("pointermove", onPointerMove);
      ticket.removeEventListener("pointerleave", onPointerLeave);
      gsap.killTweensOf(ticket, "rotationX,rotationY");
    };
  }, [reducedMotion]);

  const { paymentOptions } = pricing;

  return (
    <section ref={sectionRef} id="pricing" className="pricing-section">
      <div className="pricing-section__heading" data-reveal="heading">
        <SectionLabel>Bora para o que mais interessa?</SectionLabel>
        <h2>
          <span>Serviços</span> solicitados:
        </h2>
        <div className="requested-service">
          <div>
            <strong>{pricing.requestedService}</strong>
            <small>{pricing.requestedDetail}</small>
          </div>
          <span aria-hidden="true">⌃<br />◉<br />⌄</span>
        </div>
      </div>

      <div className="pricing-ticket" data-reveal="ticket">
        <span className="pricing-ticket__tab" aria-hidden="true" />
        <span className="pricing-ticket__glow" aria-hidden="true" />
        <span className="pricing-ticket__edge" aria-hidden="true" />
        <span className="pricing-ticket__scan" aria-hidden="true" />
        <img className="pricing-ticket__logo" src="/assets/brand/rn-logo.png" alt={company.name} loading="lazy" decoding="async" />
        <span className="pricing-ticket__divider" aria-hidden="true" />
        <h3>
          Investimento para <span>o projeto</span>
        </h3>

        <div className="price-row price-row--main">
          <span><i /> Valor do projeto</span>
          <strong data-count-to={pricing.projectValue} aria-label={asCurrency(pricing.projectValue)}>
            {asCurrency(pricing.projectValue)}
          </strong>
        </div>

        <h3 className="pricing-ticket__payment-title">
          Formas de <span>pagamento</span>
        </h3>

        <div className="payment-options">
          <div className="price-row">
            <span><i /> Integral</span>
            <small>{paymentOptions.integralDiscountLabel}</small>
            <strong data-count-to={paymentOptions.integralValue} aria-label={asCurrency(paymentOptions.integralValue)}>
              {asCurrency(paymentOptions.integralValue)}
            </strong>
          </div>
          <div className="price-row price-row--split">
            <span><i /> Em duas parcelas</span>
            <small>50% na assinatura</small>
            <strong data-count-to={paymentOptions.splitFirst} aria-label={asCurrency(paymentOptions.splitFirst)}>
              {asCurrency(paymentOptions.splitFirst)}
            </strong>
            <small>50% na entrega</small>
            <strong data-count-to={paymentOptions.splitSecond} aria-label={asCurrency(paymentOptions.splitSecond)}>
              {asCurrency(paymentOptions.splitSecond)}
            </strong>
          </div>
          <div className="price-row">
            <span><i /> Cartão de Crédito</span>
            <small>{paymentOptions.cardInstallments}</small>
            <strong data-count-to={paymentOptions.cardValue} aria-label={asCurrency(paymentOptions.cardValue)}>
              {asCurrency(paymentOptions.cardValue)}
            </strong>
          </div>
        </div>

        <a
          className="proposal-button pricing-ticket__cta"
          href={whatsappLink}
          target="_blank"
          rel="noreferrer"
          data-cursor="Fechar projeto"
          data-magnetic
        >
          <span>Quero fechar o projeto agora</span>
          <span aria-hidden="true">→</span>
        </a>
        <img
          className="pricing-ticket__pixels"
          src="/assets/images/rn-pixels.svg"
          alt=""
          aria-hidden="true"
          loading="lazy"
          decoding="async"
        />
      </div>

      <div className="pricing-validity" data-reveal="copy">
        <i aria-hidden="true" />
        <span>
          Proposta válida até <strong>{pricing.validUntil}</strong>
        </span>
      </div>
    </section>
  );
}
