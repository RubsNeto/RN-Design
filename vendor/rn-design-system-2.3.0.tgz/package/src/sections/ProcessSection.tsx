import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { AnimatePresence, motion } from "framer-motion";
import { useLayoutEffect, useRef, useState } from "react";
import { SectionLabel } from "../components/SectionLabel";
import { processSteps } from "../data/content";
import { useMediaQuery } from "../hooks/useMediaQuery";
import { useReducedMotionPreference } from "../hooks/useReducedMotionPreference";

gsap.registerPlugin(ScrollTrigger);

function ProcessIcon({ index }: { index: number }) {
  const paths = [
    // Descoberta — conversa
    <><path d="M5 5.5h14v10H9l-4 3v-13Z" /><path d="M8 9h8M8 12h5" /></>,
    // Estratégia — personas e jornadas
    <><circle cx="6" cy="7" r="2" /><circle cx="18" cy="7" r="2" /><circle cx="12" cy="18" r="2" /><path d="M7.7 8.1 10.5 16M16.3 8.1 13.5 16M8 7h8" /></>,
    // Design — wireframe
    <><path d="M4.5 5h15v14h-15z" /><path d="M4.5 10h15M10.5 10v9" /></>,
    // Desenvolvimento — código
    <><path d="m8.3 7.8-4.3 4.2 4.3 4.2M15.7 7.8l4.3 4.2-4.3 4.2" /><path d="M13.4 4.5l-2.8 15" /></>,
    // Lançamento — foguete
    <><path d="M12 3.5c2.9 1.8 4.5 4.7 4.3 8.3l-2.2 2.2H9.9l-2.2-2.2C7.5 8.2 9.1 5.3 12 3.5Z" /><circle cx="12" cy="9.3" r="1.6" /><path d="m9.7 14.5-1 4.5 3.3-1.7 3.3 1.7-1-4.5" /></>,
    // Evolução — métricas
    <><path d="M4.5 4.5v15h15" /><path d="m7.5 14.5 3.5-3.5 2.5 2.5 4.5-5" /><path d="M15.5 8.5H18V11" /></>,
  ];

  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[index]}
    </svg>
  );
}

export function ProcessSection() {
  const [activeStep, setActiveStep] = useState(0);
  const rootRef = useRef<HTMLElement>(null);
  const stepRefs = useRef<Array<HTMLElement | null>>([]);
  const reducedMotion = useReducedMotionPreference();
  const compactLayout = useMediaQuery("(max-width: 900px)");

  useLayoutEffect(() => {
    if (reducedMotion || !rootRef.current) return;

    const context = gsap.context(() => {
      stepRefs.current.forEach((step, index) => {
        if (!step) return;
        ScrollTrigger.create({
          trigger: step,
          start: compactLayout ? "top 75%" : "top 33%",
          end: "bottom 25%",
          onEnter: () => setActiveStep(index),
          onEnterBack: () => setActiveStep(index),
        });
      });
    }, rootRef);

    return () => context.revert();
  }, [compactLayout, reducedMotion]);

  const compactProgress = [0.2, 0.34, 0.44, 0.62, 0.8, 1];
  const progress = compactLayout
    ? compactProgress[activeStep]
    : (activeStep + 1) / processSteps.length;

  return (
    <section ref={rootRef} className="process-section">
      <div className="process-section__intro" data-reveal="heading">
        <SectionLabel tone="dark">Etapa por etapa</SectionLabel>
        <h2>
          Entenda o processo de <br />
          <span>desenvolvimento</span> do seu projeto
        </h2>
        <p>
          Um processo simples e transparente, pensado para manter tudo claro, eficiente e tranquilo do
          início ao fim.
        </p>
      </div>

      <div className="process-timeline" data-reveal="copy">
        <div className="process-timeline__number" aria-live="polite">
          <span className="process-timeline__number-window">
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.strong
                key={activeStep}
                initial={reducedMotion ? false : { y: 22, opacity: 0, scale: 0.94 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={reducedMotion ? undefined : { y: -20, opacity: 0, scale: 0.96 }}
                transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                {String(activeStep + 1).padStart(2, "0")}
              </motion.strong>
            </AnimatePresence>
          </span>
          <span>/06</span>
        </div>
        <div className="process-timeline__rail" aria-hidden="true">
          <span style={{ height: `${progress * 100}%` }} />
        </div>
        <div className="process-timeline__steps">
          {processSteps.map((step, index) => (
            <article
              key={step.title}
              ref={(element) => {
                stepRefs.current[index] = element;
              }}
              className={`process-step${activeStep === index ? " is-active" : ""}`}
            >
              <span className="process-step__icon" aria-hidden="true">
                <ProcessIcon index={index} />
              </span>
              <span className="process-step__index" aria-hidden="true">0{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
