import { SectionLabel } from "../components/SectionLabel";
import { company, portfolioProjects, screens } from "../data/content";

/** Letreiro contínuo com as páginas reais dos projetos, em seção própria. */
export function ScreensSection() {
  const covers = [...portfolioProjects, ...portfolioProjects];

  return (
    <section className="screens-section" aria-label="Telas de projetos da RN Design">
      <div className="screens-section__heading" data-reveal="heading">
        <SectionLabel tone="dark">{screens.label}</SectionLabel>
        <h2>
          {screens.titleBefore}
          <span>{screens.titleStrong}</span>
          {screens.titleAfter}
        </h2>
      </div>

      <div className="screens-rail" data-reveal="copy" aria-hidden="true">
        <div className="screens-rail__track">
          {[...covers, ...covers].map((project, index) => (
            <img
              key={`${project.title}-${index}`}
              src={project.image}
              alt=""
              loading="lazy"
              decoding="async"
            />
          ))}
        </div>
      </div>

      <div className="screens-section__cta" data-reveal="copy">
        <span>{screens.ctaLabel}</span>
        <a href={company.siteUrl} target="_blank" rel="noreferrer">
          {company.site}
          <i aria-hidden="true">↗</i>
        </a>
      </div>
    </section>
  );
}
