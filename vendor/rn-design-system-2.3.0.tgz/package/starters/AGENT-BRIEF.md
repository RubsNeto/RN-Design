# Brief de implementação RN

Copie, preencha e entregue este bloco ao agente de codificação junto deste Design System.

```yaml
produto: ""
objetivo_da_tela: ""
usuarios: []
modo: "Product | Expressive"
tipo_de_tela: "product-interface | data-dashboard | auth | expressive-experience"
rotas: []
dados_de_entrada: []
acoes_primarias: []
acoes_secundarias: []
estados_obrigatorios:
  - loading
  - empty
  - error
  - success
  - disabled
  - permission
regras_de_negocio: []
integracoes: []
restricoes_tecnicas: []
criterios_de_aceite: []
```

## Instrução pronta

> Implemente este brief seguindo `AGENTS.md` e `docs/AGENT-QUICKSTART.md`. Use o orçamento como fonte estética dominante, Montserrat, canvas Product branco, azul-celeste e o background RN oficial. Reutilize tokens/primitives existentes, cubra todos os estados aplicáveis e execute os gates de qualidade antes da entrega.

