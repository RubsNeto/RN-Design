# Starters RN

Esqueletos sem regra de negócio para acelerar novos produtos:

- `auth.html`: acesso, convite, recuperação e verificação;
- `product-shell.html`: navegação, cabeçalho e conteúdo operacional;
- `dashboard.html`: KPIs, tabela e estado contextual;
- `expressive.html`: hero e capítulos derivados do orçamento.

Abra os arquivos dentro deste repositório ou copie apenas a estrutura para o app consumidor. Troque textos, dados e links; preserve imports, semântica, classes RN e ordem de conteúdo. Para React, use os equivalentes em `examples/react/`.

