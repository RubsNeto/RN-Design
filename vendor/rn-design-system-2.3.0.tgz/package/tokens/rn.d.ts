export type RnTheme = "light";
export type RnMode = "product" | "expressive";
export { rnCssTokens } from "./rn.manifest.js";

export declare const rn: Readonly<{
  color: {
    brand: Readonly<Record<number | "sky" | "blueSoft", string>>;
    neutral: Readonly<Record<number, string>>;
    scene: Readonly<Record<"charcoal" | "stage" | "deep" | "ink" | "text" | "textStrong" | "textMuted", string>>;
    status: Readonly<{ success: string; warning: string; danger: string }>;
  };
  typography: {
    size: Readonly<Record<"hero" | "heroMobile" | "wordmark" | "wordmarkMobile" | "section", string>>;
    weight: Readonly<Record<"regular" | "medium" | "semibold" | "bold" | "extrabold", number>>;
    leading: Readonly<Record<"wordmark" | "tight" | "section" | "hero" | "heading" | "storyCopy" | "body" | "support" | "relaxed", number>>;
    tracking: Readonly<Record<"hero" | "tight" | "signature", string>>;
  };
  space: readonly number[];
  radius: Readonly<Record<"xs" | "sm" | "md" | "lg" | "xl" | "xxl" | "pill", number>>;
  control: Readonly<Record<"sm" | "md" | "lg" | "targetMin", number>>;
  icon: Readonly<Record<"sm" | "md" | "lg" | "xl", number>>;
  breakpoint: Readonly<Record<"compact" | "medium" | "wide" | "large", number>>;
  container: Readonly<Record<"reading" | "product" | "story" | "wide", number>>;
  layout: {
    story: Readonly<Record<"columnMain" | "columnAside" | "columnGap" | "supportWidth" | "heroMinHeight" | "heroMinHeightMobile" | "sceneMinHeight" | "sectionSpace" | "perspective" | "wordmarkIconMin" | "wordmarkIconMax", number>>;
  };
  motif: Readonly<Record<"gridProduct" | "gridEditorialX" | "gridEditorialY" | "iconLarge" | "iconSmall" | "opacityLarge" | "opacitySmall" | "orbitSmall" | "orbitLarge" | "stageGlow", number>>;
  motion: {
    duration: Readonly<Record<"instant" | "fast" | "base" | "slow" | "entry" | "reveal" | "scene" | "chapter" | "count" | "ambient", number>>;
    stagger: Readonly<Record<"word" | "wordmark", number>>;
    easing: Readonly<Record<"standard" | "emphasized" | "exit", string>>;
  };
  effect: {
    shadow: Readonly<Record<"device" | "wordmark", string>>;
    gradient: Readonly<Record<"wordmark" | "progress", string>>;
  };
}>;

export declare const rnSemantic: Readonly<Record<RnTheme, Readonly<Record<string, string>>>>;
