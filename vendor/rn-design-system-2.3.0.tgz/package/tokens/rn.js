/** Runtime-safe RN tokens. Keep in sync with rn.ts, rn.css and rn.tokens.json. */
export { rnCssTokens } from "./rn.manifest.js";

export const rn = Object.freeze({
  color: {
    brand: {
      50: "#EAF9FD", 100: "#CFF2FA", 200: "#9BE5F3", 300: "#6BD8EC",
      400: "#3FD0E9", 500: "#31BBD8", 600: "#2399C3", 700: "#1A6FAE",
      800: "#14538C", 900: "#0A2540", 950: "#04101D", sky: "#47ABE1", blueSoft: "#5A9AEE",
    },
    neutral: {
      0: "#FFFFFF", 50: "#F8FBFD", 100: "#F4F8FB", 200: "#EAF2F7",
      300: "#D9E6EE", 400: "#B7CBD7", 500: "#86A9BC", 600: "#617987",
      700: "#526B7A", 800: "#26465B", 900: "#102A3D", 950: "#07141F",
    },
    scene: {
      charcoal: "#202020", stage: "#1A1D1D", deep: "#16191C", ink: "#0F1418",
      text: "#F3F3F3", textStrong: "#E8E8E8", textMuted: "#989898",
    },
    status: { success: "#067647", warning: "#B54708", danger: "#B42318" },
  },
  typography: {
    size: {
      hero: "clamp(64px, 4.2vw, 80px)", heroMobile: "clamp(40px, 13vw, 56px)",
      wordmark: "clamp(84px, 11.6vw, 212px)", wordmarkMobile: "clamp(56px, 18vw, 96px)",
      section: "clamp(38px, 3.8vw, 56px)",
    },
    weight: { regular: 400, medium: 500, semibold: 650, bold: 700, extrabold: 800 },
    leading: { wordmark: 0.94, tight: 1.08, section: 1.12, hero: 1.14, heading: 1.18, storyCopy: 1.45, body: 1.6, support: 1.7, relaxed: 1.75 },
    tracking: { hero: "-0.045em", tight: "-0.035em", signature: "0.52em" },
  },
  space: [0, 4, 8, 12, 16, 24, 32, 40, 48, 64, 80, 96, 128],
  radius: { xs: 6, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, pill: 999 },
  control: { sm: 36, md: 44, lg: 52, targetMin: 44 },
  icon: { sm: 16, md: 20, lg: 24, xl: 32 },
  breakpoint: { compact: 600, medium: 900, wide: 1200, large: 1500 },
  container: { reading: 720, product: 1200, story: 1278, wide: 1440 },
  layout: {
    story: {
      columnMain: 920, columnAside: 432, columnGap: 88, supportWidth: 432, heroMinHeight: 1080, heroMinHeightMobile: 768,
      sceneMinHeight: 720, sectionSpace: 108, perspective: 1400,
      wordmarkIconMin: 84, wordmarkIconMax: 172,
    },
  },
  motif: {
    gridProduct: 40, gridEditorialX: 160, gridEditorialY: 180,
    iconLarge: 608, iconSmall: 120, opacityLarge: 0.06, opacitySmall: 0.14,
    orbitSmall: 120, orbitLarge: 360, stageGlow: 980,
  },
  motion: {
    duration: { instant: 100, fast: 160, base: 240, slow: 420, entry: 580, reveal: 650, scene: 720, chapter: 820, count: 920, ambient: 64000 },
    stagger: { word: 50, wordmark: 62 },
    easing: {
      standard: "cubic-bezier(0.22, 1, 0.36, 1)",
      emphasized: "cubic-bezier(0.16, 1, 0.3, 1)",
      exit: "cubic-bezier(0.4, 0, 1, 1)",
    },
  },
  effect: {
    shadow: {
      device: "0 32px 48px rgba(0, 0, 0, 0.26)",
      wordmark: "0 18px 34px rgba(48, 150, 220, 0.35)",
    },
    gradient: {
      wordmark: "linear-gradient(100deg, #3FD0E9, #47ABE1 54%, #5A9AEE)",
      progress: "linear-gradient(90deg, #1A6FAE, #47ABE1 55%, #3FD0E9)",
    },
  },
});

export const rnSemantic = Object.freeze({
  light: {
    background: rn.color.neutral[0], surface: rn.color.neutral[0], surfaceSoft: rn.color.neutral[50],
    surfaceMuted: rn.color.neutral[100], surfaceBrand: rn.color.brand[50],
    text: rn.color.neutral[950], textSubtle: rn.color.neutral[700], textMuted: rn.color.neutral[600], heading: rn.color.brand[900],
    border: rn.color.neutral[300], borderStrong: rn.color.neutral[400], controlBorder: rn.color.neutral[600],
    primary: rn.color.brand.sky, primaryHover: rn.color.brand.blueSoft, primaryActive: rn.color.brand[500], onPrimary: rn.color.neutral[950],
    accent: rn.color.brand[400], accentStrong: rn.color.brand.sky, onAccent: rn.color.neutral[950],
    brandText: rn.color.brand[700], focus: rn.color.brand[800], focusAccent: rn.color.brand[400],
    link: rn.color.brand[700], linkHover: rn.color.brand[900], overlay: "rgba(4, 16, 29, 0.72)",
    success: rn.color.status.success, successSurface: "#ECFDF3", warning: rn.color.status.warning, warningSurface: "#FFFAEB",
    danger: rn.color.status.danger, dangerSurface: "#FEF3F2",
    scene: rn.color.scene.charcoal, sceneStage: rn.color.scene.stage, sceneDeep: rn.color.scene.deep,
    onScene: rn.color.scene.text, onSceneStrong: rn.color.scene.textStrong, onSceneMuted: rn.color.scene.textMuted,
    sceneBorder: "rgba(82, 167, 225, 0.2)",
  },
});
